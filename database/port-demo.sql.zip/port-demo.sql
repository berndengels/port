# ************************************************************
# Sequel Ace SQL dump
# Version 20046
#
# https://sequel-ace.com/
# https://github.com/Sequel-Ace/Sequel-Ace
#
# Host: 127.0.0.1 (MySQL 5.5.5-10.11.3-MariaDB)
# Datenbank: port-demo
# Verarbeitungszeit: 2023-06-30 14:18:46 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
SET NAMES utf8mb4;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE='NO_AUTO_VALUE_ON_ZERO', SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Tabellen-Dump access_logs
# ------------------------------------------------------------

DROP TABLE IF EXISTS `access_logs`;

CREATE TABLE `access_logs` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ip` varchar(20) NOT NULL DEFAULT '',
  `city` varchar(50) NOT NULL DEFAULT '',
  `country` varchar(50) NOT NULL DEFAULT '',
  `state` varchar(50) NOT NULL DEFAULT '',
  `postal_code` varchar(20) NOT NULL DEFAULT '',
  `user_agent` varchar(255) NOT NULL DEFAULT '',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `city` (`city`),
  KEY `created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

LOCK TABLES `access_logs` WRITE;
/*!40000 ALTER TABLE `access_logs` DISABLE KEYS */;

INSERT INTO `access_logs` (`id`, `ip`, `city`, `country`, `state`, `postal_code`, `user_agent`, `created_at`)
VALUES
	(1,'79.224.141.153','Berlin','Germany','Berlin','10115','Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:109.0) Gecko/20100101 Firefox/109.0','2023-01-31 20:38:25'),
	(2,'79.224.141.153','Berlin','Germany','Berlin','10115','Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:109.0) Gecko/20100101 Firefox/109.0','2023-01-31 20:38:27');

/*!40000 ALTER TABLE `access_logs` ENABLE KEYS */;
UNLOCK TABLES;


# Tabellen-Dump admin_password_resets
# ------------------------------------------------------------

DROP TABLE IF EXISTS `admin_password_resets`;

CREATE TABLE `admin_password_resets` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Tabellen-Dump admin_users
# ------------------------------------------------------------

DROP TABLE IF EXISTS `admin_users`;

CREATE TABLE `admin_users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL DEFAULT '',
  `email` varchar(50) NOT NULL DEFAULT '',
  `fon` varchar(50) DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(100) NOT NULL DEFAULT '',
  `two_factor_secret` text DEFAULT NULL,
  `two_factor_recovery_codes` text DEFAULT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `profile_photo_path` varchar(2048) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `admin_users` WRITE;
/*!40000 ALTER TABLE `admin_users` DISABLE KEYS */;

INSERT INTO `admin_users` (`id`, `name`, `email`, `fon`, `email_verified_at`, `password`, `two_factor_secret`, `two_factor_recovery_codes`, `remember_token`, `profile_photo_path`, `created_at`, `updated_at`)
VALUES
	(3,'Test-Admin','admin@test.loc','1234567',NULL,'$2y$10$3PoyST1LE0sZuEEd/EnzPePWkmLkHwpjo0Ot7u1NAJ.H.98RCWePu',NULL,NULL,'dvUjJ66V3diftdWpkTiUVAxxV5jwZTDj41Tf0EX7h83hkMaxe36G9lovpOHR',NULL,'2021-10-22 23:25:22','2021-11-17 01:35:39');

/*!40000 ALTER TABLE `admin_users` ENABLE KEYS */;
UNLOCK TABLES;


# Tabellen-Dump apartment_models
# ------------------------------------------------------------

DROP TABLE IF EXISTS `apartment_models`;

CREATE TABLE `apartment_models` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `space` int(10) unsigned NOT NULL,
  `floors` tinyint(1) unsigned NOT NULL,
  `sleeping_places` tinyint(2) unsigned NOT NULL,
  `peak_season_price` int(10) unsigned DEFAULT NULL,
  `mid_season_price` int(10) unsigned DEFAULT NULL,
  `low_season_price` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

LOCK TABLES `apartment_models` WRITE;
/*!40000 ALTER TABLE `apartment_models` DISABLE KEYS */;

INSERT INTO `apartment_models` (`id`, `name`, `description`, `space`, `floors`, `sleeping_places`, `peak_season_price`, `mid_season_price`, `low_season_price`)
VALUES
	(1,'Apartment Grande','Das ist unsere größte Wohnung.',120,2,8,220,180,140),
	(2,'Apartment  Medium','Das ist unsere mittelgroße Wohnung.',80,2,6,180,160,130),
	(3,'Apartment  Petite','Das ist unsere kleinste Wohnung.',60,1,4,80,60,50);

/*!40000 ALTER TABLE `apartment_models` ENABLE KEYS */;
UNLOCK TABLES;


# Tabellen-Dump apartments
# ------------------------------------------------------------

DROP TABLE IF EXISTS `apartments`;

CREATE TABLE `apartments` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `apartment_model_id` int(11) unsigned NOT NULL,
  `name` varchar(50) NOT NULL DEFAULT '',
  `calendar_color` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `houseboat_model_id` (`apartment_model_id`),
  CONSTRAINT `apartments_ibfk_1` FOREIGN KEY (`apartment_model_id`) REFERENCES `houseboat_models` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

LOCK TABLES `apartments` WRITE;
/*!40000 ALTER TABLE `apartments` DISABLE KEYS */;

INSERT INTO `apartments` (`id`, `apartment_model_id`, `name`, `calendar_color`)
VALUES
	(1,1,'Bellinda','#ea211e'),
	(2,2,'Pauline','#005392'),
	(3,3,'Hansi','#009192');

/*!40000 ALTER TABLE `apartments` ENABLE KEYS */;
UNLOCK TABLES;


# Tabellen-Dump berth_categories
# ------------------------------------------------------------

DROP TABLE IF EXISTS `berth_categories`;

CREATE TABLE `berth_categories` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

LOCK TABLES `berth_categories` WRITE;
/*!40000 ALTER TABLE `berth_categories` DISABLE KEYS */;

INSERT INTO `berth_categories` (`id`, `name`)
VALUES
	(1,'boat'),
	(2,'houseboat');

/*!40000 ALTER TABLE `berth_categories` ENABLE KEYS */;
UNLOCK TABLES;


# Tabellen-Dump berth_maps
# ------------------------------------------------------------

DROP TABLE IF EXISTS `berth_maps`;

CREATE TABLE `berth_maps` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `berth_id` int(11) unsigned NOT NULL,
  `w` int(11) unsigned NOT NULL,
  `h` int(11) unsigned NOT NULL,
  `x` int(11) NOT NULL,
  `y` int(11) NOT NULL,
  `angle` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

LOCK TABLES `berth_maps` WRITE;
/*!40000 ALTER TABLE `berth_maps` DISABLE KEYS */;

INSERT INTO `berth_maps` (`id`, `berth_id`, `w`, `h`, `x`, `y`, `angle`)
VALUES
	(1,94,1037,600,576,522,NULL),
	(2,95,1037,600,627,558,NULL),
	(3,2,1037,600,679,594,NULL),
	(4,5,1037,600,431,586,NULL),
	(5,3,1037,600,495,539,NULL),
	(6,6,1037,600,450,598,NULL),
	(7,7,1037,600,488,601,NULL),
	(8,8,1037,600,479,614,NULL),
	(9,9,1037,600,470,626,NULL),
	(10,10,1037,600,460,638,NULL),
	(11,11,1037,600,451,651,NULL),
	(12,12,1037,600,441,663,NULL),
	(13,13,1037,600,432,676,NULL),
	(14,14,1037,600,422,688,NULL),
	(15,15,1037,600,413,700,NULL),
	(16,16,1037,600,404,713,NULL),
	(17,17,1037,600,519,646,NULL),
	(18,18,1037,600,536,657,NULL),
	(19,19,1037,600,553,668,NULL),
	(20,20,1037,600,570,679,NULL),
	(21,21,1037,600,588,690,NULL),
	(22,22,1037,600,605,701,NULL),
	(23,23,1037,600,622,712,NULL),
	(24,24,1037,600,639,723,NULL),
	(25,25,1037,600,696,676,NULL),
	(26,26,1037,600,717,688,NULL),
	(27,38,1037,600,669,749,NULL),
	(28,27,1037,600,735,700,NULL),
	(29,39,1037,600,688,762,NULL),
	(30,28,1037,600,753,712,NULL),
	(31,40,1037,600,707,775,NULL),
	(32,29,1037,600,771,724,NULL),
	(33,41,1037,600,726,788,NULL),
	(34,30,1037,600,789,736,NULL),
	(35,42,1037,600,745,801,NULL),
	(36,31,1037,600,807,748,NULL),
	(37,43,1037,600,764,814,NULL),
	(38,32,1037,600,825,759,NULL),
	(39,44,1037,600,783,828,NULL),
	(40,33,1037,600,843,771,NULL),
	(41,45,1037,600,802,841,NULL),
	(42,34,1037,600,861,783,NULL),
	(43,46,1037,600,821,854,NULL),
	(44,35,1037,600,879,795,NULL),
	(45,47,1037,600,840,867,NULL),
	(46,36,1037,600,897,807,NULL),
	(47,48,1037,600,859,880,NULL),
	(48,37,1037,600,915,819,NULL),
	(49,49,1037,600,878,893,NULL),
	(50,50,1037,600,950,829,NULL),
	(51,72,1037,600,897,929,NULL),
	(52,51,1037,600,969,843,NULL),
	(53,73,1037,600,916,942,NULL),
	(54,52,1037,600,989,856,NULL),
	(55,74,1037,600,935,955,NULL),
	(56,53,1037,600,1008,870,NULL),
	(57,75,1037,600,954,968,NULL),
	(58,54,1037,600,1028,884,NULL),
	(59,76,1037,600,973,982,NULL),
	(60,55,1037,600,1048,898,NULL),
	(61,77,1037,600,992,995,NULL),
	(62,56,1037,600,1067,912,NULL),
	(63,78,1037,600,1011,1008,NULL),
	(64,57,1037,600,1087,925,NULL),
	(65,79,1037,600,1031,1021,NULL),
	(66,58,1037,600,1106,939,NULL),
	(67,80,1037,600,1050,1034,NULL),
	(68,59,1037,600,1126,953,NULL),
	(69,81,1037,600,1069,1048,NULL),
	(70,60,1037,600,1145,967,NULL),
	(71,82,1037,600,1088,1061,NULL),
	(72,61,1037,600,1165,980,NULL),
	(73,83,1037,600,1107,1074,NULL),
	(74,62,1037,600,1184,994,NULL),
	(75,84,1037,600,1126,1087,NULL),
	(76,63,1037,600,1204,1008,NULL),
	(77,85,1037,600,1145,1101,NULL),
	(78,64,1037,600,1223,1022,NULL),
	(79,86,1037,600,1164,1114,NULL),
	(80,65,1037,600,1243,1035,NULL),
	(81,87,1037,600,1184,1127,NULL),
	(82,66,1037,600,1263,1049,NULL),
	(83,88,1037,600,1203,1140,NULL),
	(84,67,1037,600,1282,1063,NULL),
	(85,89,1037,600,1222,1153,NULL),
	(86,68,1037,600,1302,1077,NULL),
	(87,90,1037,600,1241,1167,NULL),
	(88,69,1037,600,1321,1091,NULL),
	(89,91,1037,600,1260,1180,NULL),
	(90,70,1037,600,1341,1104,NULL),
	(91,92,1037,600,1279,1193,NULL),
	(92,71,1037,600,1360,1118,NULL),
	(93,93,1037,600,1298,1206,NULL);

/*!40000 ALTER TABLE `berth_maps` ENABLE KEYS */;
UNLOCK TABLES;


# Tabellen-Dump berths
# ------------------------------------------------------------

DROP TABLE IF EXISTS `berths`;

CREATE TABLE `berths` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `dock_id` int(11) unsigned DEFAULT NULL,
  `berth_category_id` int(11) unsigned DEFAULT NULL,
  `number` varchar(10) NOT NULL DEFAULT '',
  `width` decimal(3,1) unsigned DEFAULT NULL,
  `length` decimal(3,1) unsigned DEFAULT NULL,
  `daily_price` decimal(5,2) unsigned DEFAULT NULL,
  `lat` double unsigned DEFAULT NULL,
  `lng` double DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `boat_dock_id` (`dock_id`),
  KEY `berth_category_id` (`berth_category_id`),
  CONSTRAINT `berths_ibfk_1` FOREIGN KEY (`dock_id`) REFERENCES `docks` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `berths_ibfk_2` FOREIGN KEY (`berth_category_id`) REFERENCES `berth_categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

LOCK TABLES `berths` WRITE;
/*!40000 ALTER TABLE `berths` DISABLE KEYS */;

INSERT INTO `berths` (`id`, `dock_id`, `berth_category_id`, `number`, `width`, `length`, `daily_price`, `lat`, `lng`, `enabled`)
VALUES
	(2,2,2,'3',11.0,10.0,NULL,54.026320985206,13.910778611898,1),
	(3,1,1,'5',4.2,7.0,NULL,54.026407116092,13.91028508544,1),
	(5,1,1,'4',4.0,7.0,NULL,54.026333852362,13.910112977028,1),
	(6,1,1,'6',4.0,7.0,NULL,54.026314420389,13.910164833069,1),
	(7,1,1,'7',2.7,10.0,NULL,54.026309115966,13.910266667604,1),
	(8,1,1,'8',2.7,10.0,NULL,54.026289578903,13.91024145484,1),
	(9,1,1,'9',2.7,10.0,NULL,54.026270041839,13.910216242075,1),
	(10,1,1,'10',2.7,10.0,NULL,54.026250504775,13.91019102931,1),
	(11,1,1,'11',2.7,10.0,NULL,54.026230967711,13.910165816545,1),
	(12,1,1,'12',2.7,10.0,NULL,54.026211430647,13.910140603781,1),
	(13,1,1,'13',2.7,10.0,NULL,54.026191893583,13.910115391016,1),
	(14,1,1,'14',2.7,10.0,NULL,54.026172356519,13.910090178251,1),
	(15,1,1,'15',2.7,10.0,NULL,54.026152819456,13.910064965487,1),
	(16,1,1,'16',2.7,10.0,NULL,54.026133282392,13.910039752722,1),
	(17,1,1,'17',3.6,8.0,NULL,54.026239219854,13.910348005593,1),
	(18,1,1,'18',3.6,8.0,NULL,54.026221691623,13.910394273698,1),
	(19,1,1,'19',3.6,8.0,NULL,54.026204163393,13.910440541804,1),
	(20,1,1,'20',3.6,8.0,NULL,54.026186635162,13.910486809909,1),
	(21,1,1,'21',3.6,8.0,NULL,54.026169106931,13.910533078015,1),
	(22,1,1,'22',3.6,8.0,NULL,54.0261515787,13.91057934612,1),
	(23,1,1,'23',3.6,8.0,NULL,54.026134050469,13.910625614226,1),
	(24,1,1,'24',3.6,8.0,NULL,54.026116522238,13.910671882331,1),
	(25,1,1,'25',4.3,10.0,NULL,54.026191263458,13.910823762417,1),
	(26,1,1,'26',3.8,10.0,NULL,54.02617242223,13.910880088806,1),
	(27,1,1,'28',3.8,10.0,NULL,54.026153646623,13.910928368568,1),
	(28,1,1,'30',3.8,10.0,NULL,54.026134871016,13.910976648331,1),
	(29,1,1,'32',3.8,10.0,NULL,54.026116095408,13.911024928093,1),
	(30,1,1,'34',3.8,10.0,NULL,54.026097319801,13.911073207855,1),
	(31,1,1,'36',3.8,10.0,NULL,54.026078544194,13.911121487617,1),
	(32,1,1,'38',3.8,10.0,NULL,54.026059768587,13.91116976738,1),
	(33,1,1,'40',3.8,10.0,NULL,54.02604099298,13.911218047142,1),
	(34,1,1,'42',3.8,10.0,NULL,54.026022217373,13.911266326904,1),
	(35,1,1,'44',3.8,10.0,NULL,54.026003441765,13.911314606667,1),
	(36,1,1,'46',3.8,10.0,NULL,54.025984666158,13.911362886429,1),
	(37,1,1,'48',3.8,10.0,NULL,54.025965890551,13.911411166191,1),
	(38,1,1,'27',4.1,10.0,NULL,54.026076903092,13.910750113428,1),
	(39,1,1,'29',4.1,10.0,NULL,54.026056157962,13.910801298916,1),
	(40,1,1,'31',4.1,10.0,NULL,54.026035412833,13.910852484405,1),
	(41,1,1,'33',4.1,10.0,NULL,54.026014667703,13.910903669894,1),
	(42,1,1,'35',4.1,10.0,NULL,54.025993922574,13.910954855382,1),
	(43,1,1,'37',4.1,10.0,NULL,54.025973177444,13.911006040871,1),
	(44,1,1,'39',4.1,10.0,NULL,54.025952432315,13.91105722636,1),
	(45,1,1,'41',4.1,10.0,NULL,54.025931687185,13.911108411849,1),
	(46,1,1,'43',4.1,10.0,NULL,54.025910942056,13.911159597337,1),
	(47,1,1,'45',4.1,10.0,NULL,54.025890196926,13.911210782826,1),
	(48,1,1,'47',4.1,10.0,NULL,54.025869451797,13.911261968315,1),
	(49,1,1,'49',4.1,10.0,NULL,54.025848706667,13.911313153803,1),
	(50,1,1,'50',4.2,12.0,NULL,54.025950379411,13.911504433914,1),
	(51,1,1,'52',4.2,12.0,NULL,54.025928679259,13.911556858908,1),
	(52,1,1,'54',4.2,12.0,NULL,54.025906979107,13.911609283902,1),
	(53,1,1,'56',4.2,12.0,NULL,54.025885278956,13.911661708897,1),
	(54,1,1,'58',4.2,12.0,NULL,54.025863578804,13.911714133891,1),
	(55,1,1,'60',4.2,12.0,NULL,54.025841878653,13.911766558886,1),
	(56,1,1,'62',4.2,12.0,NULL,54.025820178501,13.91181898388,1),
	(57,1,1,'64',4.2,12.0,NULL,54.02579847835,13.911871408874,1),
	(58,1,1,'66',4.2,12.0,NULL,54.025776778198,13.911923833869,1),
	(59,1,1,'68',4.2,12.0,NULL,54.025755078047,13.911976258863,1),
	(60,1,1,'70',4.2,12.0,NULL,54.025733377895,13.912028683857,1),
	(61,1,1,'72',4.2,12.0,NULL,54.025711677744,13.912081108852,1),
	(62,1,1,'74',4.2,12.0,NULL,54.025689977592,13.912133533846,1),
	(63,1,1,'76',4.2,12.0,NULL,54.025668277441,13.912185958841,1),
	(64,1,1,'78',4.2,12.0,NULL,54.025646577289,13.912238383835,1),
	(65,1,1,'80',4.2,12.0,NULL,54.025624877138,13.912290808829,1),
	(66,1,1,'82',4.2,12.0,NULL,54.025603176986,13.912343233824,1),
	(67,1,1,'84',4.2,12.0,NULL,54.025581476835,13.912395658818,1),
	(68,1,1,'86',4.2,12.0,NULL,54.025559776683,13.912448083813,1),
	(69,1,1,'88',4.2,12.0,NULL,54.025538076532,13.912500508807,1),
	(70,1,1,'90',4.2,12.0,NULL,54.02551637638,13.912552933801,1),
	(71,1,1,'92',4.2,12.0,NULL,54.025494676229,13.912605358796,1),
	(72,1,1,'51',4.1,12.0,NULL,54.025793250829,13.911361728202,1),
	(73,1,1,'53',4.1,12.0,NULL,54.025772410016,13.911413055929,1),
	(74,1,1,'55',4.1,12.0,NULL,54.025751569202,13.911464383656,1),
	(75,1,1,'57',4.1,12.0,NULL,54.025730728388,13.911515711383,1),
	(76,1,1,'59',4.1,12.0,NULL,54.025709887574,13.91156703911,1),
	(77,1,1,'61',4.1,12.0,NULL,54.02568904676,13.911618366838,1),
	(78,1,1,'63',4.1,12.0,NULL,54.025668205947,13.911669694565,1),
	(79,1,1,'65',4.1,12.0,NULL,54.025647365133,13.911721022292,1),
	(80,1,1,'67',4.1,12.0,NULL,54.025626524319,13.911772350019,1),
	(81,1,1,'69',4.1,12.0,NULL,54.025605683505,13.911823677746,1),
	(82,1,1,'71',4.1,12.0,NULL,54.025584842691,13.911875005473,1),
	(83,1,1,'73',4.1,12.0,NULL,54.025564001878,13.9119263332,1),
	(84,1,1,'75',4.1,12.0,NULL,54.025543161064,13.911977660927,1),
	(85,1,1,'77',4.1,12.0,NULL,54.02552232025,13.912028988654,1),
	(86,1,1,'79',4.1,12.0,NULL,54.025501479436,13.912080316381,1),
	(87,1,1,'81',4.1,12.0,NULL,54.025480638622,13.912131644108,1),
	(88,1,1,'83',4.1,12.0,NULL,54.025459797809,13.912182971835,1),
	(89,1,1,'85',4.1,12.0,NULL,54.025438956995,13.912234299562,1),
	(90,1,1,'87',4.1,12.0,NULL,54.025418116181,13.912285627289,1),
	(91,1,1,'89',4.1,12.0,NULL,54.025397275367,13.912336955016,1),
	(92,1,1,'91',4.1,12.0,NULL,54.025376434553,13.912388282743,1),
	(93,1,1,'93',4.1,12.0,NULL,54.02535559374,13.91243961047,1),
	(94,2,2,'1',11.0,10.0,NULL,54.02643337542,13.9105014503,1),
	(95,2,2,'2',11.0,10.0,NULL,54.026377180313,13.910640031099,1);

/*!40000 ALTER TABLE `berths` ENABLE KEYS */;
UNLOCK TABLES;


# Tabellen-Dump boat_dates
# ------------------------------------------------------------

DROP TABLE IF EXISTS `boat_dates`;

CREATE TABLE `boat_dates` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `boat_id` int(11) unsigned NOT NULL,
  `modus` enum('summer','winter') NOT NULL DEFAULT 'summer',
  `from` date NOT NULL,
  `until` date NOT NULL,
  `price` int(10) unsigned NOT NULL,
  `prices` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`prices`)),
  `is_paid` tinyint(1) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `boat_id` (`boat_id`),
  KEY `from` (`from`,`until`),
  KEY `price` (`price`),
  KEY `is_paid` (`is_paid`),
  CONSTRAINT `boat_dates_ibfk_1` FOREIGN KEY (`boat_id`) REFERENCES `boats` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

LOCK TABLES `boat_dates` WRITE;
/*!40000 ALTER TABLE `boat_dates` DISABLE KEYS */;

INSERT INTO `boat_dates` (`id`, `boat_id`, `modus`, `from`, `until`, `price`, `prices`, `is_paid`)
VALUES
	(3,2,'winter','2023-10-01','2024-05-31',577,X'7B22707269636542617365223A3433372C2270726963655472616E73706F7274223A35302C2270726963654372616E65223A35302C2270726963654D6173744372616E65223A34302C227072696365436C65616E696E67223A302C2264617973223A3234332C22746178223A31392C226E6574746F223A3438342C227461785072696365223A39332C22746F74616C223A3537377D',1),
	(4,2,'summer','2023-06-01','2023-09-30',742,X'7B22707269636542617365223A3537392C2270726963655472616E73706F7274223A35302C2270726963654372616E65223A35302C2270726963654D6173744372616E65223A34302C227072696365436C65616E696E67223A32322E352C2264617973223A3132312C22746178223A31392C226E6574746F223A3632332C227461785072696365223A3131382E352C22746F74616C223A3734312E357D',1),
	(11,35,'summer','2023-05-01','2023-10-31',788,X'7B22707269636542617365223A3633382C2270726963655472616E73706F7274223A302C2270726963654372616E65223A37352C2270726963654D6173744372616E65223A37352C226475726174696F6E5F6D6173745F6372616E65223A2231222C227072696365436C65616E696E67223A302C2264617973223A3138332C22746178223A31392C226E6574746F223A3636322C227461785072696365223A3132362C22746F74616C223A3738387D',1),
	(12,34,'summer','2023-05-01','2023-10-31',795,X'7B22707269636542617365223A3732302C2270726963655472616E73706F7274223A302C2270726963654372616E65223A37352C2270726963654D6173744372616E65223A302C227072696365436C65616E696E67223A302C2264617973223A3138332C22746178223A31392C226E6574746F223A3636382C227461785072696365223A3132372C22746F74616C223A3739357D',1);

/*!40000 ALTER TABLE `boat_dates` ENABLE KEYS */;
UNLOCK TABLES;


# Tabellen-Dump boats
# ------------------------------------------------------------

DROP TABLE IF EXISTS `boats`;

CREATE TABLE `boats` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `berth_id` int(11) unsigned DEFAULT NULL,
  `customer_id` int(11) unsigned NOT NULL,
  `type` enum('motor','sail') NOT NULL DEFAULT 'motor',
  `name` varchar(50) NOT NULL DEFAULT '',
  `length` decimal(3,1) unsigned DEFAULT NULL,
  `width` decimal(2,1) unsigned DEFAULT NULL,
  `weight` int(10) unsigned DEFAULT NULL,
  `board_height` tinyint(2) unsigned DEFAULT NULL,
  `mast_length` tinyint(2) unsigned DEFAULT NULL,
  `mast_weight` int(10) unsigned DEFAULT NULL,
  `draft` decimal(2,1) unsigned DEFAULT NULL,
  `length_waterline` decimal(3,1) unsigned DEFAULT NULL,
  `length_keel` decimal(3,1) unsigned DEFAULT NULL,
  `home_port` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `boat_name` (`name`),
  KEY `boats_fk_1` (`customer_id`),
  CONSTRAINT `boats_fk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

LOCK TABLES `boats` WRITE;
/*!40000 ALTER TABLE `boats` DISABLE KEYS */;

INSERT INTO `boats` (`id`, `berth_id`, `customer_id`, `type`, `name`, `length`, `width`, `weight`, `board_height`, `mast_length`, `mast_weight`, `draft`, `length_waterline`, `length_keel`, `home_port`)
VALUES
	(2,57,2,'sail','Dicke Berta',7.5,3.0,2500,1,8,50,1.6,6.5,1.5,NULL),
	(3,28,5,'sail','Havelliebe',8.0,2.5,2000,1,9,20,0.4,6.5,6.0,NULL),
	(34,10,8,'motor','Heidi',8.0,3.0,3000,1,NULL,NULL,0.6,7.0,NULL,NULL),
	(35,NULL,19,'sail','Pamina',8.5,2.5,3000,1,9,75,1.0,7.8,3.0,NULL);

/*!40000 ALTER TABLE `boats` ENABLE KEYS */;
UNLOCK TABLES;


# Tabellen-Dump car_license_plates
# ------------------------------------------------------------

DROP TABLE IF EXISTS `car_license_plates`;

CREATE TABLE `car_license_plates` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `country_id` int(11) unsigned NOT NULL,
  `code` varchar(10) NOT NULL DEFAULT '',
  `location` varchar(50) NOT NULL DEFAULT '',
  `district` varchar(300) NOT NULL DEFAULT '',
  `state` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `country_id` (`country_id`),
  KEY `code` (`code`),
  KEY `location` (`location`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

LOCK TABLES `car_license_plates` WRITE;
/*!40000 ALTER TABLE `car_license_plates` DISABLE KEYS */;

INSERT INTO `car_license_plates` (`id`, `country_id`, `code`, `location`, `district`, `state`)
VALUES
	(723,55,'A','Augsburg','Stadt Augsburg, Landkreis Augsburg','Bayern'),
	(724,55,'AA','AAlen','Ostalbkreis','Baden-Württemberg'),
	(725,55,'AB','Aschaffenburg','Stadt Aschaffenburg, Landkreis Aschaffenburg','Bayern'),
	(726,55,'ABG','AltenBurG','Landkreis Altenburger Land','Thüringen'),
	(727,55,'ABI','Anhalt, BItterfeld','Landkreis Anhalt-Bitterfeld','Sachsen-Anhalt'),
	(728,55,'AC','AaChen','Städteregion Aachen','Nordrhein-Westfalen'),
	(729,55,'AE','AuErbach','Vogtlandkreis','Sachsen'),
	(730,55,'AH','AHaus','Kreis Borken','Nordrhein-Westfalen'),
	(731,55,'AIB','AIBling','Landkreis München, Landkreis Rosenheim','Bayern'),
	(732,55,'AIC','AIChach','Landkreis Aichach-Friedberg','Bayern'),
	(733,55,'AK','AltenKirchen','Landkreis Altenkirchen (Westerwald)','Rheinland-Pfalz'),
	(734,55,'ALF','ALFeld','Landkreis Hildesheim','Niedersachsen'),
	(735,55,'ALZ','ALZenau','Landkreis Aschaffenburg','Bayern'),
	(736,55,'AM','AMberg','Stadt Amberg','Bayern'),
	(737,55,'AN','ANsbach','Stadt Ansbach, Landkreis Ansbach','Bayern'),
	(738,55,'ANA','ANnAberg','Erzgebirgskreis','Sachsen'),
	(739,55,'ANG','ANGermünde','Landkreis Uckermark','Brandenburg'),
	(740,55,'ANK','ANKlam','Landkreis Vorpommern-Greifswald ohne die Stadt Greifswald','Mecklenburg-Vorpommern'),
	(741,55,'AÖ','AltÖtting','Landkreis Altötting','Bayern'),
	(742,55,'AP','APolda','Landkreis Weimarer Land','Thüringen'),
	(743,55,'APD','APolDa','Landkreis Weimarer Land','Thüringen'),
	(744,55,'ARN','ARNstadt','Ilm-Kreis','Thüringen'),
	(745,55,'ART','ARTern','Kyffhäuserkreis','Thüringen'),
	(746,55,'AS','Amberg, Sulzbach','Landkreis Amberg-Sulzbach','Bayern'),
	(747,55,'ASL','ASchersLeben','Salzlandkreis','Sachsen-Anhalt'),
	(748,55,'ASZ','Aue, SchwarZenberg','Erzgebirgskreis','Sachsen'),
	(749,55,'AT','AltenTreptow','Landkreis Mecklenburgische Seenplatte ohne die Stadt Neubrandenburg','Mecklenburg-Vorpommern'),
	(750,55,'AU','AUe','Erzgebirgskreis','Sachsen'),
	(751,55,'AUR','AURich','Landkreis Aurich','Niedersachsen'),
	(752,55,'AW','AhrWeiler','Landkreis Ahrweiler','Rheinland-Pfalz'),
	(753,55,'AZ','AlZey','Landkreis Alzey-Worms','Rheinland-Pfalz'),
	(754,55,'AZE','Anhalt-ZErbst','Landkreis Anhalt-Bitterfeld','Sachsen-Anhalt'),
	(755,55,'B','Berlin','Berlin','Berlin'),
	(756,55,'BA','BAmberg','Stadt Bamberg, Landkreis Bamberg','Bayern'),
	(757,55,'BAD','BADen-Baden','Stadt Baden-Baden','Baden-Württemberg'),
	(758,55,'BAR','BARnim','Landkreis Barnim','Brandenburg'),
	(759,55,'BB','BöBlingen','Landkreis Böblingen','Baden-Württemberg'),
	(760,55,'BBG','BernBurG','Salzlandkreis','Sachsen-Anhalt'),
	(761,55,'BBL','BrandenBurgische Landesregierung','Brandenburg, Landesregierung, Landtag und Polizei','Brandenburg'),
	(762,55,'BC','BiberaCh','Landkreis Biberach','Baden-Württemberg'),
	(763,55,'BCH','BuCHen','Neckar-Odenwald-Kreis','Baden-Württemberg'),
	(764,55,'BD','BundesDienst','Deutscher Bundestag, Bundesrat, Bundespräsidialamt, Bundesregierung, Bundesministerien, Bundesfinanzverwaltung und Bundesverfassungsgericht','bundesweit'),
	(765,55,'BE','BEckum','Kreis Warendorf','Nordrhein-Westfalen'),
	(766,55,'BED','Brand-ErbisDorf','Landkreis Mittelsachsen','Sachsen'),
	(767,55,'BER','BERnau','Landkreis Barnim','Brandenburg'),
	(768,55,'BF','BurgsteinFurt','Kreis Steinfurt','Nordrhein-Westfalen'),
	(769,55,'BGD','BerchtesGaDen','Landkreis Berchtesgadener Land','Bayern'),
	(770,55,'BGL','BerchtesGadener Land','Landkreis Berchtesgadener Land','Bayern'),
	(771,55,'BH','BüHl','Ortenaukreis, Landkreis Rastatt','Baden-Württemberg'),
	(772,55,'BI','BIelefeld','Stadt Bielefeld','Nordrhein-Westfalen'),
	(773,55,'BID','BIeDenkopf','Landkreis Marburg-Biedenkopf','Hessen'),
	(774,55,'BIN','BINgen','Landkreis Mainz-Bingen','Rheinland-Pfalz'),
	(775,55,'BIR','BIRkenfeld','Landkreis Birkenfeld','Rheinland-Pfalz'),
	(776,55,'BIT','BITburg','Eifelkreis Bitburg-Prüm','Rheinland-Pfalz'),
	(777,55,'BIW','BIschofsWerda','Landkreis Bautzen','Sachsen'),
	(778,55,'BK','BacKnang','Landkreis Backnang','Baden-Württemberg'),
	(779,55,'BKS','BernKaStel','Landkreis Bernkastel-Wittlich','Rheinland-Pfalz'),
	(780,55,'BL','BaLingen','Zollernalbkreis','Baden-Württemberg'),
	(781,55,'BLB','BerLeBurg','Kreis Siegen-Wittgenstein','Nordrhein-Westfalen'),
	(782,55,'BLK','BurgenLandKreis','Burgenlandkreis','Sachsen-Anhalt'),
	(783,55,'BM','BergheiM','Rhein-Erft-Kreis','Nordrhein-Westfalen'),
	(784,55,'BN','BonN','Stadt Bonn, Diplomaten','Nordrhein-Westfalen'),
	(785,55,'BNA','BorNA','Landkreis Leipzig','Sachsen'),
	(786,55,'BO','BOchum','Stadt Bochum','Nordrhein-Westfalen'),
	(787,55,'BÖ','BÖrde','Landkreis Börde','Sachsen-Anhalt'),
	(788,55,'BOG','BOGen','Landkreis Straubing-Bogen','Bayern'),
	(789,55,'BOH','BOcHolt','Kreis Borken','Nordrhein-Westfalen'),
	(790,55,'BOR','BORken','Kreis Borken','Nordrhein-Westfalen'),
	(791,55,'BOT','BOTtrop','Stadt Bottrop','Nordrhein-Westfalen'),
	(792,55,'BP','BundesPolizei','Bundespolizei','bundesweit'),
	(793,55,'BRA','BRAke','Landkreis Wesermarsch','Niedersachsen'),
	(794,55,'BRB','BRandenBurg','Stadt Brandenburg an der Havel','Brandenburg'),
	(795,55,'BRG','BuRG','Landkreis Jerichower Land','Sachsen-Anhalt'),
	(796,55,'BRK','BRücKenau','Landkreis Bad Kissingen','Bayern'),
	(797,55,'BRL','BRaunLage','Landkreis Goslar','Niedersachsen'),
	(798,55,'BRV','BRemerVörde','Landkreis Rotenburg (Wümme)','Niedersachsen'),
	(799,55,'BS','BraunSchweig','Stadt Braunschweig, Polizeidirektion Braunschweig (PD 100–9999)','Niedersachsen'),
	(800,55,'BSB','BerSenBrück','Landkreis Osnabrück','Niedersachsen'),
	(801,55,'BSK','BeeSKow','Landkreis Oder-Spree','Brandenburg'),
	(802,55,'BT','BayreuTh','Stadt Bayreuth, Landkreis Bayreuth','Bayern'),
	(803,55,'BTF','BitTerFeld','Landkreis Anhalt-Bitterfeld','Sachsen-Anhalt'),
	(804,55,'BÜD','BÜDingen','Wetteraukreis','Hessen'),
	(805,55,'BUL','BUrgLengenfeld','Landkreis Amberg-Sulzbach (B, F und G 1–999), Landkreis Schwandorf','Bayern'),
	(806,55,'BÜR','BÜRen','Kreis Paderborn','Nordrhein-Westfalen'),
	(807,55,'BÜS','BÜSingen','Gemeinde Büsingen am Hochrhein (Gemeinde im Landkreis Konstanz, deutsche Exklave in der Schweiz) (A und Z 1–999)','Baden-Württemberg'),
	(808,55,'BÜZ','BÜtZow','Landkreis Rostock','Mecklenburg-Vorpommern'),
	(809,55,'BW','Bundes-Wasserstraßen- und Schifffahrtsverwaltung','Wasserstraßen- und Schifffahrtsverwaltung des Bundes','bundesweit'),
	(810,55,'BWL','Baden-Württembergischer Landtag','Baden-Württemberg, Landesregierung, Landtag und Polizei','Baden-Württemberg'),
	(811,55,'BYL','BaYerischer Landtag','Bayern, Landesregierung und Landtag','Bayern'),
	(812,55,'BZ','BautZen','Landkreis Bautzen','Sachsen'),
	(813,55,'C','Chemnitz','Stadt Chemnitz','Sachsen'),
	(814,55,'CA','CAlau','Landkreis Oberspreewald-Lausitz','Brandenburg'),
	(815,55,'CAS','CAStrop','Kreis Recklinghausen','Nordrhein-Westfalen'),
	(816,55,'CB','CottBus','Stadt Cottbus','Brandenburg'),
	(817,55,'CE','CElle','Landkreis Celle','Niedersachsen'),
	(818,55,'CHA','CHAm','Landkreis Cham','Bayern'),
	(819,55,'CLP','CLopPenburg','Landkreis Cloppenburg','Niedersachsen'),
	(820,55,'CLZ','CLausthal-Zellerfeld','Landkreis Goslar','Niedersachsen'),
	(821,55,'CO','COburg','Stadt Coburg und Landkreis Coburg','Bayern'),
	(822,55,'COC','COChem','Landkreis Cochem-Zell','Rheinland-Pfalz'),
	(823,55,'COE','COEsfeld','Kreis Coesfeld','Nordrhein-Westfalen'),
	(824,55,'CR','CRailsheim','Landkreis Schwäbisch Hall','Baden-Württemberg'),
	(825,55,'CUX','CUXhaven','Landkreis Cuxhaven','Niedersachsen'),
	(826,55,'CW','CalW','Landkreis Calw','Baden-Württemberg'),
	(827,55,'D','Düsseldorf','Stadt Düsseldorf','Nordrhein-Westfalen'),
	(828,55,'DA','DArmstadt','Landkreis Darmstadt-Dieburg und Stadt Darmstadt','Hessen'),
	(829,55,'DAH','DAcHau','Landkreis Dachau','Bayern'),
	(830,55,'DAN','DANnenberg','Landkreis Lüchow-Dannenberg','Niedersachsen'),
	(831,55,'DAU','DAUn','Landkreis Vulkaneifel','Rheinland-Pfalz'),
	(832,55,'DBR','DoBeRan','Landkreis Rostock','Mecklenburg-Vorpommern'),
	(833,55,'DD','DresDen','Stadt Dresden, Polizei Sachsen (Q 1000–9999)','Sachsen'),
	(834,55,'DE','DEssau','Stadt Dessau-Roßlau','Sachsen-Anhalt'),
	(835,55,'DEG','DEGgendorf','Landkreis Deggendorf','Bayern'),
	(836,55,'DEL','DELmenhorst','Stadt Delmenhorst','Niedersachsen'),
	(837,55,'DGF','DinGolFing','Landkreis Dingolfing-Landau','Bayern'),
	(838,55,'DH','DiepHolz','Landkreis Diepholz','Niedersachsen'),
	(839,55,'DI','DIeburg','Landkreis Darmstadt-Dieburg','Hessen'),
	(840,55,'DIL','DILlenburg','Lahn-Dill-Kreis ohne die Stadt Wetzlar','Hessen'),
	(841,55,'DIN','DINslaken','Kreis Wesel','Nordrhein-Westfalen'),
	(842,55,'DIZ','DIeZ','Rhein-Lahn-Kreis','Rheinland-Pfalz'),
	(843,55,'DKB','DinKelsBühl','Landkreis Ansbach','Bayern'),
	(844,55,'DL','DöbeLn','Landkreis Mittelsachsen','Sachsen'),
	(845,55,'DLG','DilLinGen','Landkreis Dillingen an der Donau','Bayern'),
	(846,55,'DM','DemMin','Landkreis Mecklenburgische Seenplatte ohne die Stadt Neubrandenburg','Mecklenburg-Vorpommern'),
	(847,55,'DN','DüreN','Kreis Düren','Nordrhein-Westfalen'),
	(848,55,'DO','DOrtmund','Stadt Dortmund','Nordrhein-Westfalen'),
	(849,55,'DON','DONauwörth','Landkreis Donau-Ries','Bayern'),
	(850,55,'DU','DUisburg','Stadt Duisburg','Nordrhein-Westfalen'),
	(851,55,'DUD','DUDerstadt','Landkreis Göttingen ohne die Stadt Göttingen','Niedersachsen'),
	(852,55,'DÜW','DÜrkheim an der Weinstraße','Landkreis Bad Dürkheim','Rheinland-Pfalz'),
	(853,55,'DW','DippoldisWalde','Landkreis Sächsische Schweiz-Osterzgebirge','Sachsen'),
	(854,55,'DZ','DelitZsch','Landkreis Nordsachsen','Sachsen'),
	(855,55,'E','Essen','Stadt Essen','Nordrhein-Westfalen'),
	(856,55,'EA','EisenAch','Stadt Eisenach','Thüringen'),
	(857,55,'EB','EilenBurg','Landkreis Nordsachsen','Sachsen'),
	(858,55,'EBE','EBErsberg','Landkreis Ebersberg','Bayern'),
	(859,55,'EBN','EBerN','Landkreis Haßberge','Bayern'),
	(860,55,'EBS','EBermannStadt','Landkreis Forchheim, Landkreis Kulmbach (A–M 1–999), Landkreis Bayreuth (N–Z 1–999)','Bayern'),
	(861,55,'ECK','ECKernförde','Kreis Rendsburg-Eckernförde','Schleswig-Holstein'),
	(862,55,'ED','ErDing','Landkreis Erding','Bayern'),
	(863,55,'EE','Elbe, Elster','Landkreis Elbe-Elster','Brandenburg'),
	(864,55,'EF','ErFurt','Stadt Erfurt','Thüringen'),
	(865,55,'EG','EGgenfelden','Landkreis Rottal-Inn','Bayern'),
	(866,55,'EH','EisenHüttenstadt','Landkreis Oder-Spree','Brandenburg'),
	(867,55,'EI','EIchstätt','Landkreis Eichstätt','Bayern'),
	(868,55,'EIC','EIChsfeld','Landkreis Eichsfeld','Thüringen'),
	(869,55,'EIL','EIsLeben','Landkreis Mansfeld-Südharz','Sachsen-Anhalt'),
	(870,55,'EIN','EINbeck','Landkreis Northeim','Niedersachsen'),
	(871,55,'EIS','EISenberg','Saale-Holzland-Kreis','Thüringen'),
	(872,55,'EL','EmsLand','Landkreis Emsland','Niedersachsen'),
	(873,55,'EM','EMmendingen','Landkreis Emmendingen','Baden-Württemberg'),
	(874,55,'EMD','EMDen','Stadt Emden','Niedersachsen'),
	(875,55,'EMS','EMS','Rhein-Lahn-Kreis','Rheinland-Pfalz'),
	(876,55,'EN','ENnepe','Ennepe-Ruhr-Kreis','Nordrhein-Westfalen'),
	(877,55,'ER','ERlangen','Stadt Erlangen','Bayern'),
	(878,55,'ERB','ERBach','Odenwaldkreis','Hessen'),
	(879,55,'ERH','ERlangen, Höchstadt','Landkreis Erlangen-Höchstadt','Bayern'),
	(880,55,'ERK','ERKelenz','Kreis Heinsberg','Nordrhein-Westfalen'),
	(881,55,'ERZ','ERZgebirge','Erzgebirgskreis','Sachsen'),
	(882,55,'ES','ESslingen','Landkreis Esslingen','Baden-Württemberg'),
	(883,55,'ESB','ESchenBach','Landkreis Neustadt an der Waldnaab, Landkreis Amberg-Sulzbach (B, F, G, I, O und Q 1–999), Landkreis Bayreuth (AT, BT, CT, DT, ... YT und ZT 1–99), Landkreis Nürnberger Land (N 1–999)','Bayern'),
	(884,55,'ESW','ESchWege','Werra-Meißner-Kreis','Hessen'),
	(885,55,'EU','EUskirchen','Kreis Euskirchen','Nordrhein-Westfalen'),
	(886,55,'EW','EbersWalde','Landkreis Barnim','Brandenburg'),
	(887,55,'F','Frankfurt','Stadt Frankfurt am Main','Hessen'),
	(888,55,'FB','FriedBerg','Wetteraukreis','Hessen'),
	(889,55,'FD','FulDa','Landkreis Fulda','Hessen'),
	(890,55,'FDB','FrieDBerg','Landkreis Aichach-Friedberg','Bayern'),
	(891,55,'FDS','FreuDenStadt','Landkreis Freudenstadt','Baden-Württemberg'),
	(892,55,'FEU','FEUchtwangen','Landkreis Ansbach','Bayern'),
	(893,55,'FF','FrankFurt','Stadt Frankfurt (Oder)','Brandenburg'),
	(894,55,'FFB','FürstenFeldBruck','Landkreis Fürstenfeldbruck','Bayern'),
	(895,55,'FG','FreiberG','Landkreis Mittelsachsen','Sachsen'),
	(896,55,'FI','FInsterwalde','Landkreis Elbe-Elster','Brandenburg'),
	(897,55,'FKB','FranKenBerg','Landkreis Waldeck-Frankenberg','Hessen'),
	(898,55,'FL','FLensburg','Stadt Flensburg','Schleswig-Holstein'),
	(899,55,'FLÖ','FLÖha','Landkreis Mittelsachsen','Sachsen'),
	(900,55,'FN','FriedrichshafeN','Bodenseekreis','Baden-Württemberg'),
	(901,55,'FO','FOrchheim','Landkreis Forchheim','Bayern'),
	(902,55,'FOR','FORst','Landkreis Spree-Neiße','Brandenburg'),
	(903,55,'FR','FReiburg','Landkreis Breisgau-Hochschwarzwald, Stadt Freiburg im Breisgau (AA–MZ 100–999 und NA–ZZ 100–9999)','Baden-Württemberg'),
	(904,55,'FRG','FReyung, Grafenau','Landkreis Freyung-Grafenau','Bayern'),
	(905,55,'FRI','FRIesland','Landkreis Friesland','Niedersachsen'),
	(906,55,'FRW','FReienWalde','Landkreis Märkisch-Oderland','Brandenburg'),
	(907,55,'FS','FreiSing','Landkreis Freising','Bayern'),
	(908,55,'FT','FrankenThal','Stadt Frankenthal (Pfalz)','Rheinland-Pfalz'),
	(909,55,'FTL','FreiTaL','Landkreis Sächsische Schweiz-Osterzgebirge','Sachsen'),
	(910,55,'FÜ','FÜrth','Landkreis Fürth, Stadt Fürth (AA–ZZ 100–999)','Bayern'),
	(911,55,'FÜS','FÜSsen','Landkreis Ostallgäu','Bayern'),
	(912,55,'FW','FürstenWalde','Landkreis Oder-Spree','Brandenburg'),
	(913,55,'FZ','FritZlar','Schwalm-Eder-Kreis','Hessen'),
	(914,55,'G','Gera','Stadt Gera','Thüringen'),
	(915,55,'GA','GArdelegen','Altmarkkreis Salzwedel','Sachsen-Anhalt'),
	(916,55,'GAN','GANdersheim','Landkreis Northeim','Niedersachsen'),
	(917,55,'GAP','GArmisch-Partenkirchen','Landkreis Garmisch-Partenkirchen','Bayern'),
	(918,55,'GC','GlauChau','Landkreis Zwickau','Sachsen'),
	(919,55,'GD','GmünD','Ostalbkreis','Baden-Württemberg'),
	(920,55,'GDB','GaDeBusch','Landkreis Nordwestmecklenburg','Mecklenburg-Vorpommern'),
	(921,55,'GE','GElsenkirchen','Stadt Gelsenkirchen','Nordrhein-Westfalen'),
	(922,55,'GEL','GELdern','Kreis Kleve','Nordrhein-Westfalen'),
	(923,55,'GEO','GErOlzhofen','Landkreis Schweinfurt, Landkreis Haßberge (A und B 1000–9999)','Bayern'),
	(924,55,'GER','GERmersheim','Landkreis Germersheim','Rheinland-Pfalz'),
	(925,55,'GF','GiFhorn','Landkreis Gifhorn','Niedersachsen'),
	(926,55,'GG','Groß-Gerau','Kreis Groß-Gerau','Hessen'),
	(927,55,'GHA','GeitHAin','Landkreis Leipzig','Sachsen'),
	(928,55,'GHC','GräfenHainiChen','Landkreis Wittenberg','Sachsen-Anhalt'),
	(929,55,'GI','GIeßen','Landkreis Gießen','Hessen'),
	(930,55,'GK','GeilenKirchen','Kreis Heinsberg','Nordrhein-Westfalen'),
	(931,55,'GL','GLadbach','Rheinisch-Bergischer Kreis','Nordrhein-Westfalen'),
	(932,55,'GLA','GLAdbeck','Kreis Recklinghausen','Nordrhein-Westfalen'),
	(933,55,'GM','GumMersbach','Oberbergischer Kreis','Nordrhein-Westfalen'),
	(934,55,'GMN','GrimMeN','Landkreis Vorpommern-Rügen ohne die Stadt Stralsund','Mecklenburg-Vorpommern'),
	(935,55,'GN','GelnhauseN','Main-Kinzig-Kreis ohne die Stadt Hanau','Hessen'),
	(936,55,'GNT','GeNThin','Landkreis Jerichower Land','Sachsen-Anhalt'),
	(937,55,'GÖ','GÖttingen','Landkreis Göttingen, Stadt Göttingen','Niedersachsen'),
	(938,55,'GOA','GOAr','Rhein-Hunsrück-Kreis','Rheinland-Pfalz'),
	(939,55,'GOH','GOarsHausen','Rhein-Lahn-Kreis','Rheinland-Pfalz'),
	(940,55,'GP','GöpPingen','Landkreis Göppingen','Baden-Württemberg'),
	(941,55,'GR','GöRlitz','Landkreis Görlitz','Sachsen'),
	(942,55,'GRA','GRAfenau','Landkreis Freyung-Grafenau','Bayern'),
	(943,55,'GRH','GRoßenHain','Landkreis Meißen','Sachsen'),
	(944,55,'GRI','GRIesbach','Landkreis Rottal-Inn (B, I, O und Q 100–999)','Bayern'),
	(945,55,'GRM','GRimMa','Landkreis Leipzig','Sachsen'),
	(946,55,'GRZ','GReiZ','Landkreis Greiz','Thüringen'),
	(947,55,'GS','GoSlar','Landkreis Goslar','Niedersachsen'),
	(948,55,'GT','GüTersloh','Kreis Gütersloh','Nordrhein-Westfalen'),
	(949,55,'GTH','GoTHa','Landkreis Gotha','Thüringen'),
	(950,55,'GÜ','GÜstrow','Landkreis Rostock','Mecklenburg-Vorpommern'),
	(951,55,'GUB','GUBen','Landkreis Spree-Neiße','Brandenburg'),
	(952,55,'GUN','GUNzenhausen','Landkreis Weißenburg-Gunzenhausen','Bayern'),
	(953,55,'GV','GreVenbroich','Rhein-Kreis Neuss','Nordrhein-Westfalen'),
	(954,55,'GVM','GreVesMühlen','Landkreis Nordwestmecklenburg','Mecklenburg-Vorpommern'),
	(955,55,'GW','GreifsWald','Landkreis Vorpommern-Greifswald ohne die Stadt Greifswald','Mecklenburg-Vorpommern'),
	(956,55,'GZ','GünZburg','Landkreis Günzburg','Bayern'),
	(957,55,'H','Hannover','Region Hannover','Niedersachsen'),
	(958,55,'HA','HAgen','Stadt Hagen','Nordrhein-Westfalen'),
	(959,55,'HAB','HAmmelBurg','Landkreis Bad Kissingen','Bayern'),
	(960,55,'HAL','HALle','Stadt Halle (Saale)','Sachsen-Anhalt'),
	(961,55,'HAM','HAMm','Stadt Hamm','Nordrhein-Westfalen'),
	(962,55,'HAS','HASsfurt','Landkreis Haßberge','Bayern'),
	(963,55,'HB','Hansestadt Bremen','Stadt Bremen, Senat und Bürgerschaft, Stadt Bremerhaven (A–Z 1000–9999)','Bremen'),
	(964,55,'HBN','HildBurghauseN','Landkreis Hildburghausen','Thüringen'),
	(965,55,'HBS','HalBerStadt','Landkreis Harz','Sachsen-Anhalt'),
	(966,55,'HC','HainiChen','Landkreis Mittelsachsen','Sachsen'),
	(967,55,'HCH','HeCHingen','Zollernalbkreis, Landkreis Freudenstadt (YQ, QY, YV, VY und ZQ 100 bis 999)','Baden-Württemberg'),
	(968,55,'HD','HeiDelberg','Stadt Heidelberg, Rhein-Neckar-Kreis (AA–ZZ 100–9999)','Baden-Württemberg'),
	(969,55,'HDH','HeiDenHeim','Landkreis Heidenheim','Baden-Württemberg'),
	(970,55,'HDL','HalDensLeben','Landkreis Börde','Sachsen-Anhalt'),
	(971,55,'HE','HElmstedt','Landkreis Helmstedt','Niedersachsen'),
	(972,55,'HEB','HErsBruck','Landkreis Nürnberger Land','Bayern'),
	(973,55,'HEF','HErsFeld','Landkreis Hersfeld-Rotenburg','Hessen'),
	(974,55,'HEI','HEIde','Kreis Dithmarschen','Schleswig-Holstein'),
	(975,55,'HEL','HEssischer Landtag','Hessen, Landesregierung und Landtag','Hessen'),
	(976,55,'HER','HERne','Stadt Herne','Nordrhein-Westfalen'),
	(977,55,'HET','HETtstedt','Landkreis Mansfeld-Südharz','Sachsen-Anhalt'),
	(978,55,'HF','HerFord','Kreis Herford','Nordrhein-Westfalen'),
	(979,55,'HG','HomburG','Hochtaunuskreis','Hessen'),
	(980,55,'HGN','HaGeNow','Landkreis Ludwigslust-Parchim','Mecklenburg-Vorpommern'),
	(981,55,'HGW','Hansestadt GreifsWald','Stadt Greifswald (große kreisangehörige Stadt im Landkreis Vorpommern-Greifswald)','Mecklenburg-Vorpommern'),
	(982,55,'HH','Hansestadt Hamburg','Freie und Hansestadt Hamburg, Senat und Bürgerschaft','Hamburg'),
	(983,55,'HHM','HoHenMölsen','Burgenlandkreis','Sachsen-Anhalt'),
	(984,55,'HI','HIldesheim','Landkreis Hildesheim','Niedersachsen'),
	(985,55,'HIG','HeilIGenstadt','Landkreis Eichsfeld','Thüringen'),
	(986,55,'HIP','HIlPoltstein','Landkreis Roth','Bayern'),
	(987,55,'HK','HeideKreis','Landkreis Heidekreis','Niedersachsen'),
	(988,55,'HL','Hansestadt Lübeck','Stadt Lübeck','Schleswig-Holstein'),
	(989,55,'HM','HaMeln','Landkreis Hameln-Pyrmont','Niedersachsen'),
	(990,55,'HMÜ','Hann. MÜnden','Landkreis Göttingen ohne die Stadt Göttingen','Niedersachsen'),
	(991,55,'HN','HeilbronN','Stadt Heilbronn, Landkreis Heilbronn (AA–MZ 100–9999 und NA–ZZ 100–999)','Baden-Württemberg'),
	(992,55,'HO','HOf','Stadt Hof, Landkreis Hof (AA–ZZ 100–9999)','Bayern'),
	(993,55,'HOG','HOfGeismar','Landkreis Kassel','Hessen'),
	(994,55,'HOH','HOfHeim','Landkreis Haßberge','Bayern'),
	(995,55,'HOL','HOLzminden','Landkreis Holzminden','Niedersachsen'),
	(996,55,'HOM','HOMburg','Saarpfalz-Kreis ohne die Stadt St. Ingbert','Saarland'),
	(997,55,'HOR','HORb','Landkreis Freudenstadt','Baden-Württemberg'),
	(998,55,'HÖS','HÖchStadt','Landkreis Erlangen-Höchstadt','Bayern'),
	(999,55,'HOT','HOhensTein','Landkreis Zwickau','Sachsen'),
	(1000,55,'HP','HepPenheim','Kreis Bergstraße','Hessen'),
	(1001,55,'HR','HombeRg','Schwalm-Eder-Kreis','Hessen'),
	(1002,55,'HRO','Hansestadt ROstock','Stadt Rostock','Mecklenburg-Vorpommern'),
	(1003,55,'HS','HeinSberg','Kreis Heinsberg','Nordrhein-Westfalen'),
	(1004,55,'HSK','HochSauerlandKreis','Hochsauerlandkreis','Nordrhein-Westfalen'),
	(1005,55,'HST','Hansestadt STralsund','Stadt Stralsund (große kreisangehörige Stadt im Landkreis Vorpommern-Rügen)','Mecklenburg-Vorpommern'),
	(1006,55,'HU','HanaU','Stadt Hanau (Sonderstatusstadt im Main-Kinzig-Kreis), Main-Kinzig-Kreis (übriges Kreisgebiet)','Hessen'),
	(1007,55,'HV','HaVelberg','Landkreis Stendal','Sachsen-Anhalt'),
	(1008,55,'HVL','HaVelLand','Landkreis Havelland','Brandenburg'),
	(1009,55,'HWI','Hansestadt WIsmar','Stadt Wismar (große kreisangehörige Stadt im Landkreis Nordwestmecklenburg)','Mecklenburg-Vorpommern'),
	(1010,55,'HX','HöXter','Kreis Höxter','Nordrhein-Westfalen'),
	(1011,55,'HY','HoYerswerda','Landkreis Bautzen','Sachsen'),
	(1012,55,'HZ','HarZ','Landkreis Harz','Sachsen-Anhalt'),
	(1013,55,'IGB','InGBert','Stadt St. Ingbert (Mittelstadt im Saarpfalz-Kreis)','Saarland'),
	(1014,55,'IK','Ilm-Kreis','Ilm-Kreis','Thüringen'),
	(1015,55,'IL','ILmenau','Ilm-Kreis','Thüringen'),
	(1016,55,'ILL','ILLertissen','Landkreis Neu-Ulm','Bayern'),
	(1017,55,'IN','INgolstadt','Stadt Ingolstadt','Bayern'),
	(1018,55,'IZ','ItZehoe','Kreis Steinburg','Schleswig-Holstein'),
	(1019,55,'J','Jena','Stadt Jena','Thüringen'),
	(1020,55,'JE','JEssen','Landkreis Wittenberg','Sachsen-Anhalt'),
	(1021,55,'JL','Jerichower Land','Landkreis Jerichower Land','Sachsen-Anhalt'),
	(1022,55,'JÜL','JÜLich','Kreis Düren','Nordrhein-Westfalen'),
	(1023,55,'K','Köln','Stadt Köln','Nordrhein-Westfalen'),
	(1024,55,'KA','KArlsruhe','Landkreis Karlsruhe, Stadt Karlsruhe (AA–MZ 100–999 und NA–ZZ 100–9999)','Baden-Württemberg'),
	(1025,55,'KB','KorBach','Landkreis Waldeck-Frankenberg','Hessen'),
	(1026,55,'KC','KronaCh','Landkreis Kronach','Bayern'),
	(1027,55,'KE','KEmpten','Stadt Kempten (Allgäu)','Bayern'),
	(1028,55,'KEH','KElHeim','Landkreis Kelheim','Bayern'),
	(1029,55,'KEL','KEhL','Ortenaukreis','Baden-Württemberg'),
	(1030,55,'KEM','KEMnath','Landkreis Tirschenreuth, Landkreis Bayreuth (AT, BT, CT, DT, ... YT und ZT 1–99)','Bayern'),
	(1031,55,'KF','KauFbeuren','Stadt Kaufbeuren','Bayern'),
	(1032,55,'KG','KissinGen','Landkreis Bad Kissingen','Bayern'),
	(1033,55,'KH','KreuznacH','Landkreis Bad Kreuznach','Rheinland-Pfalz'),
	(1034,55,'KI','KIel','Stadt Kiel','Schleswig-Holstein'),
	(1035,55,'KIB','KIrchheimBolanden','Donnersbergkreis','Rheinland-Pfalz'),
	(1036,55,'KK','Kempen, Krefeld','Kreis Viersen','Nordrhein-Westfalen'),
	(1037,55,'KL','KaisersLautern','Stadt Kaiserslautern, Landkreis Kaiserslautern (AA–ZZ 100–999)','Rheinland-Pfalz'),
	(1038,55,'KLE','KLEve','Kreis Kleve','Nordrhein-Westfalen'),
	(1039,55,'KLZ','KLötZe','Altmarkkreis Salzwedel','Sachsen-Anhalt'),
	(1040,55,'KM','KaMenz','Landkreis Bautzen','Sachsen'),
	(1041,55,'KN','KoNstanz','Landkreis Konstanz ohne die Gemeinde Büsingen am Hochrhein','Baden-Württemberg'),
	(1042,55,'KO','KOblenz','Stadt Koblenz','Rheinland-Pfalz'),
	(1043,55,'KÖN','KÖNigshofen','Landkreis Rhön-Grabfeld','Bayern'),
	(1044,55,'KÖT','KÖThen','Landkreis Anhalt-Bitterfeld','Sachsen-Anhalt'),
	(1045,55,'KÖZ','KÖtZting','Landkreis Cham','Bayern'),
	(1046,55,'KR','KRefeld','Stadt Krefeld','Nordrhein-Westfalen'),
	(1047,55,'KRU','KRUmbach','Landkreis Günzburg','Bayern'),
	(1048,55,'KS','KasSel','Landkreis Kassel und Stadt Kassel','Hessen'),
	(1049,55,'KT','KiTzingen','Landkreis Kitzingen','Bayern'),
	(1050,55,'KU','KUlmbach','Landkreis Kulmbach','Bayern'),
	(1051,55,'KÜN','KÜNzelsau','Hohenlohekreis','Baden-Württemberg'),
	(1052,55,'KUS','KUSel','Landkreis Kusel','Rheinland-Pfalz'),
	(1053,55,'KW','Königs Wusterhausen','Landkreis Dahme-Spreewald','Brandenburg'),
	(1054,55,'KY','KYritz','Landkreis Ostprignitz-Ruppin','Brandenburg'),
	(1055,55,'KYF','KYFfhäuser','Kyffhäuserkreis','Thüringen'),
	(1056,55,'L','Leipzig','Sachsen','Stadt Leipzig (A–T und AA–TZ), Landkreis Leipzig (U–Z und UA–ZZ)'),
	(1057,55,'LA','LAndshut','Stadt Landshut, Landkreis Landshut (AA–ZZ 100–999 und 5000–9999)','Bayern'),
	(1058,55,'LAN','LANdau','Landkreis Dingolfing-Landau','Bayern'),
	(1059,55,'LAU','LAUf','Landkreis Nürnberger Land','Bayern'),
	(1060,55,'LB','LudwigsBurg','Landkreis Ludwigsburg','Baden-Württemberg'),
	(1061,55,'LBS','LoBenStein','Saale-Orla-Kreis','Thüringen'),
	(1062,55,'LBZ','LüBZ','Landkreis Ludwigslust-Parchim','Mecklenburg-Vorpommern'),
	(1063,55,'LC','LuCkau','Landkreis Dahme-Spreewald','Brandenburg'),
	(1064,55,'LD','LanDau','Stadt Landau in der Pfalz','Rheinland-Pfalz'),
	(1065,55,'LDK','Lahn-Dill-Kreis','Lahn-Dill-Kreis ohne die Stadt Wetzlar','Hessen'),
	(1066,55,'LDS','Landkreis Dahme-Spreewald','Landkreis Dahme-Spreewald','Brandenburg'),
	(1067,55,'LEO','LEOnberg','Landkreis Böblingen','Baden-Württemberg'),
	(1068,55,'LER','LEeR','Landkreis Leer','Niedersachsen'),
	(1069,55,'LEV','LEVerkusen','Stadt Leverkusen','Nordrhein-Westfalen'),
	(1070,55,'LF','LauFen','Landkreis Berchtesgadener Land, Landkreis Altötting (C 1–999, E 1–500, I, J, M, O, Q und V 1–999), Landkreis Traunstein (B, F und G 1–999, DH 1–100, FZ, GH und KQ 1–999, LU 1–200, RW 1–999, TK 1–100, TS 1–999, VW 200–400 sowie WW, XX und ZZ 1–999)','Bayern'),
	(1071,55,'LG','LüneburG','Landkreis Lüneburg','Niedersachsen'),
	(1072,55,'LH','LüdingHausen','Kreis Coesfeld, Kreis Unna','Nordrhein-Westfalen'),
	(1073,55,'LI','LIndau','Landkreis Lindau (Bodensee)','Bayern'),
	(1074,55,'LIB','LIeBenwerda','Landkreis Elbe-Elster','Brandenburg'),
	(1075,55,'LIF','LIchtenFels','Landkreis Lichtenfels','Bayern'),
	(1076,55,'LIP','LIPpe','Kreis Lippe','Nordrhein-Westfalen'),
	(1077,55,'LL','Landsberg am Lech','Landkreis Landsberg am Lech','Bayern'),
	(1078,55,'LM','LiMburg','Landkreis Limburg-Weilburg','Hessen'),
	(1079,55,'LN','LübbeN','Landkreis Dahme-Spreewald','Brandenburg'),
	(1080,55,'LÖ','LÖrrach','Landkreis Lörrach','Baden-Württemberg'),
	(1081,55,'LÖB','LÖBau','Landkreis Görlitz','Sachsen'),
	(1082,55,'LOS','Landkreis Oder-Spre','Landkreis Oder-Spree','Brandenburg'),
	(1083,55,'LP','LiPpstadt','Kreis Soest','Nordrhein-Westfalen'),
	(1084,55,'LR','LahR','Ortenaukreis','Baden-Württemberg'),
	(1085,55,'LRO','Landkreis ROstock','Landkreis Rostock','Mecklenburg-Vorpommern'),
	(1086,55,'LSA','Land Sachsen-Anhalt','Sachsen-Anhalt, Landesregierung, Landtag und Polizei','Sachsen-Anhalt'),
	(1087,55,'LSN','Landtag SachseN','Sachsen, Landesregierung und Landtag','Sachsen'),
	(1088,55,'LSZ','LangenSalZa','Unstrut-Hainich-Kreis','Thüringen'),
	(1089,55,'LU','LUdwigshafen','Stadt Ludwigshafen am Rhein','Rheinland-Pfalz'),
	(1090,55,'LÜN','LÜNen','Kreis Unna','Nordrhein-Westfalen'),
	(1091,55,'LUP','LUdwigslust, Parchim','Landkreis Ludwigslust-Parchim','Mecklenburg-Vorpommern'),
	(1092,55,'LWL','LudWigsLust','Landkreis Ludwigslust-Parchim','Mecklenburg-Vorpommern'),
	(1093,55,'M','München','Landkreis München, Stadt München (AA–ZZ 100–9999)','Bayern'),
	(1094,55,'MA','MAnnheim','Stadt Mannheim','Baden-Württemberg'),
	(1095,55,'MAB','MArienBerg','Erzgebirgskreis','Sachsen'),
	(1096,55,'MAI','MAInburg','Landkreis Kelheim, Landkreis Landshut (B, F, G, I, O und Q 1–9999)','Bayern'),
	(1097,55,'MAK','MArKtredwitz','Landkreis Wunsiedel im Fichtelgebirge','Bayern'),
	(1098,55,'MAL','MALlersdorf','Landkreis Landshut (B, F, G, I, O und Q 1–9999)','Bayern'),
	(1099,55,'MB','MiesBach','Landkreis Miesbach','Bayern'),
	(1100,55,'MC','MalChin','Landkreis Mecklenburgische Seenplatte ohne die Stadt Neubrandenburg','Mecklenburg-Vorpommern'),
	(1101,55,'MD','MagDeburg','Stadt Magdeburg','Sachsen-Anhalt'),
	(1102,55,'ME','MEttmann','Kreis Mettmann','Nordrhein-Westfalen'),
	(1103,55,'MED','MElDorf','Kreis Dithmarschen','Schleswig-Holstein'),
	(1104,55,'MEG','MElsunGen','Schwalm-Eder-Kreis','Hessen'),
	(1105,55,'MEI','MEIßen','Landkreis Meißen','Sachsen'),
	(1106,55,'MEK','Mittlerer ErzgebirgsKreis','Erzgebirgskreis','Sachsen'),
	(1107,55,'MEL','MELle','Landkreis Osnabrück','Niedersachsen'),
	(1108,55,'MER','MERseburg','Saalekreis','Sachsen-Anhalt'),
	(1109,55,'MET','MEllrichstadT','Landkreis Rhön-Grabfeld','Bayern'),
	(1110,55,'MG','MönchenGladbach','Stadt Mönchengladbach','Nordrhein-Westfalen'),
	(1111,55,'MGH','MerGentHeim','Main-Tauber-Kreis','Baden-Württemberg'),
	(1112,55,'MGN','MeininGeN','Landkreis Schmalkalden-Meiningen','Thüringen'),
	(1113,55,'MH','MülHeim','Stadt Mülheim an der Ruhr','Nordrhein-Westfalen'),
	(1114,55,'MHL','MüHLhausen','Unstrut-Hainich-Kreis','Thüringen'),
	(1115,55,'MI','MInden','Kreis Minden-Lübbecke','Nordrhein-Westfalen'),
	(1116,55,'MIL','MILtenberg','Landkreis Miltenberg','Bayern'),
	(1117,55,'MK','Märkischer Kreis','Märkischer Kreis','Nordrhein-Westfalen'),
	(1118,55,'MKK','Main-Kinzig-Kreis','Main-Kinzig-Kreis ohne die Stadt Hanau','Hessen'),
	(1119,55,'ML','Mansfelder Land','Landkreis Mansfeld-Südharz','Sachsen-Anhalt'),
	(1120,55,'MM','MemMingen','Stadt Memmingen','Bayern'),
	(1121,55,'MN','MiNdelheim','Landkreis Unterallgäu','Bayern'),
	(1122,55,'MO','MOers','Kreis Wesel','Nordrhein-Westfalen'),
	(1123,55,'MOD','MarktOberDorf','Landkreis Ostallgäu','Bayern'),
	(1124,55,'MOL','Märkisch-OderLand','Landkreis Märkisch-Oderland','Brandenburg'),
	(1125,55,'MON','MONschau','Städteregion Aachen, Kreis Düren','Nordrhein-Westfalen'),
	(1126,55,'MOS','MONschau','Neckar-Odenwald-Kreis','Baden-Württemberg'),
	(1127,55,'MQ','Merseburg, Querfurt','Saalekreis','Sachsen-Anhalt'),
	(1128,55,'MR','MaRburg','Landkreis Marburg-Biedenkopf','Hessen'),
	(1129,55,'MS','MünSter','Stadt Münster','Nordrhein-Westfalen'),
	(1130,55,'MSE','Mecklenburgische SEenplatte','Landkreis Mecklenburgische Seenplatte ohne die Stadt Neubrandenburg','Mecklenburg-Vorpommern'),
	(1131,55,'MSH','Mansfeld, SüdHarz','Landkreis Mansfeld-Südharz','Sachsen-Anhalt'),
	(1132,55,'MSP','Main, SPessart','Landkreis Main-Spessart','Bayern'),
	(1133,55,'MST','Mecklenburg-STrelitz','Landkreis Mecklenburgische Seenplatte ohne die Stadt Neubrandenburg','Mecklenburg-Vorpommern'),
	(1134,55,'MTK','Main-Taunus-Kreis','Main-Taunus-Kreis','Hessen'),
	(1135,55,'MTL','MuldenTaL','Landkreis Leipzig','Sachsen'),
	(1136,55,'MÜ','MÜhldorf','Landkreis Mühldorf am Inn','Bayern'),
	(1137,55,'MÜB','MÜnchBerg','Landkreis Hof, Landkreis Bayreuth (A–M 100–999 und N–Z 1–99)','Bayern'),
	(1138,55,'MÜR','MÜRitz','Landkreis Mecklenburgische Seenplatte ohne die Stadt Neubrandenburg','Mecklenburg-Vorpommern'),
	(1139,55,'MVL','Mecklenburg-Vorpommerscher Landtag','Mecklenburg-Vorpommern, Landesregierung, Landtag und Polizei','Mecklenburg-Vorpommern'),
	(1140,55,'MW','MittWeida','Landkreis Mittelsachsen','Sachsen'),
	(1141,55,'MY','MaYen','Landkreis Mayen-Koblenz','Rheinland-Pfalz'),
	(1142,55,'MYK','MaYen, Koblenz','Landkreis Mayen-Koblenz','Rheinland-Pfalz'),
	(1143,55,'MZ','MainZ','Landkreis Mainz-Bingen, Stadt Mainz (AA–KY 100–9999 und LA–ZZ 100–999)','Rheinland-Pfalz'),
	(1144,55,'MZG','MerZiG','Landkreis Merzig-Wadern','Saarland'),
	(1145,55,'N','Nürnberg','Landkreis Nürnberger Land (A–Z 1–999), Stadt Nürnberg (A–Z 1000–9999 und AA–ZZ 100–9999)','Bayern'),
	(1146,55,'NAB','NABburg','Landkreis Schwandorf, Landkreis Amberg-Sulzbach (B, F und G 1–999)','Bayern'),
	(1147,55,'NAI','NAIla','Landkreis Hof','Bayern'),
	(1148,55,'NAU','NAUen','Landkreis Havelland','Brandenburg'),
	(1149,55,'NB','NeuBrandenburg','Stadt Neubrandenburg (große kreisangehörige Stadt im Landkreis Mecklenburgische Seenplatte)','Mecklenburg-Vorpommern'),
	(1150,55,'ND','Neuburg an der Donau','Landkreis Neuburg-Schrobenhausen','Bayern'),
	(1151,55,'NDH','NorDHausen','Landkreis Nordhausen','Thüringen'),
	(1152,55,'NE','NEuss','Rhein-Kreis Neuss','Nordrhein-Westfalen'),
	(1153,55,'NEA','NEustadt an der Aisch','Landkreis Neustadt an der Aisch-Bad Windsheim','Bayern'),
	(1154,55,'NEB','NEBra','Burgenlandkreis','Sachsen-Anhalt'),
	(1155,55,'NEC','NEustadt bei Coburg','Stadt Coburg und Landkreis Coburg','Bayern'),
	(1156,55,'NEN','NEuNburg','Landkreis Schwandorf','Bayern'),
	(1157,55,'NES','NEustadt an der Saale','Landkreis Rhön-Grabfeld','Bayern'),
	(1158,55,'NEW','NEustadt an der Waldnaab','Landkreis Neustadt an der Waldnaab','Bayern'),
	(1159,55,'NF','NordFriesland','Kreis Nordfriesland','Schleswig-Holstein'),
	(1160,55,'NH','NeuHaus','Landkreis Sonneberg','Thüringen'),
	(1161,55,'NI','NIenburg','Landkreis Nienburg/Weser','Niedersachsen'),
	(1162,55,'NK','NeunKirchen','Landkreis Neunkirchen','Saarland'),
	(1163,55,'NL','Niedersächsischer Landtag','Niedersachsen, Landesregierung und Landtag','Niedersachsen'),
	(1164,55,'NM','NeuMarkt','Landkreis Neumarkt in der Oberpfalz','Bayern'),
	(1165,55,'NMB','NauMBurg','Burgenlandkreis','Sachsen-Anhalt'),
	(1166,55,'NMS','NeuMünSter','Stadt Neumünster','Schleswig-Holstein'),
	(1167,55,'NÖ','NÖrdlingen','Landkreis Donau-Ries','Bayern'),
	(1168,55,'NOH','NOrdHorn','Landkreis Grafschaft Bentheim','Niedersachsen'),
	(1169,55,'NOL','Niederschlesische OberLausitz','Landkreis Görlitz','Sachsen'),
	(1170,55,'NOM','NOrtheiM','Landkreis Northeim','Niedersachsen'),
	(1171,55,'NOR','NORden','Landkreis Aurich','Niedersachsen'),
	(1172,55,'NP','NeurupPin','Landkreis Ostprignitz-Ruppin','Brandenburg'),
	(1173,55,'NR','Neuwied am Rhein','Landkreis Neuwied','Rheinland-Pfalz'),
	(1174,55,'NRW','NordRhein-Westfalen','Nordrhein-Westfalen, Landesregierung, Landtag und Polizei','Nordrhein-Westfalen'),
	(1175,55,'NT','NürTingen','Landkreis Esslingen','Baden-Württemberg'),
	(1176,55,'NU','Neu-Ulm','Landkreis Neu-Ulm','Bayern'),
	(1177,55,'NVP','NordVorPommern','Landkreis Vorpommern-Rügen ohne die Stadt Stralsund','Mecklenburg-Vorpommern'),
	(1178,55,'NW','Neustadt an der Weinstraße','Stadt Neustadt an der Weinstraße','Rheinland-Pfalz'),
	(1179,55,'NWM','NordWestMecklenburg','Landkreis Nordwestmecklenburg ohne die Stadt Wismar','Mecklenburg-Vorpommern'),
	(1180,55,'NY','NieskY','Landkreis Görlitz','Sachsen'),
	(1181,55,'NZ','NeustrelitZ','Landkreis Mecklenburgische Seenplatte ohne die Stadt Neubrandenburg','Mecklenburg-Vorpommern'),
	(1182,55,'OA','OberAllgäu','Landkreis Oberallgäu,','Bayern'),
	(1183,55,'OAL','OstALlgäu','Landkreis Ostallgäu','Bayern'),
	(1184,55,'OB','OBerhausen','Stadt Oberhausen','Nordrhein-Westfalen'),
	(1185,55,'OBB','OBernBurg','Landkreis Miltenberg','Bayern'),
	(1186,55,'OBG','OsterBurG','Landkreis Stendal','Sachsen-Anhalt'),
	(1187,55,'OC','OsChersleben','Landkreis Börde','Sachsen-Anhalt'),
	(1188,55,'OCH','OCHsenfurt','Landkreis Würzburg','Bayern'),
	(1189,55,'OD','OlDesloe','Kreis Stormarn','Schleswig-Holstein'),
	(1190,55,'OE','OlpE','Kreis Olpe','Nordrhein-Westfalen'),
	(1191,55,'OF','OFfenbach','Landkreis Offenbach und Stadt Offenbach am Main','Hessen'),
	(1192,55,'OG','OffenburG','Ortenaukreis','Baden-Württemberg'),
	(1193,55,'OH','OstHolstein','Kreis Ostholstein','Schleswig-Holstein'),
	(1194,55,'OHA','Osterode am HArz','Landkreis Göttingen','Niedersachsen'),
	(1195,55,'ÖHR','ÖHRingen','Hohenlohekreis','Baden-Württemberg'),
	(1196,55,'OHV','OberHaVel','Landkreis Oberhavel','Brandenburg'),
	(1197,55,'OHZ','OsterHolZ','Landkreis Osterholz','Niedersachsen'),
	(1198,55,'OK','OhreKreis','Landkreis Börde','Sachsen-Anhalt'),
	(1199,55,'OL','OLdenburg','Landkreis Oldenburg, Stadt Oldenburg (AA–ZZ 100–999)','Niedersachsen'),
	(1200,55,'OP','OPladen','Stadt Leverkusen','Nordrhein-Westfalen'),
	(1201,55,'OPR','OstPrignitz, Ruppin','Landkreis Ostprignitz-Ruppin','Brandenburg'),
	(1202,55,'OS','OSnabrück','Stadt Osnabrück, Landkreis Osnabrück (AA–ZZ 100–999)','Niedersachsen'),
	(1203,55,'OSL','OberSpreewald, Lausitz','Landkreis Oberspreewald-Lausitz','Brandenburg'),
	(1204,55,'OTW','OTtWeiler','Landkreis Ottweiler','Saarland'),
	(1205,55,'OVI','OberVIechtach','Landkreis Schwandorf','Bayern'),
	(1206,55,'OVL','OberVogtLand','Vogtlandkreis','Sachsen'),
	(1207,55,'OVP','OstVorPommern','Landkreis Ostvorpommern','Mecklenburg-Vorpommern'),
	(1208,55,'OZ','OschatZ','Landkreis Nordsachsen','Sachsen'),
	(1209,55,'P','Potsdam','Stadt Potsdam','Brandenburg'),
	(1210,55,'PA','PAssau','Stadt Passau (A–Z 1–9999), Landkreis Passau (AA–ZZ 1–999)','Bayern'),
	(1211,55,'PAF','PfAFfenhofen','Landkreis Pfaffenhofen an der Ilm','Bayern'),
	(1212,55,'PAN','PfArrkircheN','Landkreis Rottal-Inn','Bayern'),
	(1213,55,'PAR','PARsberg','Landkreis Neumarkt in der Oberpfalz, Landkreis Kelheim (Q, Y, BB und CC 1–999)','Bayern'),
	(1214,55,'PB','PaderBorn','Kreis Paderborn','Nordrhein-Westfalen'),
	(1215,55,'PCH','ParCHim','Landkreis Ludwigslust-Parchim','Mecklenburg-Vorpommern'),
	(1216,55,'PE','PEine','Landkreis Peine','Niedersachsen'),
	(1217,55,'PEG','PEGnitz','Landkreis Forchheim, Landkreis Nürnberger Land (A 1–999), Landkreis Bayreuth (B–Z 1–999)','Bayern'),
	(1218,55,'PF','PForzheim','Enzkreis, Stadt Pforzheim (AA–MZ 100–999 und NA–ZZ 100–9999)','Baden-Württemberg'),
	(1219,55,'PI','PInneberg','Kreis Pinneberg','Schleswig-Holstein'),
	(1220,55,'PIR','PIRna','Landkreis Sächsische Schweiz-Osterzgebirge','Sachsen'),
	(1221,55,'PL','PLauen','Vogtlandkreis','Sachsen'),
	(1222,55,'PLÖ','PLÖn','Kreis Plön','Schleswig-Holstein'),
	(1223,55,'PM','Potsdam, Mittelmark','Landkreis Potsdam-Mittelmark','Brandenburg'),
	(1224,55,'PN','PößNeck','Saale-Orla-Kreis','Thüringen'),
	(1225,55,'PR','PRignitz','Landkreis Prignitz','Brandenburg'),
	(1226,55,'PRÜ','PRÜm','Eifelkreis Bitburg-Prüm','Rheinland-Pfalz'),
	(1227,55,'PS','PirmaSens','Stadt Pirmasens (A–Z 1–9999), Landkreis Südwestpfalz (AA–ZZ 1–999)','Rheinland-Pfalz'),
	(1228,55,'PW','PaseWalk','Landkreis Vorpommern-Greifswald ohne die Stadt Greifswald','Mecklenburg-Vorpommern'),
	(1229,55,'PZ','PrenZlau','Landkreis Uckermark','Brandenburg'),
	(1230,55,'QFT','QuerFurT','Saalekreis','Sachsen-Anhalt'),
	(1231,55,'QLB','QuedLinBurg','Landkreis Harz','Sachsen-Anhalt'),
	(1232,55,'R','Regensburg','Landkreis Regensburg, Stadt Regensburg (AA–MM 1–999 und MN–ZZ 1000–9999)','Bayern'),
	(1233,55,'RA','Württemberg','Landkreis Rastatt','Baden-Württemberg'),
	(1234,55,'RC','ReiChenbach','Vogtlandkreis','Sachsen'),
	(1235,55,'RD','RenDsburg','Kreis Rendsburg-Eckernförde','Schleswig-Holstein'),
	(1236,55,'RDG','Ribnitz-DamGarten','Landkreis Vorpommern-Rügen ohne die Stadt Stralsund','Mecklenburg-Vorpommern'),
	(1237,55,'RE','REcklinghausen','Kreis Recklinghausen','Nordrhein-Westfalen'),
	(1238,55,'REG','REGen','Landkreis Regen','Bayern'),
	(1239,55,'REH','REHau','Landkreis Hof, Landkreis Wunsiedel im Fichtelgebirge (A, E, F, H, J, M, N, P, R, S, V und X 1–999, AA, FF, GG, OO und ZZ 100–999 sowie AU 900–999)','Bayern'),
	(1240,55,'REI','REIchenhall','Landkreis Berchtesgadener Land','Bayern'),
	(1241,55,'RG','Riesa, Großenhain','Landkreis Meißen','Sachsen'),
	(1242,55,'RH','RotH','Landkreis Roth','Bayern'),
	(1243,55,'RI','RInteln','Landkreis Schaumburg','Niedersachsen'),
	(1244,55,'RID','RIeDenburg','Landkreis Kelheim','Bayern'),
	(1245,55,'RIE','RIEsa','Landkreis Meißen','Sachsen'),
	(1246,55,'RL','RochLitz','Landkreis Mittelsachsen','Sachsen'),
	(1247,55,'RM','Röbel/Müritz','Landkreis Mecklenburgische Seenplatte ohne die Stadt Neubrandenburg','Mecklenburg-Vorpommern'),
	(1248,55,'RN','RatheNow','Landkreis Havelland','Brandenburg'),
	(1249,55,'RO','ROsenheim','Stadt Rosenheim, Landkreis Rosenheim (AA–ZZ 100–9999)','Bayern'),
	(1250,55,'ROD','RODing','Landkreis Cham, Landkreis Schwandorf (B 1–500, F 1–700, G 50–400 und I 100–1000)','Bayern'),
	(1251,55,'ROF','ROtenburg an der Fulda','Landkreis Hersfeld-Rotenburg','Hessen'),
	(1252,55,'ROK','ROcKenhausen','Donnersbergkreis','Rheinland-Pfalz'),
	(1253,55,'ROL','ROttenburg an der Laaber','Landkreis Landshut , Landkreis Kelheim (A bis Z)','Bayern'),
	(1254,55,'ROS','ROStock','Landkreis Rostock','Mecklenburg-Vorpommern'),
	(1255,55,'ROT','ROthenburg ob der Tauber','Landkreis Ansbach','Bayern'),
	(1256,55,'ROW','ROtenburg (Wümme)','Landkreis Rotenburg (Wümme)','Niedersachsen'),
	(1257,55,'RP','Rhein-Pfalz','Rhein-Pfalz-Kreis','Rheinland-Pfalz'),
	(1258,55,'RPL','Rheinland-Pfälzischer Landtag','Rheinland-Pfalz, Landesregierung, Landtag und Polizei','Rheinland-Pfalz'),
	(1259,55,'RS','RemScheid','Stadt Remscheid','Nordrhein-Westfalen'),
	(1260,55,'RSL','RosSLau','Stadt Dessau-Roßlau','Sachsen-Anhalt'),
	(1261,55,'RT','ReuTlingen','Landkreis Reutlingen','Baden-Württemberg'),
	(1262,55,'RU','RUdolstadt','Landkreis Saalfeld-Rudolstadt','Thüringen'),
	(1263,55,'RÜD','RÜDesheim','Rheingau-Taunus-Kreis','Hessen'),
	(1264,55,'RÜG','RÜGen','Landkreis Vorpommern-Rügen','Mecklenburg-Vorpommern'),
	(1265,55,'RV','RaVensburg','Landkreis Ravensburg','Baden-Württemberg'),
	(1266,55,'RW','RottWeil','Landkreis Rottweil','Baden-Württemberg'),
	(1267,55,'RZ','RatZeburg','Kreis Herzogtum Lauenburg','Schleswig-Holstein'),
	(1268,55,'S','Stuttgart','Stadt Stuttgart','Baden-Württemberg'),
	(1269,55,'SAB','SAarBurg','Landkreis Trier-Saarburg','Rheinland-Pfalz'),
	(1270,55,'SAD','SchwAnDorf','Landkreis Schwandorf','Bayern'),
	(1271,55,'SAL','SAarländischer Landtag','Saarland, Landesregierung, Landtag und Polizei','Saarland'),
	(1272,55,'SAN','StAdtsteiNach','Landkreis Hof (W–Z 1–999), Landkreis Kulmbach (A–R 1–9999 und JA–ZZ 1–999), Landkreis Kronach (S–V 1–9999 und AA–IZ 1–999)','Bayern'),
	(1273,55,'SAW','SAlzWedel','Altmarkkreis Salzwedel','Sachsen-Anhalt'),
	(1274,55,'SÄK','SÄcKingen','Landkreis Säckingen','Baden-Württemberg'),
	(1275,55,'SB','SaarBrücken','Regionalverband Saarbrücken ohne die Stadt Völklingen','Saarland'),
	(1276,55,'SBG','StrasBurG','Landkreis Vorpommern-Greifswald','Mecklenburg-Vorpommern'),
	(1277,55,'SBK','SchöneBecK','Salzlandkreis','Sachsen-Anhalt'),
	(1278,55,'SC','SChwabach','Stadt Schwabach','Bayern'),
	(1279,55,'SCZ','SChleiZ','Saale-Orla-Kreis','Thüringen'),
	(1280,55,'SDH','SonDersHausen','Kyffhäuserkreis','Thüringen'),
	(1281,55,'SDL','StenDaL','Landkreis Stendal','Sachsen-Anhalt'),
	(1282,55,'SDT','SchweDT','Landkreis Uckermark','Brandenburg'),
	(1283,55,'SE','SEgeberg','Kreis Segeberg','Schleswig-Holstein'),
	(1284,55,'SEB','SEBnitz','Landkreis Sächsische Schweiz-Osterzgebirge','Sachsen'),
	(1285,55,'SEE','SEElow','Landkreis Märkisch-Oderland','Brandenburg'),
	(1286,55,'SEF','SchEinFeld','Landkreis Neustadt an der Aisch-Bad Windsheim','Bayern'),
	(1287,55,'SEL','SELb','Landkreis Wunsiedel im Fichtelgebirge','Bayern'),
	(1288,55,'SFB','SenFtenBerg','Landkreis Oberspreewald-Lausitz','Brandenburg'),
	(1289,55,'SFT','StaßFurT','Salzlandkreis','Sachsen-Anhalt'),
	(1290,55,'SG','SolinGen','Stadt Solingen','Nordrhein-Westfalen'),
	(1291,55,'SGH','SanGerHausen','Landkreis Mansfeld-Südharz','Sachsen-Anhalt'),
	(1292,55,'SH','Schleswig-Holstein','Schleswig-Holstein, Landesregierung, Landtag und Polizei','Schleswig-Holstein'),
	(1293,55,'SHA','Schwäbisch HAll','Landkreis Schwäbisch Hall','Baden-Württemberg'),
	(1294,55,'SHG','StadtHaGen','Landkreis Schaumburg','Niedersachsen'),
	(1295,55,'SHK','Saale-Holzland-Kreis','Saale-Holzland-Kreis','Thüringen'),
	(1296,55,'SHL','SuHL','Stadt Suhl','Thüringen'),
	(1297,55,'SI','SIegen','Kreis Siegen-Wittgenstein','Nordrhein-Westfalen'),
	(1298,55,'SIG','SIGmaringen','Landkreis Sigmaringen','Baden-Württemberg'),
	(1299,55,'SIH','aus dem Film \"Hanne\"','fiktiver Ort','Filmproduktion'),
	(1300,55,'SIM','SIMmern','Rhein-Hunsrück-Kreis','Rheinland-Pfalz'),
	(1301,55,'SK','SaaleKreis','Saalekreis','Sachsen-Anhalt'),
	(1302,55,'SL','SchLeswig','Kreis Schleswig-Flensburg','Schleswig-Holstein'),
	(1303,55,'SLE','SchLEiden','Kreis Düren, Kreis Euskirchen','Nordrhein-Westfalen'),
	(1304,55,'SLF','SaaLFeld','Landkreis Saalfeld-Rudolstadt','Thüringen'),
	(1305,55,'SLG','SauLGau','Landkreis Saulgau','Baden-Württemberg'),
	(1306,55,'SLK','SalzLandKreis','Salzlandkreis','Sachsen-Anhalt'),
	(1307,55,'SLN','SchmölLN','Landkreis Altenburger Land','Thüringen'),
	(1308,55,'SLS','SaarLouiS','Landkreis Saarlouis','Saarland'),
	(1309,55,'SLÜ','SchLÜchtern','Main-Kinzig-Kreis ohne die Stadt Hanau','Hessen'),
	(1310,55,'SLZ','SaLZungen','Wartburgkreis','Thüringen'),
	(1311,55,'SM','SchMalkalden','Landkreis Schmalkalden-Meiningen','Thüringen'),
	(1312,55,'SMÜ','SchwabMÜnchen','Landkreis Augsburg','Bayern'),
	(1313,55,'SN','SchweriN','Stadt Schwerin','Mecklenburg-Vorpommern'),
	(1314,55,'SO','SOest','Kreis Soest','Nordrhein-Westfalen'),
	(1315,55,'SOB','SchrOBenhausen','Landkreis Neuburg-Schrobenhausen','Bayern'),
	(1316,55,'SOG','SchOnGau','Landkreis Weilheim-Schongau','Bayern'),
	(1317,55,'SOK','Saale-Orla-Kreis','Saale-Orla-Kreis','Thüringen'),
	(1318,55,'SÖM','SÖMmerda','Landkreis Sömmerda','Thüringen'),
	(1319,55,'SON','SONneberg','Landkreis Sonneberg','Thüringen'),
	(1320,55,'SP','SPeyer','Stadt Speyer','Rheinland-Pfalz'),
	(1321,55,'SPB','SPremBerg','Landkreis Spree-Neiße','Brandenburg'),
	(1322,55,'SPN','SPree, Neiße','Landkreis Spree-Neiße','Brandenburg'),
	(1323,55,'SR','StRaubing','Stadt Straubing (A–Z 1–9999), Landkreis Straubing-Bogen (AA–ZZ 1–999)','Bayern'),
	(1324,55,'SRB','StRausBerg','Landkreis Märkisch-Oderland','Brandenburg'),
	(1325,55,'SRO','StadtROda','Saale-Holzland-Kreis','Thüringen'),
	(1326,55,'ST','STeinfurt','Kreis Steinfurt','Nordrhein-Westfalen'),
	(1327,55,'STA','STArnberg','Landkreis Starnberg','Bayern'),
	(1328,55,'STB','STernBerg','Landkreis Ludwigslust-Parchim','Mecklenburg-Vorpommern'),
	(1329,55,'STD','STaDe','Landkreis Stade','Niedersachsen'),
	(1330,55,'STE','STaffelstEin','Landkreis Lichtenfels','Bayern'),
	(1331,55,'STL','STolLberg','Erzgebirgskreis','Sachsen'),
	(1332,55,'STO','STOckach','Landkreis Stockach','Baden-Württemberg'),
	(1333,55,'SU','SiegbUrg','Rhein-Sieg-Kreis','Nordrhein-Westfalen'),
	(1334,55,'SUL','SULzbach','Landkreis Amberg-Sulzbach','Bayern'),
	(1335,55,'SÜW','SÜdliche Weinstraße','Landkreis Südliche Weinstraße','Rheinland-Pfalz'),
	(1336,55,'SW','SchWeinfurt','Stadt Schweinfurt, Landkreis Schweinfurt (AA–ZZ 100–9999)','Bayern'),
	(1337,55,'SWA','SchWAlbach','Rheingau-Taunus-Kreis','Hessen'),
	(1338,55,'SY','SYke','Landkreis Diepholz','Niedersachsen'),
	(1339,55,'SZ','SalZgitter','Stadt Salzgitter','Niedersachsen'),
	(1340,55,'SZB','SchwarZenBerg','Erzgebirgskreis','Sachsen'),
	(1341,55,'TBB','TauBerBischofsheim','Main-Tauber-Kreis','Baden-Württemberg'),
	(1342,55,'TDO','Torgau, Delitzsch, Oschatz','Landkreis Nordsachsen','Sachsen'),
	(1343,55,'TE','TEcklenburg','Kreis Steinfurt','Nordrhein-Westfalen'),
	(1344,55,'TET','TETerow','Landkreis Rostock','Mecklenburg-Vorpommern'),
	(1345,55,'TF','Teltow, Fläming','Landkreis Teltow-Fläming','Brandenburg'),
	(1346,55,'TG','TorGau','Landkreis Nordsachsen','Sachsen'),
	(1347,55,'THL','THüringer Landtag','Thüringen, Landesregierung und Landtag','Thüringen'),
	(1348,55,'THW','Technisches HilfsWerk','Bundesanstalt Technisches Hilfswerk','bundesweit'),
	(1349,55,'TIR','TIRschenreuth','Landkreis Tirschenreuth','Bayern'),
	(1350,55,'TO','Torgau, Oschatz','Landkreis Nordsachsen','Sachsen'),
	(1351,55,'TÖL','TÖLz','Landkreis Bad Tölz-Wolfratshausen','Bayern'),
	(1352,55,'TP','TemPlin','Landkreis Uckermark','Brandenburg'),
	(1353,55,'TR','TRier','Landkreis Trier-Saarburg und Stadt Trier','Rheinland-Pfalz'),
	(1354,55,'TS','TraunStein','Landkreis Traunstein','Bayern'),
	(1355,55,'TT','TeTtnang','Bodenseekreis','Baden-Württemberg'),
	(1356,55,'TÜ','TÜbingen','Landkreis Tübingen','Baden-Württemberg'),
	(1357,55,'TUT','TUTtlingen','Landkreis Tuttlingen','Baden-Württemberg'),
	(1358,55,'UE','UElzen','Landkreis Uelzen','Niedersachsen'),
	(1359,55,'UEM','UEckerMünde','Landkreis Vorpommern-Greifswald ohne die Stadt Greifswald','Mecklenburg-Vorpommern'),
	(1360,55,'UFF','UFFenheim','Landkreis Neustadt an der Aisch-Bad Windsheim','Bayern'),
	(1361,55,'UH','Unstrut, Hainich','Unstrut-Hainich-Kreis','Thüringen'),
	(1362,55,'UL','ULm','Stadt Ulm, Alb-Donau-Kreis (AA–MZ 100–999 und NA–ZZ 100–9999)','Baden-Württemberg'),
	(1363,55,'UM','UckerMark','Landkreis Uckermark','Brandenburg'),
	(1364,55,'UN','UNna','Kreis Unna','Nordrhein-Westfalen'),
	(1365,55,'USI','USIngen','Hochtaunuskreis','Hessen'),
	(1366,55,'ÜB','ÜBerlingen','Bodenseekreis, Landkreis Ravensburg','Baden-Württemberg'),
	(1367,55,'V','Vogtland','Vogtlandkreis','Sachsen'),
	(1368,55,'VAI','VAIhingen','Landkreis Ludwigsburg','Baden-Württemberg'),
	(1369,55,'VB','VogelsBerg','Vogelsbergkreis','Hessen'),
	(1370,55,'VEC','VEChta','Landkreis Vechta','Niedersachsen'),
	(1371,55,'VER','VERden','Landkreis Verden','Niedersachsen'),
	(1372,55,'VG','Vorpommern, Greifswald','Landkreis Vorpommern-Greifswald ohne die Stadt Greifswald','Mecklenburg-Vorpommern'),
	(1373,55,'VIB','VIlsBiburg','Landkreis Landshut, Landkreis Rottal-Inn (B, I, O und Q 100–999)','Bayern'),
	(1374,55,'VIE','VIErsen','Kreis Viersen','Nordrhein-Westfalen'),
	(1375,55,'VIT','VIechTach','Landkreis Regen','Bayern'),
	(1376,55,'VK','VölKlingen','Stadt Völklingen (Mittelstadt im Regionalverband Saarbrücken)','Saarland'),
	(1377,55,'VOH','VOHenstrauß','Landkreis Neustadt an der Waldnaab','Bayern'),
	(1378,55,'VR','Vorpommern, Rügen','Landkreis Vorpommern-Rügen ohne die Stadt Stralsund','Mecklenburg-Vorpommern'),
	(1379,55,'VS','Villingen-Schwenningen','Schwarzwald-Baar-Kreis','Baden-Württemberg'),
	(1380,55,'W','Wuppertal','Stadt Wuppertal','Nordrhein-Westfalen'),
	(1381,55,'WA','WAldeck','Landkreis Waldeck-Frankenberg','Hessen'),
	(1382,55,'WAF','WArendorF','Kreis Warendorf','Nordrhein-Westfalen'),
	(1383,55,'WAK','WArtburgKreis','Wartburgkreis','Thüringen'),
	(1384,55,'WAN','WANne','Stadt Herne','Nordrhein-Westfalen'),
	(1385,55,'WAT','WATtenscheid','Stadt Bochum','Nordrhein-Westfalen'),
	(1386,55,'WB','WittenBerg','Landkreis Wittenberg','Sachsen-Anhalt'),
	(1387,55,'WBS','WorBiS','Landkreis Eichsfeld','Thüringen'),
	(1388,55,'WDA','WerDAu','Landkreis Zwickau','Sachsen'),
	(1389,55,'WE','WEimar','Stadt Weimar','Thüringen'),
	(1390,55,'WEL','WEiLburg','Landkreis Limburg-Weilburg','Hessen'),
	(1391,55,'WEN','WEideN','Stadt Weiden in der Oberpfalz','Bayern'),
	(1392,55,'WER','WERtingen','Landkreis Dillingen an der Donau, Landkreis Augsburg (A–Z 7000–9999 und YA–YZ 1–999)','Bayern'),
	(1393,55,'WES','WESel','Kreis Wesel','Nordrhein-Westfalen'),
	(1394,55,'WF','WolFenbüttel','Landkreis Wolfenbüttel','Niedersachsen'),
	(1395,55,'WG','WanGen','Landkreis Ravensburg','Baden-Württemberg'),
	(1396,55,'WHV','WilhelmsHaVen','Stadt Wilhelmshaven','Niedersachsen'),
	(1397,55,'WI','WIesbaden','Stadt Wiesbaden','Hessen'),
	(1398,55,'WIL','WIttLich','Landkreis Bernkastel-Wittlich','Rheinland-Pfalz'),
	(1399,55,'WIN','aus der Serie \"Dark\"','Winden (fiktiver Ort)','Filmproduktion'),
	(1400,55,'WIS','WISmar','Landkreis Nordwestmecklenburg','Mecklenburg-Vorpommern'),
	(1401,55,'WIT','WITten','Ennepe-Ruhr-Kreis','Nordrhein-Westfalen'),
	(1402,55,'WIV','aus dem Film \"Hanne\"','fiktiver Ort','Filmproduktion'),
	(1403,55,'WIZ','WItZenhausen','Werra-Meißner-Kreis','Hessen'),
	(1404,55,'WK','WittstocK','Landkreis Ostprignitz-Ruppin','Brandenburg'),
	(1405,55,'WL','Winsen (Luhe)','Landkreis Harburg','Niedersachsen'),
	(1406,55,'WLG','WoLGast','Landkreis Vorpommern-Greifswald ohne die Stadt Greifswald','Mecklenburg-Vorpommern'),
	(1407,55,'WM','WeilheiM','Landkreis Weilheim-Schongau','Bayern'),
	(1408,55,'WMS','WolMirStedt','Landkreis Börde','Sachsen-Anhalt'),
	(1409,55,'WN','WaiblingeN','Rems-Murr-Kreis','Baden-Württemberg'),
	(1410,55,'WND','WeNDel','Landkreis St. Wendel','Saarland'),
	(1411,55,'WO','WOrms','Stadt Worms','Rheinland-Pfalz'),
	(1412,55,'WOB','WOlfsBurg','Stadt Wolfsburg','Niedersachsen'),
	(1413,55,'WOH','WOlfHagen','Landkreis Kassel','Hessen'),
	(1414,55,'WOL','WOLfach','Ortenaukreis, Landkreis Freudenstadt (A bis E 9000–9999)','Baden-Württemberg'),
	(1415,55,'WOR','WOlfRatshausen','Landkreis Bad Tölz-Wolfratshausen, Landkreis München (F und O 10–9999), Landkreis Starnberg (B und G 10–9999)','Bayern'),
	(1416,55,'WOS','WOlfStein','Landkreis Freyung-Grafenau','Bayern'),
	(1417,55,'WR','WernigeRode','Landkreis Harz','Sachsen-Anhalt'),
	(1418,55,'WRN','WaReN','Landkreis Mecklenburgische Seenplatte ohne die Stadt Neubrandenburg','Mecklenburg-Vorpommern'),
	(1419,55,'WS','WasSerburg','Landkreis Rosenheim','Bayern'),
	(1420,55,'WSF','WeisSenFels','Burgenlandkreis','Sachsen-Anhalt'),
	(1421,55,'WST','WesterSTede','Landkreis Ammerland','Niedersachsen'),
	(1422,55,'WSW','WeisSWasser','Landkreis Görlitz','Sachsen'),
	(1423,55,'WT','WaldshuT','Landkreis Waldshut','Baden-Württemberg'),
	(1424,55,'WTL','WitTLage','Landkreis Osnabrück','Niedersachsen'),
	(1425,55,'WTM','WitTMund','Landkreis Wittmund','Niedersachsen'),
	(1426,55,'WÜ','WÜrzburg','Landkreis Würzburg, Stadt Würzburg (AA–NZ 100–9999 und OA–ZZ 100–999)','Bayern'),
	(1427,55,'WUG','WeißenbUrG','Landkreis Weißenburg-Gunzenhausen','Bayern'),
	(1428,55,'WÜM','WaldMÜnchen (mit einem Buchstabendreher)','Landkreis Cham','Bayern'),
	(1429,55,'WUN','WUNsiedel','Landkreis Wunsiedel im Fichtelgebirge','Bayern'),
	(1430,55,'WUR','WURzen','Landkreis Leipzig','Sachsen'),
	(1431,55,'WW','WesterWald','Westerwaldkreis','Rheinland-Pfalz'),
	(1432,55,'WZ','WetZlar','Stadt Wetzlar (Sonderstatusstadt im Lahn-Dill-Kreis)','Hessen'),
	(1433,55,'WZL','WanZLeben','Landkreis Börde','Sachsen-Anhalt'),
	(1434,55,'X','willkürlich gewählt','Internationale Hauptquartiere (NATO)','bundesweit'),
	(1435,55,'Y','willkürlich gewählt','Bundeswehr','bundesweit'),
	(1436,55,'Z','Zwickau','Landkreis Zwickau','Sachsen'),
	(1437,55,'ZE','ZErbst','Landkreis Anhalt-Bitterfeld','Sachsen-Anhalt'),
	(1438,55,'ZEL','ZELl','Landkreis Cochem-Zell','Rheinland-Pfalz'),
	(1439,55,'ZI','ZIttau','Landkreis Görlitz','Sachsen'),
	(1440,55,'ZIG','ZIeGenhain','Schwalm-Eder-Kreis','Hessen'),
	(1441,55,'ZP','ZschoPau','Erzgebirgskreis','Sachsen'),
	(1442,55,'ZR','ZeulenRoda','Landkreis Greiz','Thüringen'),
	(1443,55,'ZW','ZWeibrücken','Stadt Zweibrücken, Landkreis Südwestpfalz (AA–ZZ 1–99)','Rheinland-Pfalz'),
	(1444,55,'ZZ','ZeitZ','Burgenlandkreis','Sachsen-Anhalt');

/*!40000 ALTER TABLE `car_license_plates` ENABLE KEYS */;
UNLOCK TABLES;


# Tabellen-Dump caravan_dates
# ------------------------------------------------------------

DROP TABLE IF EXISTS `caravan_dates`;

CREATE TABLE `caravan_dates` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `caravan_id` int(11) unsigned NOT NULL,
  `from` date NOT NULL,
  `until` date NOT NULL,
  `persons` tinyint(2) unsigned NOT NULL,
  `electric` tinyint(1) unsigned DEFAULT NULL,
  `price` int(10) unsigned NOT NULL,
  `prices` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`prices`)),
  `is_paid` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `caravan_id` (`caravan_id`),
  KEY `from` (`from`,`until`),
  KEY `price` (`price`),
  KEY `is_paid` (`is_paid`),
  CONSTRAINT `caravan_dates_ibfk_1` FOREIGN KEY (`caravan_id`) REFERENCES `caravans` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

LOCK TABLES `caravan_dates` WRITE;
/*!40000 ALTER TABLE `caravan_dates` DISABLE KEYS */;

INSERT INTO `caravan_dates` (`id`, `caravan_id`, `from`, `until`, `persons`, `electric`, `price`, `prices`, `is_paid`)
VALUES
	(1,1,'2023-06-01','2023-06-02',2,1,18,X'7B22707269636542617365223A31352C226461696C79507269636573223A7B22323032332D30362D3031223A7B227072696365223A2231352E3030222C22736169736F6E223A224861757074736169736F6E227D7D2C227072696365456C656374726963223A332C227072696365506572736F6E73223A302C2264617973223A312C22746178223A31392C226E6574746F223A31352C227461785072696365223A332C22746F74616C223A31387D',1);

/*!40000 ALTER TABLE `caravan_dates` ENABLE KEYS */;
UNLOCK TABLES;


# Tabellen-Dump caravans
# ------------------------------------------------------------

DROP TABLE IF EXISTS `caravans`;

CREATE TABLE `caravans` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `country_id` int(11) unsigned NOT NULL,
  `carnumber` varchar(10) NOT NULL DEFAULT '',
  `carlength` tinyint(2) unsigned NOT NULL,
  `email` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `carnumber` (`carnumber`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

LOCK TABLES `caravans` WRITE;
/*!40000 ALTER TABLE `caravans` DISABLE KEYS */;

INSERT INTO `caravans` (`id`, `country_id`, `carnumber`, `carlength`, `email`)
VALUES
	(1,55,'B-CO 5915',6,NULL);

/*!40000 ALTER TABLE `caravans` ENABLE KEYS */;
UNLOCK TABLES;


# Tabellen-Dump config_boat_prices
# ------------------------------------------------------------

DROP TABLE IF EXISTS `config_boat_prices`;

CREATE TABLE `config_boat_prices` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT '',
  `saison_date_id` int(10) unsigned NOT NULL,
  `price_type_id` int(10) unsigned NOT NULL,
  `price_factor` float unsigned NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `saison_date_id` (`saison_date_id`),
  KEY `price_type_id` (`price_type_id`),
  CONSTRAINT `config_boat_prices_ibfk_1` FOREIGN KEY (`saison_date_id`) REFERENCES `config_saison_dates` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `config_boat_prices_ibfk_2` FOREIGN KEY (`price_type_id`) REFERENCES `config_price_types` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

LOCK TABLES `config_boat_prices` WRITE;
/*!40000 ALTER TABLE `config_boat_prices` DISABLE KEYS */;

INSERT INTO `config_boat_prices` (`id`, `name`, `saison_date_id`, `price_type_id`, `price_factor`)
VALUES
	(1,'Winterlager Boot',3,5,20),
	(2,'Sommer Liegeplatz',4,5,30);

/*!40000 ALTER TABLE `config_boat_prices` ENABLE KEYS */;
UNLOCK TABLES;


# Tabellen-Dump config_daily_prices
# ------------------------------------------------------------

DROP TABLE IF EXISTS `config_daily_prices`;

CREATE TABLE `config_daily_prices` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `model` varchar(100) NOT NULL DEFAULT '',
  `saison_date_id` int(10) unsigned NOT NULL,
  `price_type_id` int(10) unsigned NOT NULL,
  `from_unit` float unsigned DEFAULT NULL,
  `until_unit` float unsigned DEFAULT NULL,
  `price` decimal(4,2) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `saison_date_id` (`saison_date_id`),
  KEY `price_type_id` (`price_type_id`),
  KEY `has_daily_price_type` (`model`),
  CONSTRAINT `config_daily_prices_ibfk_1` FOREIGN KEY (`saison_date_id`) REFERENCES `config_saison_dates` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `config_daily_prices_ibfk_2` FOREIGN KEY (`price_type_id`) REFERENCES `config_price_types` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

LOCK TABLES `config_daily_prices` WRITE;
/*!40000 ALTER TABLE `config_daily_prices` DISABLE KEYS */;

INSERT INTO `config_daily_prices` (`id`, `model`, `saison_date_id`, `price_type_id`, `from_unit`, `until_unit`, `price`)
VALUES
	(1,'App\\Models\\CaravanDates',2,6,NULL,NULL,15.00),
	(2,'App\\Models\\CaravanDates',1,6,NULL,NULL,12.00),
	(3,'App\\Models\\GuestBoatDates',2,1,NULL,NULL,2.00),
	(4,'App\\Models\\GuestBoatDates',1,1,NULL,NULL,1.50);

/*!40000 ALTER TABLE `config_daily_prices` ENABLE KEYS */;
UNLOCK TABLES;


# Tabellen-Dump config_entities
# ------------------------------------------------------------

DROP TABLE IF EXISTS `config_entities`;

CREATE TABLE `config_entities` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `model` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `model` (`model`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

LOCK TABLES `config_entities` WRITE;
/*!40000 ALTER TABLE `config_entities` DISABLE KEYS */;

INSERT INTO `config_entities` (`id`, `model`)
VALUES
	(6,'App\\Models\\Apartment'),
	(2,'App\\Models\\Boat'),
	(1,'App\\Models\\Caravan'),
	(3,'App\\Models\\GuestBoat'),
	(5,'App\\Models\\House'),
	(4,'App\\Models\\Houseboat');

/*!40000 ALTER TABLE `config_entities` ENABLE KEYS */;
UNLOCK TABLES;


# Tabellen-Dump config_has_price_components
# ------------------------------------------------------------

DROP TABLE IF EXISTS `config_has_price_components`;

CREATE TABLE `config_has_price_components` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `entity_id` int(11) unsigned NOT NULL,
  `price_component_id` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

LOCK TABLES `config_has_price_components` WRITE;
/*!40000 ALTER TABLE `config_has_price_components` DISABLE KEYS */;

INSERT INTO `config_has_price_components` (`id`, `entity_id`, `price_component_id`)
VALUES
	(1,1,1),
	(2,3,1),
	(3,1,2),
	(4,3,2),
	(5,2,3),
	(6,3,3),
	(7,2,4),
	(8,3,4),
	(9,2,5),
	(10,3,5),
	(11,4,6),
	(12,2,7),
	(13,3,7),
	(14,6,6),
	(15,5,6),
	(16,6,8),
	(17,5,8),
	(18,4,8);

/*!40000 ALTER TABLE `config_has_price_components` ENABLE KEYS */;
UNLOCK TABLES;


# Tabellen-Dump config_holidays
# ------------------------------------------------------------

DROP TABLE IF EXISTS `config_holidays`;

CREATE TABLE `config_holidays` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(50) NOT NULL DEFAULT '',
  `name` varchar(50) NOT NULL DEFAULT '',
  `enabled` tinyint(1) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

LOCK TABLES `config_holidays` WRITE;
/*!40000 ALTER TABLE `config_holidays` DISABLE KEYS */;

INSERT INTO `config_holidays` (`id`, `key`, `name`, `enabled`)
VALUES
	(1,'new_year','Neujahr',1),
	(2,'good_friday','Karfreitag',1),
	(3,'easter_monday','Ostermontag',1),
	(4,'labor_day','Tag der Arbeit',1),
	(5,'ascension','Christi Himmelfahrt',1),
	(6,'whit_sunday','Pfingstsonntag',1),
	(7,'whit_monday','Pfingstmontag',1),
	(8,'german_unity_day','Tag der Deutschen Einheit',1),
	(9,'reformation_day','Reformationstag',0),
	(10,'repentance_and_prayer_day','Buß- und Bettag',0),
	(11,'christmas_eve','Heiligabend',1),
	(12,'christmas_day','Erster Weihnachtsfeiertag',1),
	(13,'second_christmas_day','Zweiter Weihnachtsfeiertag',1),
	(14,'new_years_eve','Silvester',1);

/*!40000 ALTER TABLE `config_holidays` ENABLE KEYS */;
UNLOCK TABLES;


# Tabellen-Dump config_offers
# ------------------------------------------------------------

DROP TABLE IF EXISTS `config_offers`;

CREATE TABLE `config_offers` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL DEFAULT '',
  `model` varchar(100) DEFAULT NULL,
  `enabled` tinyint(1) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `model` (`model`),
  KEY `enabled` (`enabled`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

LOCK TABLES `config_offers` WRITE;
/*!40000 ALTER TABLE `config_offers` DISABLE KEYS */;

INSERT INTO `config_offers` (`id`, `name`, `model`, `enabled`)
VALUES
	(1,'Caravans','App\\Models\\Caravan',1),
	(2,'Boote','App\\Models\\Boat',1),
	(3,'Hausboote','App\\Models\\Houseboat',1),
	(4,'Boot Services','App\\Models\\Service',1),
	(6,'Häuser','App\\Models\\House',1),
	(7,'Apartments','App\\Models\\Apartment',1);

/*!40000 ALTER TABLE `config_offers` ENABLE KEYS */;
UNLOCK TABLES;


# Tabellen-Dump config_price_components
# ------------------------------------------------------------

DROP TABLE IF EXISTS `config_price_components`;

CREATE TABLE `config_price_components` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `price_type_id` int(11) unsigned NOT NULL,
  `config_service_id` int(11) unsigned DEFAULT NULL,
  `name` varchar(50) NOT NULL DEFAULT '',
  `key` varchar(50) NOT NULL DEFAULT '',
  `unit_inclusive` tinyint(3) unsigned DEFAULT NULL,
  `unit_price` decimal(10,2) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `price_type_id` (`price_type_id`),
  KEY `config_service_id` (`config_service_id`),
  CONSTRAINT `config_price_components_ibfk_1` FOREIGN KEY (`price_type_id`) REFERENCES `config_price_types` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `config_price_components_ibfk_2` FOREIGN KEY (`config_service_id`) REFERENCES `config_services` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

LOCK TABLES `config_price_components` WRITE;
/*!40000 ALTER TABLE `config_price_components` DISABLE KEYS */;

INSERT INTO `config_price_components` (`id`, `price_type_id`, `config_service_id`, `name`, `key`, `unit_inclusive`, `unit_price`)
VALUES
	(1,7,1,'Stromanschluß pro Tag (Gäste)','electric',NULL,3.00),
	(2,7,NULL,'Personen pro Tag (Gäste)','persons',2,1.00),
	(3,8,4,'Boot Kranen','crane',NULL,25.00),
	(4,4,5,'Mast Kranen','mast_crane',NULL,75.00),
	(5,1,6,'Unterschiff Reinigung','cleaning',NULL,3.00),
	(6,9,1,'Strom pro Kilowatt','kilowatt',NULL,1.00),
	(7,8,7,'Boots-Transport im Hafen','transport',NULL,20.00),
	(8,5,8,'Reinigung Mietobjekt','rental_cleaning',NULL,0.50);

/*!40000 ALTER TABLE `config_price_components` ENABLE KEYS */;
UNLOCK TABLES;


# Tabellen-Dump config_price_types
# ------------------------------------------------------------

DROP TABLE IF EXISTS `config_price_types`;

CREATE TABLE `config_price_types` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `name_units` varchar(50) DEFAULT NULL,
  `type` enum('length','volume','kilogram','ton','area','hour','half_hour','day','absolute','kilowatt') NOT NULL DEFAULT 'length',
  `is_time` tinyint(1) NOT NULL DEFAULT 0,
  `unit` char(2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`,`type`,`unit`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `config_price_types` WRITE;
/*!40000 ALTER TABLE `config_price_types` DISABLE KEYS */;

INSERT INTO `config_price_types` (`id`, `name`, `name_units`, `type`, `is_time`, `unit`)
VALUES
	(1,'pro Meter','Meter','length',0,'m'),
	(2,'pro Liter','Liter','volume',0,'L'),
	(3,'pro Kilogramm','Kilogramm','kilogram',0,'Kg'),
	(4,'pro Stunde','Stunden','hour',1,'H'),
	(5,'pro  Quatratmeter','Quatratmeter','area',0,'m²'),
	(6,'Absolut','Absolut','absolute',0,NULL),
	(7,'pro Tag','Tage','day',1,'T'),
	(8,'pro Tonne','Tonnen','ton',0,'t'),
	(9,'pro Kilowatt','Kilowatt','kilowatt',0,'KW');

/*!40000 ALTER TABLE `config_price_types` ENABLE KEYS */;
UNLOCK TABLES;


# Tabellen-Dump config_saison_dates
# ------------------------------------------------------------

DROP TABLE IF EXISTS `config_saison_dates`;

CREATE TABLE `config_saison_dates` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL DEFAULT '',
  `key` enum('customer','guest') DEFAULT NULL,
  `mode` enum('summer','winter') DEFAULT NULL,
  `from_day` tinyint(2) unsigned zerofill NOT NULL,
  `from_month` tinyint(2) unsigned zerofill NOT NULL,
  `until_day` tinyint(2) unsigned zerofill NOT NULL,
  `until_month` tinyint(2) unsigned zerofill NOT NULL,
  `from_mday` smallint(5) unsigned DEFAULT NULL,
  `until_mday` smallint(5) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `from_month_day` (`from_mday`,`until_mday`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `config_saison_dates` WRITE;
/*!40000 ALTER TABLE `config_saison_dates` DISABLE KEYS */;

INSERT INTO `config_saison_dates` (`id`, `name`, `key`, `mode`, `from_day`, `from_month`, `until_day`, `until_month`, `from_mday`, `until_mday`)
VALUES
	(1,'Nebensaison','guest',NULL,01,10,31,05,1001,531),
	(2,'Hauptsaison','guest',NULL,01,06,30,09,601,930),
	(3,'Winterlager Boote, Nebensaison','customer','winter',01,11,30,04,1101,430),
	(4,'Sommer-Liegeplatz Boote, Hauptsaison','customer','summer',01,05,31,10,501,1031);

/*!40000 ALTER TABLE `config_saison_dates` ENABLE KEYS */;
UNLOCK TABLES;


# Tabellen-Dump config_saison_rent_dates
# ------------------------------------------------------------

DROP TABLE IF EXISTS `config_saison_rent_dates`;

CREATE TABLE `config_saison_rent_dates` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `config_saison_rent_id` int(11) unsigned NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `holiday` varchar(25) DEFAULT NULL,
  `from` date NOT NULL,
  `until` date NOT NULL,
  PRIMARY KEY (`id`),
  KEY `config_saison_rent_id` (`config_saison_rent_id`),
  CONSTRAINT `config_saison_rent_dates_ibfk_1` FOREIGN KEY (`config_saison_rent_id`) REFERENCES `config_saison_rents` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

LOCK TABLES `config_saison_rent_dates` WRITE;
/*!40000 ALTER TABLE `config_saison_rent_dates` DISABLE KEYS */;

INSERT INTO `config_saison_rent_dates` (`id`, `config_saison_rent_id`, `name`, `holiday`, `from`, `until`)
VALUES
	(1,1,NULL,'Ostern 2022','2022-04-15','2022-04-18'),
	(2,1,NULL,'Pfingsten 2022','2022-06-05','2022-06-06'),
	(3,1,NULL,'WeihnachtenSilvester2023','2023-12-24','2024-01-01'),
	(4,1,'2022',NULL,'2022-06-01','2022-09-30'),
	(5,2,'2022',NULL,'2022-04-01','2022-05-31'),
	(6,2,'2022',NULL,'2022-10-01','2022-10-31'),
	(7,3,'2022/23',NULL,'2022-11-01','2023-03-31'),
	(9,1,NULL,'WeihnachtenSilvester2022','2022-12-24','2023-01-01'),
	(10,1,NULL,'Ostern 2023','2023-04-07','2023-04-10'),
	(11,1,NULL,'Pfingsten 2023','2023-05-28','2023-05-29'),
	(12,2,'2023',NULL,'2023-04-01','2023-05-31'),
	(13,1,'2023',NULL,'2023-06-01','2023-09-30'),
	(14,2,'2023',NULL,'2023-10-01','2023-10-31'),
	(15,3,'2023/24',NULL,'2023-11-01','2024-03-31');

/*!40000 ALTER TABLE `config_saison_rent_dates` ENABLE KEYS */;
UNLOCK TABLES;


# Tabellen-Dump config_saison_rents
# ------------------------------------------------------------

DROP TABLE IF EXISTS `config_saison_rents`;

CREATE TABLE `config_saison_rents` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `key` enum('peak','mid','low') DEFAULT NULL,
  `name` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

LOCK TABLES `config_saison_rents` WRITE;
/*!40000 ALTER TABLE `config_saison_rents` DISABLE KEYS */;

INSERT INTO `config_saison_rents` (`id`, `key`, `name`)
VALUES
	(1,'peak','Hauptsaison'),
	(2,'mid','Zwischensaison'),
	(3,'low','Nebensaison');

/*!40000 ALTER TABLE `config_saison_rents` ENABLE KEYS */;
UNLOCK TABLES;


# Tabellen-Dump config_services
# ------------------------------------------------------------

DROP TABLE IF EXISTS `config_services`;

CREATE TABLE `config_services` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL DEFAULT '',
  `key` varchar(50) DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

LOCK TABLES `config_services` WRITE;
/*!40000 ALTER TABLE `config_services` DISABLE KEYS */;

INSERT INTO `config_services` (`id`, `name`, `key`)
VALUES
	(1,'Stromanschluß','electric'),
	(2,'Wasser','water'),
	(3,'WLAN','wlan'),
	(4,'Kranen','crane'),
	(5,'Mast Kranen','mast_crane'),
	(6,'Rumpf-Reinigung','cleaning'),
	(7,'Boot-Transport im Hafen','transport'),
	(8,'Reinigung Mietobjekt','rental-cleaning');

/*!40000 ALTER TABLE `config_services` ENABLE KEYS */;
UNLOCK TABLES;


# Tabellen-Dump config_settings
# ------------------------------------------------------------

DROP TABLE IF EXISTS `config_settings`;

CREATE TABLE `config_settings` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL DEFAULT '',
  `lat` decimal(10,8) unsigned NOT NULL,
  `lng` decimal(10,8) unsigned NOT NULL,
  `street` varchar(50) NOT NULL DEFAULT '',
  `location` varchar(50) NOT NULL DEFAULT '',
  `postcode` varchar(10) NOT NULL DEFAULT '',
  `email` varchar(100) DEFAULT '',
  `fon` varchar(50) DEFAULT '',
  `bank` varchar(50) DEFAULT NULL,
  `bic` varchar(50) DEFAULT NULL,
  `iban` varchar(50) DEFAULT NULL,
  `tax` float unsigned NOT NULL DEFAULT 0,
  `use_tax` tinyint(1) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

LOCK TABLES `config_settings` WRITE;
/*!40000 ALTER TABLE `config_settings` DISABLE KEYS */;

INSERT INTO `config_settings` (`id`, `name`, `lat`, `lng`, `street`, `location`, `postcode`, `email`, `fon`, `bank`, `bic`, `iban`, `tax`, `use_tax`)
VALUES
	(1,'HafenLiebe  Resort Usedom',54.02584800,13.91135200,'Kirchstraße 5','Lütow','17440','engels@f50.de','038377 40575','Berliner Sparkasse','BELADEXXXXX','DE12 1234 1234 1234 1234 12',19,1);

/*!40000 ALTER TABLE `config_settings` ENABLE KEYS */;
UNLOCK TABLES;


# Tabellen-Dump contacts
# ------------------------------------------------------------

DROP TABLE IF EXISTS `contacts`;

CREATE TABLE `contacts` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL DEFAULT '',
  `email` varchar(50) NOT NULL DEFAULT '',
  `subject` varchar(100) DEFAULT NULL,
  `message` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `email` (`email`),
  KEY `created_at` (`created_at`),
  FULLTEXT KEY `subject` (`subject`,`message`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

LOCK TABLES `contacts` WRITE;
/*!40000 ALTER TABLE `contacts` DISABLE KEYS */;

INSERT INTO `contacts` (`id`, `name`, `email`, `subject`, `message`, `created_at`)
VALUES
	(1,'Herr Bernd Engels','engels@goldenacker.de','Test','Test','2022-09-06 18:09:36'),
	(2,'Herr Müller','engels@goldenacker.de','Test','Test 2','2023-01-06 20:31:25'),
	(3,'Bernd Engels','engels@goldenacker.de','Test','dfdfdsfsd','2023-01-10 18:06:40');

/*!40000 ALTER TABLE `contacts` ENABLE KEYS */;
UNLOCK TABLES;


# Tabellen-Dump countries
# ------------------------------------------------------------

DROP TABLE IF EXISTS `countries`;

CREATE TABLE `countries` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `code` char(2) NOT NULL,
  `en` varchar(100) NOT NULL,
  `de` varchar(100) NOT NULL,
  `es` varchar(100) NOT NULL,
  `fr` varchar(100) NOT NULL,
  `it` varchar(100) NOT NULL,
  `ru` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `countries_code_en_de_index` (`code`,`en`,`de`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `countries` WRITE;
/*!40000 ALTER TABLE `countries` DISABLE KEYS */;

INSERT INTO `countries` (`id`, `code`, `en`, `de`, `es`, `fr`, `it`, `ru`)
VALUES
	(1,'AD','Andorra','Andorra','Andorra','ANDORRE','Andorra ','Андорра'),
	(2,'AE','United Arab Emirates','Vereinigte Arabische Emirate','Emiratos Árabes Unidos','ÉMIRATS ARABES UNIS','Emirati Arabi Uniti ','ОАЭ'),
	(3,'AF','Afghanistan','Afghanistan','Afganistán','AFGHANISTAN','Afghanistan','Афганистан'),
	(4,'AG','Antigua and Barbuda','Antigua und Barbuda','Antigua y Barbuda','ANTIGUA-ET-BARBUDA','Antigua e Barbuda','Антигуа и Барбуда'),
	(5,'AI','Anguilla','Anguilla','Anguila','ANGUILLA','Anguilla','Ангилья'),
	(6,'AL','Albania','Albanien','Albania','ALBANIE','Albania ','Албания'),
	(7,'AM','Armenia','Armenien','Armenia','ARMÉNIE','Armenia ','Армения'),
	(8,'AN','Netherlands Antilles','Niederländische Antillen','Antillas Neerlandesas','','',''),
	(9,'AO','Angola','Angola','Angola','ANGOLA','Angola ','Ангола'),
	(10,'AQ','Antarctica','Antarktis','Antártida','ANTARCTIQUE','Antartide ','Антарктида'),
	(11,'AR','Argentina','Argentinien','Argentina','ARGENTINE','Argentina ','Аргентина'),
	(12,'AS','American Samoa','Amerikanisch-Samoa','Samoa Americana','SAMOA AMÉRICAINES','Samoa Americane','Американское Самоа'),
	(13,'AT','Austria','Österreich','Austria','AUTRICHE','Austria','Австрия'),
	(14,'AU','Australia','Australien','Australia','AUSTRALIE','Australia','Австралия'),
	(15,'AW','Aruba','Aruba','Aruba','ARUBA','Aruba','Аруба'),
	(16,'AX','Aland Islands','Åland','Islas Áland','ÅLAND, ÎLES','Isole Åland','Аландские острова'),
	(17,'AZ','Azerbaijan','Aserbaidschan','Azerbaiyán','AZERBAÏDJAN','Azerbaigian','Азербайджан'),
	(18,'BA','Bosnia and Herzegovina','Bosnien und Herzegowina','Bosnia y Herzegovina','BOSNIE-HERZÉGOVINE','Bosnia ed Erzegovina','Босния и Герцеговина'),
	(19,'BB','Barbados','Barbados','Barbados','BARBADE','Barbados','Барбадос'),
	(20,'BD','Bangladesh','Bangladesch','Bangladesh','BANGLADESH','Bangladesh','Бангладеш'),
	(21,'BE','Belgium','Belgien','Bélgica','BELGIQUE','Belgio','Бельгия'),
	(22,'BF','Burkina Faso','Burkina Faso','Burkina Faso','BURKINA FASO','Burkina Faso','Буркина-Фасо'),
	(23,'BG','Bulgaria','Bulgarien','Bulgaria','BULGARIE','Bulgaria','Болгария'),
	(24,'BH','Bahrain','Bahrain','Bahréin','BAHREÏN','Bahrein','Бахрейн'),
	(25,'BI','Burundi','Burundi','Burundi','BURUNDI','Burundi','Бурунди'),
	(26,'BJ','Benin','Benin','Benin','BÉNIN','Benin','Бенин'),
	(27,'BM','Bermuda','Bermuda','Bermudas','BERMUDES','Bermuda','Бермуды'),
	(28,'BN','Brunei','Brunei Darussalam','Brunéi','BRUNÉI DARUSSALAM','Brunei','Бруней'),
	(29,'BO','Bolivia','Bolivien','Bolivia','BOLIVIE, ÉTAT PLURINATIONAL DE','Bolivia','Боливия'),
	(30,'BR','Brazil','Brasilien','Brasil','BRÉSIL','Brasile','Бразилия'),
	(31,'BS','Bahamas','Bahamas','Bahamas','BAHAMAS','Bahamas','Багамы'),
	(32,'BT','Bhutan','Bhutan','Bhután','BHOUTAN','Bhutan','Бутан'),
	(33,'BV','Bouvet Island','Bouvetinsel','Isla Bouvet','BOUVET, ÎLE','Isola Bouvet','Остров Буве'),
	(34,'BW','Botswana','Botswana','Botsuana','BOTSWANA','Botswana','Ботсвана'),
	(35,'BY','Belarus','Belarus (Weißrussland)','Belarús','BÉLARUS','Bielorussia','Белоруссия'),
	(36,'BZ','Belize','Belize','Belice','BELIZE','Belize','Белиз'),
	(37,'CA','Canada','Kanada','Canadá','CANADA','Canada','Канада'),
	(38,'CC','Cocos (Keeling) Islands','Kokosinseln (Keelinginseln)','Islas Cocos','COCOS (KEELING), ÎLES','Isole Cocos (Keeling)','Кокосовые острова'),
	(39,'CD','Congo (Kinshasa)','Kongo','Congo','CONGO, LA RÉPUBLIQUE DÉMOCRATIQUE DU','RD del Congo','Демократическая Республика Конго'),
	(40,'CF','Central African Republic','Zentralafrikanische Republik','República Centro-Africana','CENTRAFRICAINE, RÉPUBLIQUE','Rep. Centrafricana','ЦАР'),
	(41,'CG','Congo (Brazzaville)','Republik Kongo','Congo','CONGO','Rep. del Congo','Республика Конго'),
	(42,'CH','Switzerland','Schweiz','Suiza','SUISSE','Svizzera','Швейцария'),
	(43,'CI','Ivory Coast','Elfenbeinküste','Costa de Marfil','CÔTE D’IVOIRE','Costa d\'Avorio','Кот-д’Ивуар'),
	(44,'CK','Cook Islands','Cookinseln','Islas Cook','COOK, ÎLES','Isole Cook','Острова Кука'),
	(45,'CL','Chile','Chile','Chile','CHILI','Cile','Чили'),
	(46,'CM','Cameroon','Kamerun','Camerún','CAMEROUN','Camerun','Камерун'),
	(47,'CN','China','China, Volksrepublik','China','CHINE','Cina','КНР (Китайская Народная Республика)'),
	(48,'CO','Colombia','Kolumbien','Colombia','COLOMBIE','Colombia','Колумбия'),
	(49,'CR','Costa Rica','Costa Rica','Costa Rica','COSTA RICA','Costa Rica','Коста-Рика'),
	(50,'CU','Cuba','Kuba','Cuba','CUBA','Cuba','Куба'),
	(51,'CV','Cape Verde','Kap Verde','Cabo Verde','CABO VERDE','Capo Verde','Кабо-Верде'),
	(52,'CX','Christmas Island','Weihnachtsinsel','Islas Christmas','CHRISTMAS, ÎLE','Isola di Natale','Остров Рождества'),
	(53,'CY','Cyprus','Zypern','Chipre','CHYPRE','Cipro','Кипр'),
	(54,'CZ','Czech Republic','Tschechische Republik','República Checa','TCHÈQUE, RÉPUBLIQUE','Rep. Ceca','Чехия'),
	(55,'DE','Germany','Deutschland','Alemania','ALLEMAGNE','Germania','Германия'),
	(56,'DJ','Djibouti','Dschibuti','Yibuti','DJIBOUTI','Gibuti','Джибути'),
	(57,'DK','Denmark','Dänemark','Dinamarca','DANEMARK','Danimarca','Дания'),
	(58,'DM','Dominica','Dominica','Domínica','DOMINIQUE','Dominica','Доминика'),
	(59,'DO','Dominican Republic','Dominikanische Republik','República Dominicana','DOMINICAINE, RÉPUBLIQUE','Rep. Dominicana','Доминиканская Республика'),
	(60,'DZ','Algeria','Algerien','Argelia','ALGÉRIE','Algeria','Алжир'),
	(61,'EC','Ecuador','Ecuador','Ecuador','ÉQUATEUR','Ecuador','Эквадор'),
	(62,'EE','Estonia','Estland (Reval)','Estonia','ESTONIE','Estonia','Эстония'),
	(63,'EG','Egypt','Ägypten','Egipto','ÉGYPTE','Egitto','Египет'),
	(64,'EH','Western Sahara','Westsahara','Sahara Occidental','SAHARA OCCIDENTAL','Sahara Occidentale','САДР'),
	(65,'ER','Eritrea','Eritrea','Eritrea','ÉRYTHRÉE','Eritrea','Эритрея'),
	(66,'ES','Spain','Spanien','España','ESPAGNE','Spagna','Испания'),
	(67,'ET','Ethiopia','Äthiopien','Etiopía','ÉTHIOPIE','Etiopia','Эфиопия'),
	(68,'FI','Finland','Finnland','Finlandia','FINLANDE','Finlandia','Финляндия'),
	(69,'FJ','Fiji','Fidschi','Fiji','FIDJI','Figi','Фиджи'),
	(70,'FK','Falkland Islands','Falklandinseln (Malwinen)','Islas Malvinas','FALKLAND, ÎLES (MALVINAS)','Isole Falkland','Фолклендские острова'),
	(71,'FM','Micronesia','Mikronesien','Micronesia','MICRONÉSIE, ÉTATS FÉDÉRÉS DE','Micronesia','Микронезия'),
	(72,'FO','Faroe Islands','Färöer','Islas Faroe','FÉROÉ, ÎLES','Fær Øer','Фареры'),
	(73,'FR','France','Frankreich','Francia','FRANCE','Francia','Франция'),
	(74,'GA','Gabon','Gabun','Gabón','GABON','Gabon','Габон'),
	(75,'GB','United Kingdom','Großbritannien und Nordirland','Reino Unido','ROYAUME-UNI','Regno Unito','Великобритания'),
	(76,'GD','Grenada','Grenada','Granada','GRENADE','Grenada','Гренада'),
	(77,'GE','Georgia','Georgien','Georgia','GÉORGIE','Georgia','Грузия'),
	(78,'GF','French Guiana','Französisch-Guayana','Guayana Francesa','GUYANE FRANÇAISE','Guyana francese','Гвиана'),
	(79,'GG','Guernsey','Guernsey (Kanalinsel)','Guernsey','GUERNESEY','Guernsey','Гернси'),
	(80,'GH','Ghana','Ghana','Ghana','GHANA','Ghana','Гана'),
	(81,'GI','Gibraltar','Gibraltar','Gibraltar','GIBRALTAR','Gibilterra','Гибралтар'),
	(82,'GL','Greenland','Grönland','Groenlandia','GROENLAND','Groenlandia','Гренландия'),
	(83,'GM','Gambia','Gambia','Gambia','GAMBIE','Gambia','Гамбия'),
	(84,'GN','Guinea','Guinea','Guinea','GUINÉE','Guinea','Гвинея'),
	(85,'GP','Guadeloupe','Guadeloupe','Guadalupe','GUADELOUPE','Guadalupa','Гваделупа'),
	(86,'GQ','Equatorial Guinea','Äquatorialguinea','Guinea Ecuatorial','GUINÉE ÉQUATORIALE','Guinea Equatoriale','Экваториальная Гвинея'),
	(87,'GR','Greece','Griechenland','Grecia','GRÈCE','Grecia ','Греция'),
	(88,'GS','South Georgia and the South Sandwich Islands','Südgeorgien und die Südl. Sandwichinseln','Georgia del Sur e Islas Sandwich del Sur','GÉORGIE DU SUD ET LES ÎLES SANDWICH DU SUD','Georgia del Sud e isole Sandwich meridionali','Южная Георгия и Южные Сандвичевы Острова'),
	(89,'GT','Guatemala','Guatemala','Guatemala','GUATEMALA','Guatemala','Гватемала'),
	(90,'GU','Guam','Guam','Guam','GUAM','Guam','Гуам'),
	(91,'GW','Guinea-Bissau','Guinea-Bissau','Guinea-Bissau','GUINÉE-BISSAU','Guinea-Bissau','Гвинея-Бисау'),
	(92,'GY','Guyana','Guyana','Guayana','GUYANA','Guyana','Гайана'),
	(93,'HK','Hong Kong S.A.R., China','Hongkong','Hong Kong','HONG KONG','Hong Kong','Гонконг'),
	(94,'HM','Heard Island and McDonald Islands','Heard- und McDonald-Inseln','Islas Heard y McDonald','HEARD ET MACDONALD, ÎLES','Isole Heard e McDonald','Херд и Макдональд'),
	(95,'HN','Honduras','Honduras','Honduras','HONDURAS','Honduras','Гондурас'),
	(96,'HR','Croatia','Kroatien','Croacia','CROATIE','Croazia','Хорватия'),
	(97,'HT','Haiti','Haiti','Haití','HAÏTI','Haiti ','Гаити'),
	(98,'HU','Hungary','Ungarn','Hungría','HONGRIE','Ungheria','Венгрия'),
	(99,'ID','Indonesia','Indonesien','Indonesia','INDONÉSIE','Indonesia','Индонезия'),
	(100,'IE','Ireland','Irland','Irlanda','IRLANDE','Irlanda ','Флаг Ирландии Ирландия'),
	(101,'IL','Israel','Israel','Israel','ISRAËL','Israele ','Израиль'),
	(102,'IM','Isle of Man','Insel Man','Isla de Man','ÎLE DE MAN','Isola di Man','Остров Мэн'),
	(103,'IN','India','Indien','India','INDE','India ','Индия Индия'),
	(104,'IO','British Indian Ocean Territory','Britisches Territorium im Indischen Ozean','Territorio Británico del Océano Índico','OCÉAN INDIEN, TERRITOIRE BRITANNIQUE DE L\'','Territorio britannico dell\'oceano','Британская территория в Индийском океане'),
	(105,'IQ','Iraq','Irak','Irak','IRAQ','Iraq ','Ирак'),
	(106,'IR','Iran','Iran','Irán','IRAN, RÉPUBLIQUE ISLAMIQUE D\'','Iran ','Иран'),
	(107,'IS','Iceland','Island','Islandia','ISLANDE','Islanda ','Исландия'),
	(108,'IT','Italy','Italien','Italia','ITALIE','Italia ','Италия'),
	(109,'JE','Jersey','Jersey (Kanalinsel)','Jersey','JERSEY','Jersey ','Джерси'),
	(110,'JM','Jamaica','Jamaika','Jamaica','JAMAÏQUE','Giamaica','Ямайка'),
	(111,'JO','Jordan','Jordanien','Jordania','JORDANIE','Giordania ','Иордания'),
	(112,'JP','Japan','Japan','Japón','JAPON','Giappone ','Япония'),
	(113,'KE','Kenya','Kenia','Kenia','KENYA','Kenya ','Кения'),
	(114,'KG','Kyrgyzstan','Kirgisistan','Kirguistán','KIRGHIZISTAN','Kirghizistan','Киргизия'),
	(115,'KH','Cambodia','Kambodscha','Camboya','CAMBODGE','Cambogia ','Камбоджа'),
	(116,'KI','Kiribati','Kiribati','Kiribati','KIRIBATI','Kiribati ','Кирибати'),
	(117,'KM','Comoros','Komoren','Comoros','COMORES','Comore ','Коморы'),
	(118,'KN','Saint Kitts and Nevis','St. Kitts und Nevis','San Cristóbal y Nieves','SAINT-KITTS-ET-NEVIS','Saint Kitts e Nevis','Сент-Китс и Невис'),
	(119,'KP','North Korea','Nordkorea','Corea del Norte','CORÉE, RÉPUBLIQUE POPULAIRE DÉMOCRATIQUE DE','Corea del Nord ','КНДР (Корейская Народно-Демократическая Республика)'),
	(120,'KR','South Korea','Südkorea','Corea del Sur','CORÉE, RÉPUBLIQUE DE','Corea del Sud ','Республика Корея'),
	(121,'KW','Kuwait','Kuwait','Kuwait','KOWEÏT','Kuwait ','Кувейт'),
	(122,'KY','Cayman Islands','Kaimaninseln','Islas Caimán','CAÏMANES, ÎLES','Isole Cayman','Острова Кайман'),
	(123,'KZ','Kazakhstan','Kasachstan','Kazajstán','KAZAKHSTAN','Kazakistan ','Казахстан'),
	(124,'LA','Laos','Laos','Laos','LAO, RÉPUBLIQUE DÉMOCRATIQUE POPULAIRE','Laos ','Лаос'),
	(125,'LB','Lebanon','Libanon','Líbano','LIBAN','Libano','Ливан'),
	(126,'LC','Saint Lucia','St. Lucia','Santa Lucía','SAINTE-LUCIE','Santa Lucia','Сент-Люсия'),
	(127,'LI','Liechtenstein','Liechtenstein','Liechtenstein','LIECHTENSTEIN','Liechtenstein','Лихтенштейн'),
	(128,'LK','Sri Lanka','Sri Lanka','Sri Lanka','SRI LANKA','Sri Lanka ','Шри-Ланка'),
	(129,'LR','Liberia','Liberia','Liberia','LIBÉRIA','Liberia ','Либерия'),
	(130,'LS','Lesotho','Lesotho','Lesotho','LESOTHO','Lesotho ','Лесото'),
	(131,'LT','Lithuania','Litauen','Lituania','LITUANIE','Lituania','Литва'),
	(132,'LU','Luxembourg','Luxemburg','Luxemburgo','LUXEMBOURG','Lussemburgo','Люксембург'),
	(133,'LV','Latvia','Lettland','Letonia','LETTONIE','Lettonia ','Латвия'),
	(134,'LY','Libya','Libyen','Libia','LIBYE','Libia ','Ливия'),
	(135,'MA','Morocco','Marokko','Marruecos','MAROC','Marocco','Марокко'),
	(136,'MC','Monaco','Monaco','Mónaco','MONACO','Monaco ','Монако'),
	(137,'MD','Moldova','Moldawien','Moldova','MOLDOVA','Moldavia','Молдавия'),
	(138,'MG','Madagascar','Madagaskar','Madagascar','MADAGASCAR','Madagascar ','Мадагаскар'),
	(139,'MH','Marshall Islands','Marshallinseln','Islas Marshall','MARSHALL, ÎLES','Isole Marshall','Маршалловы Острова'),
	(140,'MK','Macedonia','Mazedonien','Macedonia','MACÉDOINE, L\'EX-RÉPUBLIQUE YOUGOSLAVE DE','Macedonia ','Македония'),
	(141,'ML','Mali','Mali','Mali','MALI','Mali ','Мали'),
	(142,'MM','Myanmar','Myanmar (Burma)','Myanmar','MYANMAR','Birmania','Мьянма'),
	(143,'MN','Mongolia','Mongolei','Mongolia','MONGOLIE','Mongolia','Монголия'),
	(144,'MO','Macao S.A.R., China','Macau','Macao','MACAO','Macao ','Макао'),
	(145,'MP','Northern Mariana Islands','Nördliche Marianen','Islas Marianas del Norte','MARIANNES DU NORD, ÎLES','Isole Marianne Settentrionali','Северные Марианские острова'),
	(146,'MQ','Martinique','Martinique','Martinica','MARTINIQUE','Martinica','Мартиника'),
	(147,'MR','Mauritania','Mauretanien','Mauritania','MAURITANIE','Mauritania','Мавритания'),
	(148,'MS','Montserrat','Montserrat','Montserrat','MONTSERRAT','Montserrat','Монтсеррат'),
	(149,'MT','Malta','Malta','Malta','MALTE','Malta ','Мальта'),
	(150,'MU','Mauritius','Mauritius','Mauricio','MAURICE','Mauritius','Маврикий'),
	(151,'MV','Maldives','Malediven','Maldivas','MALDIVES','Maldive ','Мальдивы'),
	(152,'MW','Malawi','Malawi','Malawi','MALAWI','Malawi ','Малави'),
	(153,'MX','Mexico','Mexiko','México','MEXIQUE','Messico ','Мексика'),
	(154,'MY','Malaysia','Malaysia','Malasia','MALAISIE','Malesia ','Малайзия'),
	(155,'MZ','Mozambique','Mosambik','Mozambique','MOZAMBIQUE','Mozambico','Мозамбик'),
	(156,'NA','Namibia','Namibia','Namibia','NAMIBIE','Namibia ','Намибия'),
	(157,'NC','New Caledonia','Neukaledonien','Nueva Caledonia','NOUVELLE-CALÉDONIE','Nuova Caledonia','Новая Каледония'),
	(158,'NE','Niger','Niger','Níger','NIGER','Niger ','Нигер'),
	(159,'NF','Norfolk Island','Norfolkinsel','Islas Norkfolk','NORFOLK, ÎLE','Isola Norfolk','Остров Норфолк'),
	(160,'NG','Nigeria','Nigeria','Nigeria','NIGÉRIA','Nigeria ','Нигерия'),
	(161,'NI','Nicaragua','Nicaragua','Nicaragua','NICARAGUA','Nicaragua','Никарагуа'),
	(162,'NL','Netherlands','Niederlande','Países Bajos','PAYS-BAS','Paesi Bassi','Нидерланды'),
	(163,'NO','Norway','Norwegen','Noruega','NORVÈGE','Norvegia ','Норвегия'),
	(164,'NP','Nepal','Nepal','Nepal','NÉPAL','Nepal ','Непал'),
	(165,'NR','Nauru','Nauru','Nauru','NAURU','Nauru ','Науру'),
	(166,'NU','Niue','Niue','Niue','NIUÉ','Niue ','Ниуэ'),
	(167,'NZ','New Zealand','Neuseeland','Nueva Zelanda','NOUVELLE-ZÉLANDE','Nuova Zelanda','Новая Зеландия'),
	(168,'OM','Oman','Oman','Omán','OMAN','Oman ','Оман'),
	(169,'PA','Panama','Panama','Panamá','PANAMA','Panamá','Панама'),
	(170,'PE','Peru','Peru','Perú','PÉROU','Perù ','Перу'),
	(171,'PF','French Polynesia','Französisch-Polynesien','Polinesia Francesa','POLYNÉSIE FRANÇAISE','Polinesia Francese ','Французская Полинезия'),
	(172,'PG','Papua New Guinea','Papua-Neuguinea','Papúa Nueva Guinea','PAPOUASIE-NOUVELLE-GUINÉE','Papua Nuova Guinea ','Папуа — Новая Гвинея'),
	(173,'PH','Philippines','Philippinen','Filipinas','PHILIPPINES','Filippine ','Филиппины'),
	(174,'PK','Pakistan','Pakistan','Pakistán','PAKISTAN','Pakistan ','Пакистан'),
	(175,'PL','Poland','Polen','Polonia','POLOGNE','Polonia ','Польша'),
	(176,'PM','Saint Pierre and Miquelon','St. Pierre und Miquelon','San Pedro y Miquelón','SAINT-PIERRE-ET-MIQUELON','Saint-Pierre e Miquelon','Сен-Пьер и Микелон'),
	(177,'PN','Pitcairn','Pitcairninseln','Islas Pitcairn','PITCAIRN','Isole Pitcairn ','Острова Питкэрн'),
	(178,'PR','Puerto Rico','Puerto Rico','Puerto Rico','PORTO RICO','Porto Rico ','Пуэрто-Рико'),
	(179,'PS','Palestine','Palästina','Palestina','ÉTAT DE PALESTINE','Palestina ','Государство Палестина'),
	(180,'PT','Portugal','Portugal','Portugal','PORTUGAL','Portogallo ','Португалия'),
	(181,'PW','Palau','Palau','Islas Palaos','PALAOS','Palau ','Палау'),
	(182,'PY','Paraguay','Paraguay','Paraguay','PARAGUAY','Paraguay ','Парагвай'),
	(183,'QA','Qatar','Katar','Qatar','QATAR','Qatar ','Катар'),
	(184,'RE','Reunion','Réunion','Reunión','RÉUNION','Riunione ','Реюньон'),
	(185,'RO','Romania','Rumänien','Rumanía','ROUMANIE','Romania ','Румыния'),
	(186,'RU','Russia','Russische Föderation','Rusia','RUSSIE, FÉDÉRATION DE','Russia ','Россия'),
	(187,'RW','Rwanda','Ruanda','Ruanda','RWANDA','Ruanda ','Руанда'),
	(188,'SA','Saudi Arabia','Saudi-Arabien','Arabia Saudita','ARABIE SAOUDITE','Arabia Saudita','Саудовская Аравия'),
	(189,'SB','Solomon Islands','Salomonen','Islas Solomón','SALOMON, ÎLES','Isole Salomone','Соломоновы Острова'),
	(190,'SC','Seychelles','Seychellen','Seychelles','SEYCHELLES','Seychelles','Сейшельские Острова'),
	(191,'SD','Sudan','Sudan','Sudán','SOUDAN','Sudan ','Судан'),
	(192,'SE','Sweden','Schweden','Suecia','SUÈDE','Svezia','Швеция'),
	(193,'SG','Singapore','Singapur','Singapur','SINGAPOUR','Singapore','Сингапур'),
	(194,'SH','Saint Helena','St. Helena','Santa Elena','SAINTE-HÉLÈNE, ASCENSION ET TRISTAN DA CUNHA','Sant\'Elena, Ascensione e Tristan da Cunha','Острова Святой Елены, Вознесения и Тристан-да-Кунья'),
	(195,'SI','Slovenia','Slowenien','Eslovenia','SLOVÉNIE','Slovenia Slovenia','Словения'),
	(196,'SJ','Svalbard and Jan Mayen','Svalbard und Jan Mayen','Islas Svalbard y Jan Mayen','SVALBARD ET ÎLE JAN MAYEN','Svalbard e Jan Mayen','Флаг Шпицбергена и Ян-Майена Шпицберген и Ян-Майен'),
	(197,'SK','Slovakia','Slowakei','Eslovaquia','SLOVAQUIE','Slovacchia ','Словакия'),
	(198,'SL','Sierra Leone','Sierra Leone','Sierra Leona','SIERRA LEONE','Sierra Leone','Сьерра-Леоне'),
	(199,'SM','San Marino','San Marino','San Marino','SAINT-MARIN','San Marino ','Сан-Марино'),
	(200,'SN','Senegal','Senegal','Senegal','SÉNÉGAL','Senegal ','Сенегал'),
	(201,'SO','Somalia','Somalia','Somalia','SOMALIE','Somalia ','Сомали'),
	(202,'SR','Suriname','Suriname','Surinam','SURINAME','Suriname','Суринам'),
	(203,'ST','Sao Tome and Principe','São Tomé und Príncipe','Santo Tomé y Príncipe','SAO TOMÉ-ET-PRINCIPE','São Tomé e Príncipe','Сан-Томе и Принсипи'),
	(204,'SV','El Salvador','El Salvador','El Salvador','EL SALVADOR','El Salvador ','Сальвадор'),
	(205,'SY','Syria','Syrien','Siria','SYRIENNE, RÉPUBLIQUE ARABE','Siria ','Сирия'),
	(206,'SZ','Swaziland','Swasiland','Suazilandia','SWAZILAND','Swaziland','Свазиленд'),
	(207,'TC','Turks and Caicos Islands','Turks- und Caicosinseln','Islas Turcas y Caicos','TURKS ET CAÏQUES, ÎLES','Turks e Caicos ','Тёркс и Кайкос'),
	(208,'TD','Chad','Tschad','Chad','TCHAD','Ciad ','Чад'),
	(209,'TF','French Southern Territories','Französische Süd- und Antarktisgebiete','Territorios Australes Franceses','TERRES AUSTRALES FRANÇAISES','Terre australi e antartiche francesi','Французские Южные и Антарктические Территории'),
	(210,'TG','Togo','Togo','Togo','TOGO','Togo ','Того'),
	(211,'TH','Thailand','Thailand','Tailandia','THAÏLANDE','Thailandia','Таиланд'),
	(212,'TJ','Tajikistan','Tadschikistan','Tayikistán','TADJIKISTAN','Tagikistan','Таджикистан'),
	(213,'TK','Tokelau','Tokelau','Tokelau','TOKELAU','Tokelau ','Токелау'),
	(214,'TL','East Timor','Timor-Leste','Timor-Leste','TIMOR-LESTE','Timor Est','Восточный Тимор'),
	(215,'TM','Turkmenistan','Turkmenistan','Turkmenistán','TURKMÉNISTAN','Turkmenistan','Туркмения'),
	(216,'TN','Tunisia','Tunesien','Túnez','TUNISIE','Tunisia ','Тунис'),
	(217,'TO','Tonga','Tonga','Tonga','TONGA','Tonga ','Тонга'),
	(218,'TR','Turkey','Türkei','Turquía','TURQUIE','Turchia','Турция'),
	(219,'TT','Trinidad and Tobago','Trinidad und Tobago','Trinidad y Tobago','TRINITÉ-ET-TOBAGO','Trinidad e Tobago','Тринидад и Тобаго'),
	(220,'TV','Tuvalu','Tuvalu','Tuvalu','TUVALU','Tuvalu ','Тувалу'),
	(221,'TW','Taiwan','Taiwan','Taiwán','TAÏWAN, PROVINCE DE CHINE','Taiwan ','Китайская Республика'),
	(222,'TZ','Tanzania','Tansania','Tanzania','TANZANIE, RÉPUBLIQUE UNIE DE','Tanzania ','Танзания'),
	(223,'UA','Ukraine','Ukraine','Ucrania','UKRAINE','Ucraina ','Украина'),
	(224,'UG','Uganda','Uganda','Uganda','OUGANDA','Uganda ','Уганда'),
	(225,'UM','United States Minor Outlying Islands','Amerikanisch-Ozeanien','Islas menores periféricas de los Estados Unidos','ÎLES MINEURES ÉLOIGNÉES DES ÉTATS-UNIS','Isole minori esterne degli Stati Uniti','Внешние малые острова (США)'),
	(226,'US','United States','Vereinigte Staaten von Amerika','Estados Unidos de América','ÉTATS-UNIS','Stati Uniti','США'),
	(227,'UY','Uruguay','Uruguay','Uruguay','URUGUAY','Uruguay ','Уругвай'),
	(228,'UZ','Uzbekistan','Usbekistan','Uzbekistán','OUZBÉKISTAN','Uzbekistan','Узбекистан'),
	(229,'VA','Vatican','Vatikanstadt','Ciudad del Vaticano','SAINT-SIÈGE (ÉTAT DE LA CITÉ DU VATICAN)','Città del Vaticano','Ватикан'),
	(230,'VC','Saint Vincent and the Grenadines','St. Vincent und die Grenadinen','San Vicente y las Granadinas','SAINT-VINCENT-ET-LES-GRENADINES','Saint Vincent e Grenadine','Сент-Винсент и Гренадины'),
	(231,'VE','Venezuela','Venezuela','Venezuela','VENEZUELA, RÉPUBLIQUE BOLIVARIENNE DU','Venezuela ','Венесуэла'),
	(232,'VG','British Virgin Islands','Britische Jungferninseln','Islas Vírgenes Británicas','ÎLES VIERGES BRITANNIQUES','Isole Vergini britanniche ','Британские Виргинские острова'),
	(233,'VI','U.S. Virgin Islands','Amerikanische Jungferninseln','Islas Vírgenes de los Estados Unidos de América','ÎLES VIERGES DES ÉTATS-UNIS','Isole Vergini americane ','Виргинские Острова (США)'),
	(234,'VN','Vietnam','Vietnam','Vietnam','VIET NAM','Vietnam','Вьетнам'),
	(235,'VU','Vanuatu','Vanuatu','Vanuatu','VANUATU','Vanuatu','Вануату'),
	(236,'WF','Wallis and Futuna','Wallis und Futuna','Wallis y Futuna','WALLIS-ET-FUTUNA','Wallis e Futuna','Уоллис и Футуна'),
	(237,'WS','Samoa','Samoa','Samoa','SAMOA','Samoa ','Самоа'),
	(238,'YE','Yemen','Jemen','Yemen','YÉMEN','Yemen ','Йемен'),
	(239,'YT','Mayotte','Mayotte','Mayotte','MAYOTTE','Mayotte ','Майотта'),
	(240,'ZA','South Africa','Südafrika','Sudáfrica','AFRIQUE DU SUD','Sudafrica ','ЮАР'),
	(241,'ZM','Zambia','Sambia','Zambia','ZAMBIE','Zambia ','Замбия'),
	(242,'ZW','Zimbabwe','Simbabwe','Zimbabue','ZIMBABWE','Zimbabwe','Зимбабве'),
	(243,'RS','Serbia','Serbien','Serbia','SERBIE','Serbia ','Сербия'),
	(244,'ME','Montenegro','Montenegro','Montenegro','MONTÉNÉGRO','Montenegro','Черногория'),
	(245,'BL','Saint Barthelemy !Saint Barthélemy','Saint-Barthélemy','Saint Barthélemy','SAINT-BARTHÉLEMY','Saint-Barthélemy','Сен-Бартелеми'),
	(246,'BQ','Bonaire, Sint Eustatius and Saba','Bonaire, Sint Eustatius und Saba','Bonaire, San Eustaquio y Saba','BONAIRE, SAINT-EUSTACHE ET SABA','Isole BES','Синт-Эстатиус и Саба'),
	(247,'CW','Curacao !Curaçao','Curaçao','Curaçao','CURAÇAO','Curaçao','Кюрасао'),
	(248,'MF','Saint Martin (French part)','Saint-Martin (franz. Teil)','Saint Martin (parte francesa)','SAINT-MARTIN (PARTIE FRANÇAISE)','Saint-Martin','Сен-Мартен'),
	(249,'SX','Sint Maarten (Dutch part)','Sint Maarten (niederl. Teil)','Sint Maarten (parte neerlandesa)','SAINT-MARTIN (PARTIE NÉERLANDAISE)','Sint Maarten ','Синт-Мартен'),
	(250,'SS','South Sudan','Sudsudan!Südsudan','Sudán del Sur','SOUDAN DU SUD','Sudan del Sud','Южный Судан');

/*!40000 ALTER TABLE `countries` ENABLE KEYS */;
UNLOCK TABLES;


# Tabellen-Dump crane_dates
# ------------------------------------------------------------

DROP TABLE IF EXISTS `crane_dates`;

CREATE TABLE `crane_dates` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `cranable_type` varchar(50) NOT NULL,
  `cranable_id` int(11) unsigned NOT NULL,
  `date` datetime DEFAULT NULL,
  `crane_date` date NOT NULL,
  `crane_time` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cranable_type` (`cranable_type`,`cranable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

LOCK TABLES `crane_dates` WRITE;
/*!40000 ALTER TABLE `crane_dates` DISABLE KEYS */;

INSERT INTO `crane_dates` (`id`, `cranable_type`, `cranable_id`, `date`, `crane_date`, `crane_time`)
VALUES
	(1,'App\\Models\\Boat',35,'2023-07-22 14:00:00','2023-07-22','14:00:00'),
	(2,'App\\Models\\GuestBoat',3,'2023-06-21 10:00:00','2023-06-21','10:00:00'),
	(3,'App\\Models\\Boat',3,'2023-06-23 13:00:00','2023-06-23','13:00:00');

/*!40000 ALTER TABLE `crane_dates` ENABLE KEYS */;
UNLOCK TABLES;


# Tabellen-Dump customers
# ------------------------------------------------------------

DROP TABLE IF EXISTS `customers`;

CREATE TABLE `customers` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `type` enum('guest','permanent','renter') NOT NULL DEFAULT 'guest',
  `name` varchar(50) NOT NULL DEFAULT '',
  `email` varchar(50) DEFAULT '',
  `password` varchar(100) DEFAULT '',
  `remember_token` varchar(100) DEFAULT NULL,
  `fon` varchar(50) DEFAULT NULL,
  `state` varchar(50) DEFAULT NULL,
  `street` varchar(50) DEFAULT NULL,
  `postcode` varchar(20) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `confirmed` tinyint(1) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `customer_type` (`type`),
  KEY `email` (`email`,`password`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

LOCK TABLES `customers` WRITE;
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;

INSERT INTO `customers` (`id`, `type`, `name`, `email`, `password`, `remember_token`, `fon`, `state`, `street`, `postcode`, `city`, `confirmed`)
VALUES
	(2,'permanent','Marc Müller','info@krug.de','$2y$10$kSM5BQyRurU90a.IG4i/9.pf05c4zlIrw46KPjUVjND.R6RPpslSe',NULL,'3833756575','Mecklenburg-Vorpommern','Dorfstrasse 3','17111','Lottow',1),
	(3,'permanent','Test-Kunde','kunde@test.loc','$2y$10$rSA.qLnnHFI0JnmtyslX7eoITK7uhVhv2o3/lSd8l2qiAkOtAk3/u','e3XJw9vYRr41d800fEPy85USn100kT4Cwt2BdxPAAgEGWtSJsALtRhyYN55q','13456778',NULL,'Dorfstrasse 32','17440','Dummersbach',1),
	(5,'permanent','André Meier','a.meier@test.de','$2y$10$yxi6FYNzrUhEqjlTjFO.xebQ9BBoma7XP4vOW6fDZf0tGyTJyh5sq',NULL,'+493043423523',NULL,'Müller Weg 24','13000','Berlin',1),
	(7,'renter','Paul Hausboot','bta@goldenacker.de','$2y$10$GM3SOWuRZndR3uQZwCGNcOxUZGQvvWdE.2RzFJE2pZ8MNiKWBiWkS',NULL,'490302816477',NULL,'Hauptstrasse 45','12456','Dummersbach',1),
	(8,'permanent','Bernd Engels','engels@f50.de','$2y$10$Z/er9B9OqL1mUW43syvp5Oe7rAo5plnadgZNEkkFSQwbFvSH0flRG',NULL,'038372 766960',NULL,'Am Bodden 18','17373','Dummersbach',1),
	(9,'renter','Liese Hausboot','engels@f50.de','$2y$10$TKXFVePi0TfI8broXsQKRulDnYdRUd2jQ2UE.yAAwecFRUIRDlTIy',NULL,'+ 49 176 19 25 96 43',NULL,'Am Fährberg 9','18565','Dummersbach',1),
	(10,'renter','Kunde Hausboot','test@test.com','$2y$10$/vIpHGl/FODKbj4sSxMcYuvDaV4iuGAB2kaUGOPBlrqu./3R05hOm',NULL,'12345678',NULL,'Am Hafen 1','18551','Dummersbach',1),
	(12,'renter','Kunde Haus','test@testtt.com','$2y$10$va3eu0Mzt0/WWQeQb54I5e8eWarIM37C7FCEMc54qS9ez8Z.m.x3a',NULL,'+49 151 58502706',NULL,'Am Breetzer Bodden 22','18556','Lüppel',1),
	(13,'renter','Kunde Apartment','test@tesst.com','$2y$10$exRhKKZrPbyGCiBVDWF6iOuf6OLHXHdcZ9gL9N5BCV1jvRQH5egLq',NULL,'+49 162 188 77 66',NULL,'Am Bollwerk 6','17375','Lammhausen',1),
	(14,'renter','Max Pinsel','pinsel@mailtrap.io','$2y$10$S7Ztu/cac5y464jlz7mdcuRZXrUNwT1IF5gWs2rp9ThMHDAQD49by',NULL,'12345678',NULL,'Dorfstrasse 24','18439','Lüppel',1),
	(15,'renter','Rob Maxwell','maxwel@mailtrap.io','$2y$10$qMVkk/XMXqKlGE2aYZLJPeLJfNrDdlQpYybjZthOyjOZ9PrVgaG2e',NULL,'12345678',NULL,'Hafenstraße 12/Haus D','18519','Lammhausen',1),
	(18,'renter','Bernd Engels','renter@goldenacker.de','$2y$10$9HOlPipVoto/SpONvHS/DuKRgijbMKjBEnxkA5kpAq7eVBs8Kfr7S',NULL,'12345678',NULL,'Dorfstraße 8a','10117','Berlin',1),
	(19,'permanent','Bernd Engels','engels@goldenacker.de','$2y$10$mG2XsspKG862/E39KyS4X.fPXX5hDO13hWGa3F36aMj2fvFVCuy/W',NULL,'+491791014302',NULL,'Ackerstr. 22','10115','Berlin',1),
	(20,'permanent','PaulTestman n','engels@test.de','$2y$10$z8uT4h/fV/m29Ooror1t5.M7T8bo3ivNKb/OCj8m39am6AFXegNq.',NULL,NULL,NULL,NULL,NULL,NULL,0),
	(21,'permanent','Adam Paulmann','admin@test.loc','$2y$10$vI73QIwV8vWMVTCc..Xb6ONQLcNlHK/y5Qjsk4IhlxnDR2tpRlp/O',NULL,NULL,NULL,NULL,NULL,NULL,1);

/*!40000 ALTER TABLE `customers` ENABLE KEYS */;
UNLOCK TABLES;


# Tabellen-Dump docks
# ------------------------------------------------------------

DROP TABLE IF EXISTS `docks`;

CREATE TABLE `docks` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  `length` tinyint(3) unsigned DEFAULT NULL,
  `min_box_length` tinyint(3) unsigned DEFAULT NULL,
  `max_box_length` tinyint(3) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

LOCK TABLES `docks` WRITE;
/*!40000 ALTER TABLE `docks` DISABLE KEYS */;

INSERT INTO `docks` (`id`, `name`, `length`, `min_box_length`, `max_box_length`)
VALUES
	(1,'A',200,5,12),
	(2,'B',35,NULL,NULL);

/*!40000 ALTER TABLE `docks` ENABLE KEYS */;
UNLOCK TABLES;


# Tabellen-Dump failed_jobs
# ------------------------------------------------------------

DROP TABLE IF EXISTS `failed_jobs`;

CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Tabellen-Dump guest_boat_dates
# ------------------------------------------------------------

DROP TABLE IF EXISTS `guest_boat_dates`;

CREATE TABLE `guest_boat_dates` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `guest_boat_id` int(11) unsigned NOT NULL,
  `berth_id` int(11) unsigned DEFAULT NULL,
  `from` date NOT NULL,
  `until` date NOT NULL,
  `persons` tinyint(2) unsigned NOT NULL,
  `electric` tinyint(1) unsigned DEFAULT NULL,
  `price` int(10) unsigned NOT NULL,
  `prices` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`prices`)),
  `is_paid` tinyint(1) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `caravan_id` (`guest_boat_id`),
  KEY `from` (`from`,`until`),
  KEY `price` (`price`),
  KEY `is_paid` (`is_paid`),
  KEY `guest_boat_berth_id` (`berth_id`),
  CONSTRAINT `guest_boat_dates_ibfk_1` FOREIGN KEY (`guest_boat_id`) REFERENCES `guest_boats` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

LOCK TABLES `guest_boat_dates` WRITE;
/*!40000 ALTER TABLE `guest_boat_dates` DISABLE KEYS */;

INSERT INTO `guest_boat_dates` (`id`, `guest_boat_id`, `berth_id`, `from`, `until`, `persons`, `electric`, `price`, `prices`, `is_paid`)
VALUES
	(4,2,22,'2021-09-29','2021-10-01',4,1,58,X'7B22707269636542617365223A34382C226461696C79507269636573223A7B22323032312D30392D3239223A7B227072696365223A32342C22736169736F6E223A224861757074736169736F6E227D2C22323032312D30392D3330223A7B227072696365223A32342C22736169736F6E223A224861757074736169736F6E227D7D2C227072696365456C656374726963223A362C227072696365506572736F6E73223A342C2264617973223A322C22746178223A31392C226E6574746F223A34382C227461785072696365223A31302C22746F74616C223A35387D',1),
	(5,2,23,'2023-02-02','2023-02-03',2,1,20,X'7B22707269636542617365223A31382C226461696C79507269636573223A7B22323032332D30322D3032223A7B227072696365223A31382C22736169736F6E223A224E6562656E736169736F6E227D7D2C227072696365456C656374726963223A322C227072696365506572736F6E73223A302C2264617973223A312C22746178223A31392C226E6574746F223A31362C227461785072696365223A342C22746F74616C223A32307D',1),
	(6,3,22,'2023-02-07','2023-02-08',2,1,17,X'7B22707269636542617365223A31352C226461696C79507269636573223A7B22323032332D30322D3037223A7B227072696365223A31352C22736169736F6E223A224E6562656E736169736F6E227D7D2C227072696365456C656374726963223A322C227072696365506572736F6E73223A302C2264617973223A312C22746178223A31392C226E6574746F223A31342C227461785072696365223A332C22746F74616C223A31377D',1),
	(7,3,23,'2023-07-01','2023-07-02',2,1,22,X'7B22707269636542617365223A32302C226461696C79507269636573223A7B22323032332D30372D3031223A7B227072696365223A32302C22736169736F6E223A224861757074736169736F6E227D7D2C227072696365456C656374726963223A322C227072696365506572736F6E73223A302C2264617973223A312C22746178223A31392C226E6574746F223A31382C227461785072696365223A342C22746F74616C223A32327D',1);

/*!40000 ALTER TABLE `guest_boat_dates` ENABLE KEYS */;
UNLOCK TABLES;


# Tabellen-Dump guest_boats
# ------------------------------------------------------------

DROP TABLE IF EXISTS `guest_boats`;

CREATE TABLE `guest_boats` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL DEFAULT '',
  `length` decimal(3,1) unsigned NOT NULL,
  `home_port` varchar(50) NOT NULL DEFAULT '',
  `email` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

LOCK TABLES `guest_boats` WRITE;
/*!40000 ALTER TABLE `guest_boats` DISABLE KEYS */;

INSERT INTO `guest_boats` (`id`, `name`, `length`, `home_port`, `email`)
VALUES
	(2,'Elise II',12.0,'Seedorf','engels@f50.de'),
	(3,'Lagune',10.0,'Sassnitz','engels@goldenacker.de');

/*!40000 ALTER TABLE `guest_boats` ENABLE KEYS */;
UNLOCK TABLES;


# Tabellen-Dump house_models
# ------------------------------------------------------------

DROP TABLE IF EXISTS `house_models`;

CREATE TABLE `house_models` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `space` int(10) unsigned NOT NULL,
  `floors` tinyint(1) unsigned NOT NULL,
  `sleeping_places` tinyint(2) unsigned NOT NULL,
  `peak_season_price` int(10) unsigned DEFAULT NULL,
  `mid_season_price` int(10) unsigned DEFAULT NULL,
  `low_season_price` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

LOCK TABLES `house_models` WRITE;
/*!40000 ALTER TABLE `house_models` DISABLE KEYS */;

INSERT INTO `house_models` (`id`, `name`, `description`, `space`, `floors`, `sleeping_places`, `peak_season_price`, `mid_season_price`, `low_season_price`)
VALUES
	(1,'Haus Grande','Das ist unser größtes Haus.',240,2,8,220,180,140),
	(2,'Haus Medium','Das ist unser mittelgroßes Haus.',140,2,6,180,160,130),
	(3,'Haus Petite','Das ist unser kleinstes Haus.',100,1,4,150,130,110);

/*!40000 ALTER TABLE `house_models` ENABLE KEYS */;
UNLOCK TABLES;


# Tabellen-Dump houseboat_models
# ------------------------------------------------------------

DROP TABLE IF EXISTS `houseboat_models`;

CREATE TABLE `houseboat_models` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `space` int(10) unsigned NOT NULL,
  `floors` tinyint(1) unsigned NOT NULL,
  `sleeping_places` tinyint(2) unsigned NOT NULL,
  `peak_season_price` int(10) unsigned DEFAULT NULL,
  `mid_season_price` int(10) unsigned DEFAULT NULL,
  `low_season_price` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

LOCK TABLES `houseboat_models` WRITE;
/*!40000 ALTER TABLE `houseboat_models` DISABLE KEYS */;

INSERT INTO `houseboat_models` (`id`, `name`, `description`, `space`, `floors`, `sleeping_places`, `peak_season_price`, `mid_season_price`, `low_season_price`)
VALUES
	(1,'Grande','Das ist unser größtes Hausboot.',120,2,8,220,180,140),
	(2,'Medium','Das ist unser mittelgroßes Hausboot.',80,2,6,180,160,130),
	(3,'Petite','Das ist unser kleinstes Hausboot.',60,1,4,150,130,110);

/*!40000 ALTER TABLE `houseboat_models` ENABLE KEYS */;
UNLOCK TABLES;


# Tabellen-Dump houseboat_owners
# ------------------------------------------------------------

DROP TABLE IF EXISTS `houseboat_owners`;

CREATE TABLE `houseboat_owners` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL DEFAULT '',
  `email` varchar(50) NOT NULL DEFAULT '',
  `city` varchar(50) NOT NULL DEFAULT '',
  `postcode` varchar(10) NOT NULL DEFAULT '',
  `street` varchar(50) NOT NULL DEFAULT '',
  `fon` varchar(50) NOT NULL DEFAULT '',
  `bank` varchar(50) NOT NULL DEFAULT '',
  `iban` varchar(50) NOT NULL DEFAULT '',
  `bic` varchar(20) NOT NULL DEFAULT '',
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `updated_at` (`updated_at`,`created_at`),
  KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

LOCK TABLES `houseboat_owners` WRITE;
/*!40000 ALTER TABLE `houseboat_owners` DISABLE KEYS */;

INSERT INTO `houseboat_owners` (`id`, `name`, `email`, `city`, `postcode`, `street`, `fon`, `bank`, `iban`, `bic`, `created_at`, `updated_at`)
VALUES
	(1,'Hugo Stinkreich','engels@f50.de','Dummersbach','12456','Dorfstrasse 32','01791014302','Berliner Sparkasse','DE40 23787128218711','assa133','2022-06-25 14:20:41','2022-06-25 14:20:41'),
	(2,'Donald Duck','test@google.de','Berlin','10117','Kirchstraße 5','+49302816477','Berliner Sparkasse','DE40 23787128218711','assa133','2022-06-25 14:29:59','2022-06-25 14:29:59');

/*!40000 ALTER TABLE `houseboat_owners` ENABLE KEYS */;
UNLOCK TABLES;


# Tabellen-Dump houseboats
# ------------------------------------------------------------

DROP TABLE IF EXISTS `houseboats`;

CREATE TABLE `houseboats` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `houseboat_model_id` int(11) unsigned NOT NULL,
  `houseboat_owner_id` int(11) unsigned DEFAULT NULL,
  `name` varchar(50) NOT NULL DEFAULT '',
  `calendar_color` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `houseboat_model_id` (`houseboat_model_id`),
  KEY `houseboat_owner_id` (`houseboat_owner_id`),
  CONSTRAINT `houseboats_ibfk_1` FOREIGN KEY (`houseboat_model_id`) REFERENCES `houseboat_models` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `houseboats_ibfk_2` FOREIGN KEY (`houseboat_owner_id`) REFERENCES `houseboat_owners` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

LOCK TABLES `houseboats` WRITE;
/*!40000 ALTER TABLE `houseboats` DISABLE KEYS */;

INSERT INTO `houseboats` (`id`, `houseboat_model_id`, `houseboat_owner_id`, `name`, `calendar_color`)
VALUES
	(1,1,1,'Bellinda','#ea211e'),
	(2,2,2,'Pauline','#005392'),
	(3,3,NULL,'Hansi','#009192');

/*!40000 ALTER TABLE `houseboats` ENABLE KEYS */;
UNLOCK TABLES;


# Tabellen-Dump houses
# ------------------------------------------------------------

DROP TABLE IF EXISTS `houses`;

CREATE TABLE `houses` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `house_model_id` int(11) unsigned NOT NULL,
  `name` varchar(50) NOT NULL DEFAULT '',
  `calendar_color` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `houseboat_model_id` (`house_model_id`),
  CONSTRAINT `houses_ibfk_1` FOREIGN KEY (`house_model_id`) REFERENCES `houseboat_models` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

LOCK TABLES `houses` WRITE;
/*!40000 ALTER TABLE `houses` DISABLE KEYS */;

INSERT INTO `houses` (`id`, `house_model_id`, `name`, `calendar_color`)
VALUES
	(1,1,'Möwe','#ea211e'),
	(2,2,'Wind','#005392'),
	(3,3,'Sand','#009192');

/*!40000 ALTER TABLE `houses` ENABLE KEYS */;
UNLOCK TABLES;


# Tabellen-Dump material_categories
# ------------------------------------------------------------

DROP TABLE IF EXISTS `material_categories`;

CREATE TABLE `material_categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `modus` enum('underwater','board','deck','all') DEFAULT 'underwater',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `material_categories` WRITE;
/*!40000 ALTER TABLE `material_categories` DISABLE KEYS */;

INSERT INTO `material_categories` (`id`, `name`, `modus`)
VALUES
	(1,'Unterwasser Anstrich','underwater'),
	(2,'Unterwasser Reinigung','underwater'),
	(3,'Unterwasserschiff Schleifen','underwater'),
	(4,'Motor','all'),
	(5,'Elektrik','all'),
	(6,'Wachs','board'),
	(7,'Überwasser Anstrich','board'),
	(8,'Überwasser Reinigung','board'),
	(9,'Unterwasser Voranstrich','underwater'),
	(10,'Osmose Schutz','underwater');

/*!40000 ALTER TABLE `material_categories` ENABLE KEYS */;
UNLOCK TABLES;


# Tabellen-Dump materials
# ------------------------------------------------------------

DROP TABLE IF EXISTS `materials`;

CREATE TABLE `materials` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `material_category_id` int(10) unsigned NOT NULL,
  `price_type_id` int(10) unsigned NOT NULL,
  `name` varchar(100) NOT NULL,
  `price_per_unit` decimal(10,2) unsigned NOT NULL,
  `fertility` decimal(11,2) unsigned DEFAULT NULL,
  `fertility_per` enum('Meter','Quadratmeter','Liter') DEFAULT 'Meter',
  `fertility_unit` enum('Meter','Quadratmeter','Liter') DEFAULT 'Meter',
  PRIMARY KEY (`id`),
  KEY `materials_ibfk_1` (`material_category_id`),
  KEY `materials_ibfk_2` (`price_type_id`),
  CONSTRAINT `materials_ibfk_1` FOREIGN KEY (`material_category_id`) REFERENCES `material_categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `materials_ibfk_2` FOREIGN KEY (`price_type_id`) REFERENCES `config_price_types` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `materials` WRITE;
/*!40000 ALTER TABLE `materials` DISABLE KEYS */;

INSERT INTO `materials` (`id`, `material_category_id`, `price_type_id`, `name`, `price_per_unit`, `fertility`, `fertility_per`, `fertility_unit`)
VALUES
	(1,1,2,'International Antifouling VC 17m® Extra',50.00,5.85,'Liter','Quadratmeter'),
	(2,1,2,'International Antifouling VC 17m Graphit',60.00,5.85,'Liter','Quadratmeter'),
	(3,1,2,'International Antifouling VC 17m Blau',60.00,5.85,'Liter','Quadratmeter'),
	(4,6,2,'Yachticon Boot Wachs',34.00,18.00,'Liter','Meter'),
	(5,6,2,'AWN flüssiges Bootwachs',24.00,18.00,'Liter','Liter'),
	(6,8,2,'Yachticon Anti Gilb',32.00,50.00,'Liter','Quadratmeter'),
	(7,1,2,'AWN Selbstpolierendes Antifouling',30.65,9.00,'Quadratmeter','Liter'),
	(8,9,2,'Unterwasser-Primer',22.65,8.00,'Liter','Quadratmeter'),
	(9,10,2,'Gelshield 200 Osmose-Schutz Grundierung - grau',39.99,9.00,'Liter','Quadratmeter'),
	(10,10,2,'Gelshield 200 Osmose-Schutz Grundierung - grün',39.99,9.00,'Liter','Quadratmeter');

/*!40000 ALTER TABLE `materials` ENABLE KEYS */;
UNLOCK TABLES;


# Tabellen-Dump media
# ------------------------------------------------------------

DROP TABLE IF EXISTS `media`;

CREATE TABLE `media` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `model_type` varchar(191) NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  `uuid` char(36) DEFAULT NULL,
  `collection_name` varchar(191) NOT NULL,
  `name` varchar(191) NOT NULL,
  `file_name` varchar(191) NOT NULL,
  `mime_type` varchar(191) DEFAULT NULL,
  `disk` varchar(191) NOT NULL,
  `conversions_disk` varchar(191) DEFAULT NULL,
  `size` bigint(20) unsigned NOT NULL,
  `manipulations` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`manipulations`)),
  `custom_properties` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`custom_properties`)),
  `generated_conversions` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`generated_conversions`)),
  `responsive_images` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`responsive_images`)),
  `order_column` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `media_uuid_unique` (`uuid`),
  KEY `media_model_type_model_id_index` (`model_type`,`model_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `media` WRITE;
/*!40000 ALTER TABLE `media` DISABLE KEYS */;

INSERT INTO `media` (`id`, `model_type`, `model_id`, `uuid`, `collection_name`, `name`, `file_name`, `mime_type`, `disk`, `conversions_disk`, `size`, `manipulations`, `custom_properties`, `generated_conversions`, `responsive_images`, `order_column`, `created_at`, `updated_at`)
VALUES
	(1,'App\\Models\\HouseModel',1,'5ea7c703-032f-4213-a2e2-a735a6f8fca2','houseModel','haus_in_strasse','haus_in_strasse.jpg','image/jpeg','images','images',79788,X'5B5D',X'5B5D',X'7B227468756D62223A747275652C226D6F62696C65223A747275652C226C61726765223A747275657D',X'5B5D',1,'2023-06-29 17:40:55','2023-06-29 17:40:55'),
	(2,'App\\Models\\HouseModel',1,'5b69dd18-c16e-457b-a01f-00dfa0cfad35','houseModel','robben','robben.jpg','image/jpeg','images','images',43074,X'5B5D',X'5B5D',X'7B227468756D62223A747275652C226D6F62696C65223A747275652C226C61726765223A747275657D',X'5B5D',2,'2023-06-29 17:41:02','2023-06-29 17:41:02'),
	(3,'App\\Models\\HouseModel',1,'50fa795e-93b1-4b86-a75b-bd46b8b0a6e8','houseModel','schweden2','schweden2.jpg','image/jpeg','images','images',911964,X'5B5D',X'5B5D',X'7B227468756D62223A747275652C226D6F62696C65223A747275652C226C61726765223A747275657D',X'5B5D',3,'2023-06-29 17:41:07','2023-06-29 17:41:07'),
	(4,'App\\Models\\ApartmentModel',1,'cd9f3cf8-130c-4954-9386-33531f2f4995','apartmentModel','pamina_helgoland','pamina_helgoland.jpg','image/jpeg','images','images',317958,X'5B5D',X'5B5D',X'7B227468756D62223A747275652C226D6F62696C65223A747275652C226C61726765223A747275657D',X'5B5D',1,'2023-06-29 17:46:25','2023-06-29 17:46:26'),
	(5,'App\\Models\\HouseboatModel',1,'de4cda01-8fac-40d4-aafa-2e3c35bb0cf4','houseboatModel','pamina_vor_amrum','pamina_vor_amrum.jpg','image/jpeg','images','images',687227,X'5B5D',X'5B5D',X'7B227468756D62223A747275652C226D6F62696C65223A747275652C226C61726765223A747275657D',X'5B5D',1,'2023-06-29 17:46:46','2023-06-29 17:46:47'),
	(6,'App\\Models\\Boat',2,'81dfeccf-942c-4771-9d36-c114e897f2ed','boat','hooge_parking','hooge_parking.jpg','image/jpeg','images','images',252373,X'5B5D',X'5B5D',X'7B227468756D62223A747275652C226D6F62696C65223A747275652C226C61726765223A747275657D',X'5B5D',1,'2023-06-29 17:48:35','2023-06-29 17:48:36'),
	(7,'App\\Models\\Boat',2,'5f615a49-f8e4-4122-bc3f-0d9a3bfc1101','boat','pamina_maße','pamina_maße.jpg','image/jpeg','images','images',150529,X'5B5D',X'5B5D',X'7B227468756D62223A747275652C226D6F62696C65223A747275652C226C61726765223A747275657D',X'5B5D',2,'2023-06-29 17:48:47','2023-06-29 17:48:47'),
	(8,'App\\Models\\Boat',2,'c16dff66-60e6-4c4d-bc69-310ede1304bc','boat','schweden1','schweden1.jpg','image/jpeg','images','images',969793,X'5B5D',X'5B5D',X'7B227468756D62223A747275652C226D6F62696C65223A747275652C226C61726765223A747275657D',X'5B5D',3,'2023-06-29 17:49:04','2023-06-29 17:49:05');

/*!40000 ALTER TABLE `media` ENABLE KEYS */;
UNLOCK TABLES;


# Tabellen-Dump migrations
# ------------------------------------------------------------

DROP TABLE IF EXISTS `migrations`;

CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;

INSERT INTO `migrations` (`id`, `migration`, `batch`)
VALUES
	(1,'2014_10_12_000000_create_users_table',1),
	(2,'2014_10_12_100000_create_password_resets_table',1),
	(3,'2014_10_12_200000_add_two_factor_columns_to_users_table',1),
	(4,'2019_08_19_000000_create_failed_jobs_table',1),
	(5,'2019_12_14_000001_create_personal_access_tokens_table',1),
	(6,'2020_05_21_100000_create_teams_table',1),
	(7,'2020_05_21_200000_create_team_user_table',1),
	(8,'2020_05_21_300000_create_team_invitations_table',1),
	(9,'2021_08_09_214411_create_permission_tables',1),
	(10,'2021_08_25_115413_create_sessions_table',1),
	(11,'2021_10_20_204903_create_admin_password_resets_table',0),
	(12,'2021_10_20_204903_create_admin_users_table',0),
	(13,'2021_10_20_204903_create_boat_dates_table',0),
	(14,'2021_10_20_204904_create_guest_boat_dates_table',0),
	(15,'2021_10_20_204903_create_guest_boats_table',0),
	(16,'2021_10_20_204903_create_boats_table',0),
	(17,'2021_10_20_204903_create_car_license_plates_table',0),
	(18,'2021_10_20_204904_create_caravan_dates_table',0),
	(19,'2021_10_20_204903_create_caravans_table',0),
	(20,'2021_10_20_204903_create_countries_table',0),
	(21,'2021_10_20_204903_create_customers_table',0),
	(22,'2021_10_20_204903_create_failed_jobs_table',0),
	(23,'2021_10_20_204903_create_model_has_permissions_table',0),
	(24,'2021_10_20_204903_create_model_has_roles_table',0),
	(25,'2021_10_20_204903_create_pages_table',0),
	(26,'2021_10_20_204903_create_password_resets_table',0),
	(27,'2021_10_20_204903_create_permissions_table',0),
	(28,'2021_10_20_204903_create_personal_access_tokens_table',0),
	(29,'2021_10_20_204903_create_role_has_permissions_table',0),
	(30,'2021_10_20_204903_create_roles_table',0),
	(31,'2021_10_20_204903_create_sessions_table',0),
	(32,'2021_10_20_204903_create_users_table',0),
	(33,'2021_10_20_204903_create_widgets_table',0),
	(34,'2021_10_20_204905_add_foreign_keys_to_boat_guest_dates_table',0),
	(35,'2021_10_20_204905_add_foreign_keys_to_caravan_dates_table',0),
	(36,'2021_10_20_204905_add_foreign_keys_to_model_has_permissions_table',0),
	(37,'2021_10_20_204905_add_foreign_keys_to_model_has_roles_table',0),
	(38,'2021_10_20_204905_add_foreign_keys_to_role_has_permissions_table',0),
	(39,'2021_10_20_204906_add_foreign_keys_to_boat_dates_table',2),
	(40,'2021_10_20_204907_add_foreign_keys_to_boat_table',2),
	(41,'2021_10_23_151401_create_dashboard_tiles_table',2),
	(42,'2021_11_28_184010_create_boat_prices_table',0),
	(43,'2021_11_28_184010_create_daily_prices_table',0),
	(44,'2021_11_28_184011_add_foreign_keys_to_boat_prices_table',0),
	(45,'2021_11_28_184011_add_foreign_keys_to_daily_prices_table',0),
	(46,'2021_12_07_193630_create_config_services_table',0),
	(47,'2021_12_07_193630_create_config_entity_types_table',0),
	(48,'2021_12_07_193630_create_config_price_components_table',0),
	(49,'2021_12_07_193630_create_config_has_price_components_table',0),
	(50,'2021_12_07_193631_add_foreign_keys_to_config_price_components_table',0),
	(51,'2022_03_12_194011_create_houseboats_table',0),
	(52,'2022_03_12_194011_create_houseboats_dates_table',0),
	(53,'2022_03_12_194012_add_foreign_keys_to_houseboats_dates_table',0),
	(54,'2022_03_12_212401_create_offers_table',0),
	(55,'2022_03_13_103143_create_houseboat_models_table',0),
	(56,'2022_03_13_195709_create_config_saison_rents_table',0),
	(57,'2022_03_13_195709_create_config_saison_rent_dates_table',0),
	(58,'2022_03_13_195711_add_foreign_keys_to_config_saison_rent_dates_table',0),
	(59,'2022_04_03_165746_create_config_holidays_table',0),
	(60,'2022_04_10_121747_create_houseboat_guests_table',0),
	(61,'2022_04_10_121748_add_foreign_keys_to_houseboat_guests_table',0),
	(62,'2016_06_01_000001_create_oauth_auth_codes_table',3),
	(63,'2016_06_01_000002_create_oauth_access_tokens_table',3),
	(64,'2016_06_01_000003_create_oauth_refresh_tokens_table',3),
	(65,'2016_06_01_000004_create_oauth_clients_table',3),
	(66,'2016_06_01_000005_create_oauth_personal_access_clients_table',3),
	(67,'2021_11_02_145658_create_media_table',4),
	(68,'2022_06_19_190914_create_guest_boat_berths_table',0),
	(69,'2022_07_01_004024_create_boat_docks_table',0),
	(70,'2022_07_12_170232_create_config_port_table',0),
	(71,'2022_07_12_170232_create_berth_categories_table',0),
	(72,'2022_12_08_201447_create_berth_maps_table',0),
	(73,'2022_12_28_184451_create_house_models_table',0),
	(74,'2022_12_28_184451_create_apartments_table',0),
	(75,'2022_12_28_184451_create_houses_table',0),
	(76,'2022_12_28_184451_create_rentables_table',0),
	(77,'2022_12_28_184452_add_foreign_keys_to_apartments_table',0),
	(78,'2022_12_28_184452_add_foreign_keys_to_houses_table',0),
	(79,'2022_12_28_184452_add_foreign_keys_to_rentables_table',0),
	(80,'2023_01_02_183428_create_apartment_models_table',0),
	(81,'2023_01_06_165616_create_contacts_table',0),
	(82,'2023_01_31_190816_create_access_logs_table',0);

/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;


# Tabellen-Dump model_has_permissions
# ------------------------------------------------------------

DROP TABLE IF EXISTS `model_has_permissions`;

CREATE TABLE `model_has_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL,
  `model_type` varchar(255) NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Tabellen-Dump model_has_roles
# ------------------------------------------------------------

DROP TABLE IF EXISTS `model_has_roles`;

CREATE TABLE `model_has_roles` (
  `role_id` bigint(20) unsigned NOT NULL,
  `model_type` varchar(255) NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `model_has_roles` WRITE;
/*!40000 ALTER TABLE `model_has_roles` DISABLE KEYS */;

INSERT INTO `model_has_roles` (`role_id`, `model_type`, `model_id`)
VALUES
	(1,'App\\Models\\Customer',1),
	(1,'App\\Models\\Customer',2),
	(1,'App\\Models\\Customer',3),
	(1,'App\\Models\\Customer',6),
	(1,'App\\Models\\Customer',8),
	(1,'App\\Models\\Customer',18),
	(1,'App\\Models\\Customer',19),
	(1,'App\\Models\\Customer',20),
	(1,'App\\Models\\Customer',21),
	(3,'App\\Models\\AdminUser',3),
	(5,'App\\Models\\AdminUser',3);

/*!40000 ALTER TABLE `model_has_roles` ENABLE KEYS */;
UNLOCK TABLES;


# Tabellen-Dump oauth_access_tokens
# ------------------------------------------------------------

DROP TABLE IF EXISTS `oauth_access_tokens`;

CREATE TABLE `oauth_access_tokens` (
  `id` varchar(100) NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `client_id` bigint(20) unsigned NOT NULL,
  `name` varchar(191) DEFAULT NULL,
  `scopes` text DEFAULT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_access_tokens_user_id_index` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Tabellen-Dump oauth_auth_codes
# ------------------------------------------------------------

DROP TABLE IF EXISTS `oauth_auth_codes`;

CREATE TABLE `oauth_auth_codes` (
  `id` varchar(100) NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `client_id` bigint(20) unsigned NOT NULL,
  `scopes` text DEFAULT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_auth_codes_user_id_index` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Tabellen-Dump oauth_clients
# ------------------------------------------------------------

DROP TABLE IF EXISTS `oauth_clients`;

CREATE TABLE `oauth_clients` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `name` varchar(191) NOT NULL,
  `secret` varchar(100) DEFAULT NULL,
  `provider` varchar(191) DEFAULT NULL,
  `redirect` text NOT NULL,
  `personal_access_client` tinyint(1) NOT NULL,
  `password_client` tinyint(1) NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_clients_user_id_index` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `oauth_clients` WRITE;
/*!40000 ALTER TABLE `oauth_clients` DISABLE KEYS */;

INSERT INTO `oauth_clients` (`id`, `user_id`, `name`, `secret`, `provider`, `redirect`, `personal_access_client`, `password_client`, `revoked`, `created_at`, `updated_at`)
VALUES
	(1,NULL,'Lumen Personal Access Client','mq5TumYdz2qETYg63r96zqsWrhpxvyd0O62Ebqnl',NULL,'http://localhost',1,0,0,'2022-12-15 02:53:51','2022-12-15 02:53:51'),
	(2,NULL,'Lumen Password Grant Client','FqvANgiqQoOLBLoFnImKZwf8yPb6UK8wFoUvoXN2','admin','http://localhost',0,1,0,'2022-12-15 02:54:15','2022-12-15 02:54:15'),
	(3,NULL,'Lumen Personal Access Client','jf8ay4fjtrmatjakxSLTECOgIfwn1Iu5wfu3O7F7',NULL,'http://localhost',1,0,0,'2022-12-15 02:54:59','2022-12-15 02:54:59'),
	(4,NULL,'Lumen Personal Access Client','XtmIrS89vOTkLUAr7lwkbpyqjeIomkcPfpZ9hxTI',NULL,'http://localhost',1,0,0,'2022-12-15 02:59:28','2022-12-15 02:59:28'),
	(5,NULL,'Lumen Password Grant Client','NamfG9LZI9rqxMU9wRKHjecdfOx5i1yVMcwRcT2m','admin','http://localhost',0,1,0,'2022-12-15 02:59:31','2022-12-15 02:59:31'),
	(6,NULL,'Lumen Personal Access Client','WZIZi6J6tslEfvWdm1Dc1tjDp3m26pKJhu6IqVx5',NULL,'http://localhost',1,0,0,'2022-12-15 03:01:30','2022-12-15 03:01:30'),
	(7,NULL,'Lumen Password Grant Client','0ezJ3WJMSB6vof7znToN45UwQkqmDuBqJREGgimT','customer','http://localhost',0,1,0,'2022-12-15 03:01:32','2022-12-15 03:01:32');

/*!40000 ALTER TABLE `oauth_clients` ENABLE KEYS */;
UNLOCK TABLES;


# Tabellen-Dump oauth_personal_access_clients
# ------------------------------------------------------------

DROP TABLE IF EXISTS `oauth_personal_access_clients`;

CREATE TABLE `oauth_personal_access_clients` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `client_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `oauth_personal_access_clients` WRITE;
/*!40000 ALTER TABLE `oauth_personal_access_clients` DISABLE KEYS */;

INSERT INTO `oauth_personal_access_clients` (`id`, `client_id`, `created_at`, `updated_at`)
VALUES
	(1,1,'2022-12-15 02:53:51','2022-12-15 02:53:51'),
	(2,3,'2022-12-15 02:54:59','2022-12-15 02:54:59'),
	(3,4,'2022-12-15 02:59:28','2022-12-15 02:59:28'),
	(4,6,'2022-12-15 03:01:30','2022-12-15 03:01:30');

/*!40000 ALTER TABLE `oauth_personal_access_clients` ENABLE KEYS */;
UNLOCK TABLES;


# Tabellen-Dump oauth_refresh_tokens
# ------------------------------------------------------------

DROP TABLE IF EXISTS `oauth_refresh_tokens`;

CREATE TABLE `oauth_refresh_tokens` (
  `id` varchar(100) NOT NULL,
  `access_token_id` varchar(100) NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_refresh_tokens_access_token_id_index` (`access_token_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Tabellen-Dump pages
# ------------------------------------------------------------

DROP TABLE IF EXISTS `pages`;

CREATE TABLE `pages` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(50) NOT NULL DEFAULT '',
  `slug` varchar(50) DEFAULT NULL,
  `content` mediumtext NOT NULL,
  `is_public` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

LOCK TABLES `pages` WRITE;
/*!40000 ALTER TABLE `pages` DISABLE KEYS */;

INSERT INTO `pages` (`id`, `title`, `slug`, `content`, `is_public`)
VALUES
	(1,'Impressum','impressum','<p><span style=\"font-size: 18px;\"><strong>Yachtanlieger Netzelkow</strong></span></p><table style=\"width: 100%;\"><tbody><tr><td style=\"width: 19.0513%;\">Adresse<br></td><td style=\"width: 80.7932%;\">11888 Dorf, Dorfstra&szlig;e 5<br></td></tr><tr><td style=\"width: 19.0513%;\">Telefon<br></td><td style=\"width: 80.7932%;\">12345678<br></td></tr><tr><td style=\"width: 19.0513%;\">Email<br></td><td style=\"width: 80.7932%;\">hafen@meister.de<br></td></tr><tr><td style=\"width: 19.0513%;\">Gesch&auml;ftsf&uuml;hrer<br></td><td style=\"width: 80.7932%;\">Hannes Oberchef<br></td></tr><tr><td style=\"width: 19.0513%;\">Webauftritt<br></td><td style=\"width: 80.7932%;\">Bernd Engels<br></td></tr></tbody></table>',1),
	(2,'Datenschutzerklärung','datenschutz','<h3>Datenschutzerkl&auml;rung</h3><p>Diese Datenschutzerkl&auml;rung soll die Nutzer dieser Website &uuml;ber die Art, den Umfang und den Zweck der Erhebung und Verwendung personenbezogener Daten durch den Websitebetreiber &quot;Yachtanlieger Netzelkow&quot; informieren. Der Websitebetreiber nimmt Ihren Datenschutz sehr ernst und behandelt</p><p>Ihre personenbezogenen Daten vertraulich und entsprechend der gesetzlichen Vorschriften. Da durch neue Technologien und die st&auml;ndige Weiterentwicklung dieser Webseite &Auml;nderungen an dieser Datenschutzerkl&auml;rung vorgenommen werden k&ouml;nnen, empfehlen wir Ihnen sich die Datenschutzerkl&auml;rung in regelm&auml;&szlig;igen Abst&auml;nden wieder durchzulesen. Definitionen der verwendeten Begriffe</p><p>(z.B. &quot;personenbezogene Daten&quot; oder &quot;Verarbeitung&quot;) finden Sie in Art. 4 DSGVO.</p><h4><strong>Zugriffsdaten</strong></h4><p>Wir, der Websitebetreiber bzw. Seitenprovider, erheben aufgrund unseres berechtigten Interesses (s. Art. 6 Abs. 1 lit. f. DSGVO) Daten &uuml;ber Zugriffe auf die Website und speichern diese als &quot;Server-Logfiles&quot; auf dem Server der Website ab. Folgende Daten werden so protokolliert:</p><p>- Besuchte Website</p><p>- Uhrzeit zum Zeitpunkt des Zugriffes</p><p>- Menge der gesendeten Daten in Byte</p><p>- Quelle/Verweis, von welchem Sie auf die Seite gelangten</p><p>- Verwendeter Browser</p><p>- Verwendetes Betriebssystem</p><p>- Verwendete IP-Adresse</p><p>Die Server-Logfiles werden f&uuml;r maximal 7 Tage gespeichert und anschlie&szlig;end gel&ouml;scht. Die Speicherung der Daten erfolgt aus Sicherheitsgr&uuml;nden, um z. B. Missbrauchsf&auml;lle aufkl&auml;ren zu k&ouml;nnen. M&uuml;ssen Daten aus Beweisgr&uuml;nden aufgehoben werden, sind sie solange von der L&ouml;schung ausgenommen bis der Vorfall endg&uuml;ltig gekl&auml;rt ist.</p><h4>Cookies, Session-Daten</h4><p>Diese Website verwendet einzig und allein Sitzungs-Cookies, die nicht an Dritte &uuml;bertragen werden. Bei Cookies handelt es sich um kleine Dateien, welche auf Ihrem Endger&auml;t gespeichert werden. Ihr Browser greift auf diese Dateien zu. Durch den Einsatz von Cookies erh&ouml;ht sich die Benutzerfreundlichkeit und Sicherheit dieser Website. Falls Sie nicht m&ouml;chten, dass Cookies &nbsp;auf Ihrem Endger&auml;t gespeichert werden, k&ouml;nnen Sie dem Einsatz dieser Dateien hier widersprechen:</p><p>- Cookie-Deaktivierungsseite der Netzwerkwerbeinitiative: http://optout.networkadvertising.org/?c=1#!/</p><p>- Cookie-Deaktivierungsseite der US-amerikanischen Website: http://optout.aboutads.info/?c=2#!/</p><p>- Cookie-Deaktivierungsseite der europ&auml;ischen Website: http://optout.networkadvertising.org/?c=1#!/</p><p>G&auml;ngige Browser bieten die Einstellungsoption, Cookies nicht zuzulassen. Hinweis: Es ist nicht gew&auml;hrleistet, dass Sie auf alle Funktionen dieser Website ohne Einschr&auml;nkungen zugreifen k&ouml;nnen, wenn Sie entsprechende Einstellungen vornehmen.</p><h4>Erfassung und Verarbeitung personenbezogener Daten</h4><p>Der Websitebetreiber erhebt, nutzt und gibt Ihre personenbezogenen Daten nur dann weiter, wenn dies im gesetzlichen Rahmen erlaubt ist oder Sie in die Datenerhebung einwilligen. Als personenbezogene Daten gelten s&auml;mtliche Informationen, welche dazu dienen, Ihre Person zu bestimmen und welche zu Ihnen zur&uuml;ckverfolgt werden k&ouml;nnen &ndash; also beispielsweise Ihr Name, Ihre E-Mail-Adresse und Telefonnummer. Diese Website k&ouml;nnen Sie auch besuchen, ohne Angaben zu Ihrer Person zu machen. Zur Verbesserung unseres</p><p>Online-Angebotes speichern wir jedoch (ohne Personenbezug) Ihre Zugriffsdaten auf diese Website. Zu diesen Zugriffsdaten geh&ouml;ren z. B. die von Ihnen angeforderte Datei oder der Name Ihres Internet-Providers. Durch die Anonymisierung der Daten sind R&uuml;ckschl&uuml;sse auf Ihre Person nicht m&ouml;glich.</p><h4>Umgang mit Kontaktdaten</h4><p>Nehmen Sie mit uns als Websitebetreiber durch die angebotenen Kontaktm&ouml;glichkeiten Verbindung auf, werden Ihre Angaben gespeichert, damit auf diese zur Bearbeitung und Beantwortung Ihrer Anfrage zur&uuml;ckgegriffen werden kann. Ohne Ihre Einwilligung werden diese Daten nicht an Dritte weitergegeben.</p><p>Google Analytics, Facebook Social-Media-Plugins. Beides wird von uns derzeit nicht verwendet.</p><h4>Widerruf und K&uuml;ndigung</h4><p>Ihre Einwilligung zum Erhalt des Newsletter k&ouml;nnen Sie jederzeit widerrufen und somit das Newsletter-Abonnement k&uuml;ndigen. Nach Ihrer K&uuml;ndigung erfolgt die L&ouml;schung Ihre personenbezogenen Daten. Ihre Einwilligung in den Newsletterversand erlischt gleichzeitig. Am Ende jedes Newsletters finden Sie den Link zur K&uuml;ndigung.</p><h4>Rechte des Nutzers</h4><p>Sie haben als Nutzer das Recht, auf Antrag eine kostenlose Auskunft dar&uuml;ber zu erhalten, welche personenbezogenen Daten &uuml;ber Sie gespeichert wurden. Sie haben au&szlig;erdem das Recht auf Berichtigung falscher Daten und auf die Verarbeitungseinschr&auml;nkung oder L&ouml;schung Ihrer personenbezogenen Daten.</p><p>Falls zutreffend, k&ouml;nnen Sie auch Ihr Recht auf Datenportabilit&auml;t geltend machen. Sollten Sie annehmen, dass Ihre Daten unrechtm&auml;&szlig;ig verarbeitet wurden, k&ouml;nnen Sie eine Beschwerde bei der zust&auml;ndigen Aufsichtsbeh&ouml;rde einreichen.</p><h4>L&ouml;schung von Daten</h4><p>Sofern Ihr Wunsch nicht mit einer gesetzlichen Pflicht zur Aufbewahrung von Daten (z. B. Vorratsdatenspeicherung) kollidiert, haben Sie ein Anrecht auf L&ouml;schung Ihrer Daten. Von uns gespeicherte Daten werden, sollten sie f&uuml;r ihre Zweckbestimmung nicht mehr vonn&ouml;ten sein und es keine gesetzlichen Aufbewahrungsfristen geben, gel&ouml;scht. Falls eine L&ouml;schung nicht durchgef&uuml;hrt werden kann, da die Daten f&uuml;r zul&auml;ssige gesetzliche Zwecke erforderlich sind, erfolgt eine Einschr&auml;nkung der Datenverarbeitung. In diesem Fall werden die Daten gesperrt und nicht f&uuml;r andere Zwecke verarbeitet.</p><h4>Widerspruchsrecht</h4><p>Nutzer dieser Webseite k&ouml;nnen von ihrem Widerspruchsrecht Gebrauch machen und der Verarbeitung ihrer personenbezogenen Daten zu jeder Zeit widersprechen. Wenn Sie eine Berichtigung, Sperrung, L&ouml;schung oder Auskunft &uuml;ber die zu Ihrer Person gespeicherten personenbezogenen Daten w&uuml;nschen oder bzgl. der Erhebung, Verarbeitung oder Verwendung Ihrer personenbezogenen Daten haben oder erteilte Einwilligungen widerrufen m&ouml;chten, wenden Sie sich bitte an folgende E-Mail-Adresse: info@yachtanlieger.de</p>',1);

/*!40000 ALTER TABLE `pages` ENABLE KEYS */;
UNLOCK TABLES;


# Tabellen-Dump password_resets
# ------------------------------------------------------------

DROP TABLE IF EXISTS `password_resets`;

CREATE TABLE `password_resets` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Tabellen-Dump permissions
# ------------------------------------------------------------

DROP TABLE IF EXISTS `permissions`;

CREATE TABLE `permissions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `guard_name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;

INSERT INTO `permissions` (`id`, `name`, `guard_name`, `created_at`, `updated_at`)
VALUES
	(1,'write Caravan','admin','2021-09-29 22:22:59','2021-09-30 12:51:44'),
	(2,'read Caravan','admin','2021-09-29 22:26:25','2021-09-30 12:51:57'),
	(3,'read CaravanDates','admin','2021-09-30 12:55:49','2021-09-30 12:55:49'),
	(4,'write CaravanDates','admin','2021-09-30 12:56:05','2021-09-30 12:56:05'),
	(5,'read Page','admin','2021-09-30 12:57:05','2021-09-30 12:57:05'),
	(6,'write Page','admin','2021-09-30 12:57:12','2021-09-30 12:57:12'),
	(7,'read User','admin','2021-09-30 13:00:12','2021-09-30 13:00:12'),
	(8,'write User','admin','2021-09-30 13:00:23','2021-09-30 13:00:23'),
	(9,'read Role','admin','2021-09-30 13:00:32','2021-09-30 13:00:32'),
	(10,'write Role','admin','2021-09-30 13:00:42','2021-09-30 13:00:42'),
	(11,'read Permission','admin','2021-09-30 13:00:51','2021-09-30 13:00:51'),
	(12,'write Permission','admin','2021-09-30 13:00:59','2021-09-30 13:00:59'),
	(13,'read Country','admin','2021-09-30 13:01:12','2021-09-30 13:01:12'),
	(14,'write Country','admin','2021-09-30 13:01:22','2021-09-30 13:01:22'),
	(15,'read CaravansMenu','admin','2021-09-30 14:36:07','2021-09-30 14:36:07'),
	(16,'read PermissionsMenu','admin','2021-09-30 14:36:45','2021-09-30 14:36:45'),
	(17,'read InfoMenu','admin','2021-09-30 14:37:09','2021-09-30 14:37:09'),
	(18,'read ContentMenu','admin','2021-10-02 12:41:31','2021-10-02 12:49:13'),
	(19,'read Widget','admin','2021-10-02 12:42:38','2021-10-02 12:42:38'),
	(20,'write Widget','admin','2021-10-02 12:42:46','2021-10-02 12:42:46'),
	(21,'read CustomersMenu','admin','2021-10-03 17:28:20','2021-10-03 17:28:20'),
	(22,'read BoatsMenu','admin','2021-10-03 17:28:42','2021-10-03 17:28:42'),
	(23,'read Customer','admin','2021-10-03 17:28:59','2021-10-03 17:28:59'),
	(24,'write Customer','admin','2021-10-03 17:29:07','2021-10-03 17:29:07'),
	(25,'read Boat','admin','2021-10-03 17:29:13','2021-10-03 17:29:13'),
	(26,'write Boat','admin','2021-10-03 17:29:19','2021-10-03 17:29:19'),
	(27,'read BoatMenu','customer','2021-10-04 18:12:22','2021-10-04 18:13:21'),
	(28,'read Boat','customer','2021-10-04 18:26:46','2021-10-04 18:26:46'),
	(29,'read Customer','customer','2021-10-04 18:27:14','2021-10-04 18:27:14'),
	(30,'read CustomersMenu','customer','2021-10-04 18:27:46','2021-10-04 18:27:46'),
	(31,'read Routes','admin','2021-10-04 18:50:06','2021-10-04 18:50:06'),
	(32,'read BoatDates','admin','2021-10-10 22:17:04','2021-10-10 22:17:04'),
	(33,'write BoatDates','admin','2021-10-10 22:17:11','2021-10-10 22:17:11'),
	(34,'read BoatGuest','admin','2021-10-10 22:17:20','2021-10-10 22:17:20'),
	(35,'write BoatGuest','admin','2021-10-10 22:17:28','2021-10-10 22:17:28'),
	(36,'read BoatGuestDates','admin','2021-10-10 22:17:37','2021-10-10 22:17:37'),
	(37,'write BoatGuestDates','admin','2021-10-10 22:17:44','2021-10-10 22:17:44'),
	(38,'confirm Registration','admin','2021-10-20 12:11:54','2021-10-20 12:11:54'),
	(39,'read ProfileMenu','customer','2021-11-09 18:38:30','2021-11-09 18:38:30'),
	(40,'write Boat','customer','2021-11-09 18:39:39','2021-11-09 18:39:39'),
	(41,'read BoatDates','customer','2021-11-09 18:40:41','2021-11-09 18:40:41'),
	(42,'read ServiceMenu','admin','2021-11-10 14:21:29','2021-11-10 15:03:47'),
	(43,'read ServiceMenu','customer','2021-11-10 14:21:49','2021-11-10 15:04:28'),
	(44,'read Service','admin','2021-11-10 14:22:09','2021-11-10 14:22:09'),
	(45,'write Service','admin','2021-11-10 14:22:18','2021-11-10 14:22:18'),
	(46,'read ServiceCategory','admin','2021-11-10 14:22:28','2021-11-10 14:22:28'),
	(47,'write ServiceCategory','admin','2021-11-10 14:22:37','2021-11-10 14:22:37'),
	(48,'read Material','admin','2021-11-10 14:22:45','2021-11-10 14:22:45'),
	(49,'write Material','admin','2021-11-10 14:22:54','2021-11-10 14:22:54'),
	(50,'read MaterialCategory','admin','2021-11-10 14:23:03','2021-11-10 14:23:03'),
	(51,'write MaterialCategory','admin','2021-11-10 14:23:13','2021-11-10 14:23:13'),
	(52,'read Service','customer','2021-11-10 14:23:38','2021-11-10 14:23:38'),
	(53,'read ServiceRequest','admin','2021-11-10 14:32:06','2021-11-10 14:32:06'),
	(54,'write ServiceRequest','admin','2021-11-10 14:32:18','2021-11-10 14:32:18'),
	(55,'read ServiceRequest','customer','2021-11-10 14:32:37','2021-11-10 14:32:37'),
	(56,'write ServiceRequest','customer','2021-11-10 14:32:51','2021-11-10 14:32:51'),
	(59,'read ConfigSaisonDates','admin','2021-11-27 23:40:03','2021-11-30 01:08:05'),
	(60,'write ConfigSaisonDates','admin','2021-11-27 23:40:24','2021-11-30 01:08:31'),
	(61,'read SettingsMenu','admin','2021-11-27 23:41:51','2021-11-27 23:41:51'),
	(62,'read ConfigBoatPrice','admin','2021-11-30 21:04:53','2021-11-30 21:04:53'),
	(63,'write ConfigBoatPrice','admin','2021-11-30 21:05:07','2021-11-30 21:05:07'),
	(64,'read ConfigDailyPrice','admin','2021-11-30 21:05:37','2021-11-30 21:05:37'),
	(65,'write ConfigDailyPrice','admin','2021-11-30 21:05:48','2021-11-30 21:05:48'),
	(66,'read ConfigEntity','admin','2021-11-30 21:06:02','2021-11-30 21:06:02'),
	(67,'write ConfigEntity','admin','2021-11-30 21:06:13','2021-11-30 21:06:13'),
	(68,'read ConfigPriceComponent','admin','2021-11-30 21:06:29','2021-11-30 21:06:29'),
	(69,'write ConfigPriceComponent','admin','2021-11-30 21:06:50','2021-11-30 21:06:50'),
	(70,'read ConfigPriceType','admin','2021-11-30 21:07:28','2021-11-30 21:07:28'),
	(71,'write ConfigPriceType','admin','2021-11-30 21:07:39','2021-11-30 21:07:39'),
	(72,'read ConfigService','admin','2021-11-30 21:07:53','2021-11-30 21:07:53'),
	(73,'write ConfigService','admin','2021-11-30 21:08:04','2021-11-30 21:08:04'),
	(74,'read Offer','admin','2022-03-13 11:02:57','2022-03-13 11:02:57'),
	(75,'write Offer','admin','2022-03-13 11:03:23','2022-03-13 11:03:23'),
	(76,'read Houseboat','admin','2022-03-13 16:25:45','2022-03-13 16:25:45'),
	(77,'write Houseboat','admin','2022-03-13 16:25:59','2022-03-13 16:25:59'),
	(78,'read HouseboatDates','admin','2022-03-13 16:27:07','2022-03-13 16:27:07'),
	(79,'write HouseboatDates','admin','2022-03-13 16:27:22','2022-03-13 16:27:22'),
	(80,'read HouseboatModel','admin','2022-03-13 16:27:38','2022-03-13 16:27:38'),
	(81,'write HouseboatModel','admin','2022-03-13 16:27:56','2022-03-13 16:27:56'),
	(82,'read HouseboatsMenu','admin','2022-03-13 16:34:04','2022-03-13 17:50:35'),
	(83,'read ConfigSaisonRent','admin','2022-04-03 13:21:21','2022-04-03 13:21:21'),
	(84,'write ConfigSaisonRent','admin','2022-04-03 13:21:39','2022-04-03 13:21:39'),
	(85,'read ConfigSaisonRentDates','admin','2022-04-03 13:21:49','2022-04-03 13:21:49'),
	(86,'write ConfigSaisonRentDates','admin','2022-04-03 13:22:00','2022-04-03 13:22:00'),
	(89,'read Berth','admin','2022-06-25 13:56:35','2022-06-25 13:56:35'),
	(90,'write Berth','admin','2022-06-25 13:56:47','2022-06-25 13:56:47'),
	(91,'read HouseboatOwner','admin','2022-06-25 13:56:58','2022-06-25 13:56:58'),
	(92,'write HouseboatOwner','admin','2022-06-25 13:57:14','2022-06-25 13:57:14'),
	(93,'read Dock','admin','2022-07-01 11:52:04','2023-01-03 20:11:49'),
	(95,'write Dock','admin','2022-07-01 12:15:29','2023-01-03 20:12:06'),
	(96,'read ConfigSettings','admin','2022-07-12 18:43:51','2022-07-12 18:43:51'),
	(97,'write ConfigSettings','admin','2022-07-12 18:43:59','2022-07-12 18:43:59'),
	(98,'read ConfigHoliday','admin','2022-11-26 01:53:38','2022-11-26 01:53:38'),
	(99,'write ConfigHoliday','admin','2022-11-26 01:54:35','2022-11-26 01:54:35'),
	(100,'read Rentable','admin','2022-12-29 17:54:35','2022-12-29 17:54:35'),
	(101,'write Rentable','admin','2022-12-29 17:54:47','2022-12-29 17:54:47'),
	(102,'read Apartment','admin','2022-12-29 17:55:29','2022-12-29 17:55:29'),
	(103,'write Apartment','admin','2022-12-29 17:55:37','2022-12-29 17:55:37'),
	(104,'read ApartmentModel','admin','2022-12-29 17:55:43','2022-12-29 17:55:43'),
	(105,'write ApartmentModel','admin','2022-12-29 17:55:51','2022-12-29 17:55:51'),
	(106,'read House','admin','2022-12-29 17:56:03','2022-12-29 17:56:03'),
	(107,'write House','admin','2022-12-29 17:56:14','2022-12-29 17:56:14'),
	(108,'read HouseModel','admin','2022-12-29 17:56:25','2022-12-29 17:56:25'),
	(109,'write HouseModel','admin','2022-12-29 17:56:56','2022-12-29 17:56:56'),
	(110,'read RentalsMenu','admin','2022-12-30 17:40:09','2022-12-30 17:43:56'),
	(111,'write Customer','customer','2023-01-07 01:24:27','2023-01-07 01:24:27'),
	(112,'read Rentable','customer','2023-01-07 01:41:40','2023-01-07 01:41:40'),
	(113,'write Rentable','customer','2023-01-07 01:41:56','2023-01-07 01:41:56'),
	(114,'read AccessLog','admin','2023-02-01 18:42:17','2023-02-01 18:42:17'),
	(115,'read CraneDate','admin','2023-05-30 15:51:10','2023-05-30 15:51:10'),
	(116,'write CraneDate','admin','2023-05-30 15:51:45','2023-05-30 18:50:41'),
	(117,'read CraneDate','customer','2023-05-30 15:52:09','2023-05-30 15:52:09'),
	(118,'write CraneDate','customer','2023-05-30 15:52:26','2023-05-30 15:52:26'),
	(119,'ImageUpload','admin','2023-06-25 11:51:57','2023-06-25 11:51:57');

/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;


# Tabellen-Dump personal_access_tokens
# ------------------------------------------------------------

DROP TABLE IF EXISTS `personal_access_tokens`;

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Tabellen-Dump rentable_models
# ------------------------------------------------------------

DROP TABLE IF EXISTS `rentable_models`;

CREATE TABLE `rentable_models` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `rentable_id` int(11) unsigned DEFAULT NULL,
  `rentable_type` varchar(100) DEFAULT NULL,
  `name` varchar(50) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `space` int(10) unsigned NOT NULL,
  `floors` tinyint(1) unsigned NOT NULL,
  `sleeping_places` tinyint(2) unsigned NOT NULL,
  `peak_season_price` int(10) unsigned DEFAULT NULL,
  `mid_season_price` int(10) unsigned DEFAULT NULL,
  `low_season_price` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `rentable_id` (`rentable_id`,`rentable_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

LOCK TABLES `rentable_models` WRITE;
/*!40000 ALTER TABLE `rentable_models` DISABLE KEYS */;

INSERT INTO `rentable_models` (`id`, `rentable_id`, `rentable_type`, `name`, `description`, `space`, `floors`, `sleeping_places`, `peak_season_price`, `mid_season_price`, `low_season_price`)
VALUES
	(1,NULL,'houseboat','Grande','Das ist unser größtes Hausboot.',120,2,8,220,180,140),
	(2,NULL,'houseboat','Medium','Das ist unser mittelgroßes Hausboot.',80,2,6,180,160,130),
	(3,NULL,'houseboat','Petite','Das ist unser kleinstes Hausboot.',60,1,4,150,130,110),
	(4,NULL,'house','Haus Grande','Das ist unser größtes Haus.',240,2,8,220,180,140),
	(5,NULL,'house','Haus Medium','Das ist unser mittelgroßes Haus.',140,2,6,180,160,130),
	(6,NULL,'house','Haus Petite','Das ist unser kleinstes Haus.',100,1,4,150,130,110),
	(7,NULL,'apartment','Apartment Grande','Das ist unsere größte Wohnung.',120,2,8,220,180,140),
	(8,NULL,'apartment','Apartment  MEDIUM','Das ist unsere mittelgroße Wohnung.',80,2,6,180,160,130),
	(9,NULL,'apartment','Apartment  Petite','Das ist unsere kleinste Wohnung.',60,1,4,150,130,110);

/*!40000 ALTER TABLE `rentable_models` ENABLE KEYS */;
UNLOCK TABLES;


# Tabellen-Dump rentable_models_copy
# ------------------------------------------------------------

DROP TABLE IF EXISTS `rentable_models_copy`;

CREATE TABLE `rentable_models_copy` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `rentable_id` int(11) unsigned DEFAULT NULL,
  `rentable_type` varchar(100) DEFAULT NULL,
  `name` varchar(50) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `space` int(10) unsigned NOT NULL,
  `floors` tinyint(1) unsigned NOT NULL,
  `sleeping_places` tinyint(2) unsigned NOT NULL,
  `peak_season_price` int(10) unsigned DEFAULT NULL,
  `mid_season_price` int(10) unsigned DEFAULT NULL,
  `low_season_price` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `rentable_id` (`rentable_id`,`rentable_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

LOCK TABLES `rentable_models_copy` WRITE;
/*!40000 ALTER TABLE `rentable_models_copy` DISABLE KEYS */;

INSERT INTO `rentable_models_copy` (`id`, `rentable_id`, `rentable_type`, `name`, `description`, `space`, `floors`, `sleeping_places`, `peak_season_price`, `mid_season_price`, `low_season_price`)
VALUES
	(1,NULL,'App\\Models\\Houseboat','Grande','Das ist unser größtes Hausboot.',120,2,8,220,180,140),
	(2,NULL,'App\\Models\\Houseboat','Medium','Das ist unser mittelgroßes Hausboot.',80,2,6,180,160,130),
	(3,NULL,'App\\Models\\Houseboat','Petite','Das ist unser kleinstes Hausboot.',60,1,4,150,130,110),
	(4,NULL,'App\\Models\\House','Haus Grande','Das ist unser größtes Haus.',240,2,8,220,180,140),
	(5,NULL,'App\\Models\\House','Haus Medium','Das ist unser mittelgroßes Haus.',140,2,6,180,160,130),
	(6,NULL,'App\\Models\\House','Haus Petite','Das ist unser kleinstes Haus.',100,1,4,150,130,110),
	(7,NULL,'App\\Models\\Apartment','Apartment Grande','Das ist unsere größte Wohnung.',120,2,8,220,180,140),
	(8,NULL,'App\\Models\\Apartment','Apartment  MEDIUM','Das ist unsere mittelgroße Wohnung.',80,2,6,180,160,130),
	(9,NULL,'App\\Models\\Apartment','Apartment  Petite','Das ist unsere kleinste Wohnung.',60,1,4,150,130,110);

/*!40000 ALTER TABLE `rentable_models_copy` ENABLE KEYS */;
UNLOCK TABLES;


# Tabellen-Dump rentables
# ------------------------------------------------------------

DROP TABLE IF EXISTS `rentables`;

CREATE TABLE `rentables` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `rentable_id` int(11) unsigned NOT NULL,
  `rentable_type` varchar(100) DEFAULT '',
  `customer_id` int(11) unsigned NOT NULL,
  `from` date NOT NULL,
  `until` date NOT NULL,
  `price` int(11) unsigned DEFAULT NULL,
  `prices` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `is_paid` tinyint(1) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `from` (`from`,`until`),
  KEY `customer_id` (`customer_id`),
  KEY `is_paid` (`is_paid`),
  KEY `price` (`price`),
  KEY `rentable_id` (`rentable_id`),
  KEY `rentable_type` (`rentable_type`),
  CONSTRAINT `rentables_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

LOCK TABLES `rentables` WRITE;
/*!40000 ALTER TABLE `rentables` DISABLE KEYS */;

INSERT INTO `rentables` (`id`, `rentable_id`, `rentable_type`, `customer_id`, `from`, `until`, `price`, `prices`, `is_paid`)
VALUES
	(2,1,'houseboat',10,'2022-04-12','2022-04-18',1200,X'7B22707269636542617365223A313038302C226461696C79507269636573223A7B22323032322D30342D3132223A7B2264617465223A2244692E2031322E30342E32303232222C22736169736F6E223A225A7769736368656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3138307D2C22323032322D30342D3133223A7B2264617465223A224D692E2031332E30342E32303232222C22736169736F6E223A225A7769736368656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3138307D2C22323032322D30342D3134223A7B2264617465223A22446F2E2031342E30342E32303232222C22736169736F6E223A225A7769736368656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3138307D2C22323032322D30342D3135223A7B2264617465223A2246722E2031352E30342E32303232222C22736169736F6E223A225A7769736368656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3138307D2C22323032322D30342D3136223A7B2264617465223A2253612E2031362E30342E32303232222C22736169736F6E223A225A7769736368656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3138307D2C22323032322D30342D3137223A7B2264617465223A22536F2E2031372E30342E32303232222C22736169736F6E223A225A7769736368656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3138307D7D2C2264617973223A362C22746178223A31392C226E6574746F223A3930372E35362C227461785072696365223A3137322E34342C22746F74616C223A313038307D',1),
	(4,3,'houseboat',7,'2022-04-12','2022-04-14',260,X'7B22707269636542617365223A3236302C226461696C79507269636573223A7B22323032322D30342D3132223A7B2264617465223A2244692E2031322E30342E32303232222C22736169736F6E223A225A7769736368656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3133307D2C22323032322D30342D3133223A7B2264617465223A224D692E2031332E30342E32303232222C22736169736F6E223A225A7769736368656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3133307D7D2C2264617973223A322C22746178223A31392C226E6574746F223A3231382E34392C227461785072696365223A34312E35312C22746F74616C223A3236307D',1),
	(5,2,'houseboat',7,'2022-05-16','2022-06-05',3280,X'7B22707269636542617365223A333238302C226461696C79507269636573223A7B22323032322D30352D3136223A7B2264617465223A224D6F2E2031362E30352E32303232222C22736169736F6E223A225A7769736368656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3136307D2C22323032322D30352D3137223A7B2264617465223A2244692E2031372E30352E32303232222C22736169736F6E223A225A7769736368656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3136307D2C22323032322D30352D3138223A7B2264617465223A224D692E2031382E30352E32303232222C22736169736F6E223A225A7769736368656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3136307D2C22323032322D30352D3139223A7B2264617465223A22446F2E2031392E30352E32303232222C22736169736F6E223A225A7769736368656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3136307D2C22323032322D30352D3230223A7B2264617465223A2246722E2032302E30352E32303232222C22736169736F6E223A225A7769736368656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3136307D2C22323032322D30352D3231223A7B2264617465223A2253612E2032312E30352E32303232222C22736169736F6E223A225A7769736368656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3136307D2C22323032322D30352D3232223A7B2264617465223A22536F2E2032322E30352E32303232222C22736169736F6E223A225A7769736368656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3136307D2C22323032322D30352D3233223A7B2264617465223A224D6F2E2032332E30352E32303232222C22736169736F6E223A225A7769736368656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3136307D2C22323032322D30352D3234223A7B2264617465223A2244692E2032342E30352E32303232222C22736169736F6E223A225A7769736368656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3136307D2C22323032322D30352D3235223A7B2264617465223A224D692E2032352E30352E32303232222C22736169736F6E223A225A7769736368656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3136307D2C22323032322D30352D3236223A7B2264617465223A22446F2E2032362E30352E32303232222C22736169736F6E223A225A7769736368656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3136307D2C22323032322D30352D3237223A7B2264617465223A2246722E2032372E30352E32303232222C22736169736F6E223A225A7769736368656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3136307D2C22323032322D30352D3238223A7B2264617465223A2253612E2032382E30352E32303232222C22736169736F6E223A225A7769736368656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3136307D2C22323032322D30352D3239223A7B2264617465223A22536F2E2032392E30352E32303232222C22736169736F6E223A225A7769736368656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3136307D2C22323032322D30352D3330223A7B2264617465223A224D6F2E2033302E30352E32303232222C22736169736F6E223A225A7769736368656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3136307D2C22323032322D30352D3331223A7B2264617465223A2244692E2033312E30352E32303232222C22736169736F6E223A225A7769736368656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3136307D2C22323032322D30362D3031223A7B2264617465223A224D692E2030312E30362E32303232222C22736169736F6E223A224861757074736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3138307D2C22323032322D30362D3032223A7B2264617465223A22446F2E2030322E30362E32303232222C22736169736F6E223A224861757074736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3138307D2C22323032322D30362D3033223A7B2264617465223A2246722E2030332E30362E32303232222C22736169736F6E223A224861757074736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3138307D2C22323032322D30362D3034223A7B2264617465223A2253612E2030342E30362E32303232222C22736169736F6E223A224861757074736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3138307D7D2C2264617973223A32302C22746178223A31392C226E6574746F223A323735362E332C227461785072696365223A3532332E372C22746F74616C223A333238307D',1),
	(6,2,'houseboat',7,'2022-04-25','2022-05-01',960,X'7B22707269636542617365223A3936302C226461696C79507269636573223A7B22323032322D30342D3235223A7B2264617465223A224D6F2E2032352E30342E32303232222C22736169736F6E223A225A7769736368656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3136307D2C22323032322D30342D3236223A7B2264617465223A2244692E2032362E30342E32303232222C22736169736F6E223A225A7769736368656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3136307D2C22323032322D30342D3237223A7B2264617465223A224D692E2032372E30342E32303232222C22736169736F6E223A225A7769736368656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3136307D2C22323032322D30342D3238223A7B2264617465223A22446F2E2032382E30342E32303232222C22736169736F6E223A225A7769736368656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3136307D2C22323032322D30342D3239223A7B2264617465223A2246722E2032392E30342E32303232222C22736169736F6E223A225A7769736368656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3136307D2C22323032322D30342D3330223A7B2264617465223A2253612E2033302E30342E32303232222C22736169736F6E223A225A7769736368656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3136307D7D2C2264617973223A362C22746178223A31392C226E6574746F223A3830362E37322C227461785072696365223A3135332E32382C22746F74616C223A3936307D',1),
	(7,2,'houseboat',7,'2022-06-05','2022-06-12',1260,X'7B22707269636542617365223A313236302C226461696C79507269636573223A7B22323032322D30362D3035223A7B2264617465223A22536F2E2030352E30362E32303232222C22736169736F6E223A224861757074736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3138307D2C22323032322D30362D3036223A7B2264617465223A224D6F2E2030362E30362E32303232222C22736169736F6E223A224861757074736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3138307D2C22323032322D30362D3037223A7B2264617465223A2244692E2030372E30362E32303232222C22736169736F6E223A224861757074736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3138307D2C22323032322D30362D3038223A7B2264617465223A224D692E2030382E30362E32303232222C22736169736F6E223A224861757074736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3138307D2C22323032322D30362D3039223A7B2264617465223A22446F2E2030392E30362E32303232222C22736169736F6E223A224861757074736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3138307D2C22323032322D30362D3130223A7B2264617465223A2246722E2031302E30362E32303232222C22736169736F6E223A224861757074736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3138307D2C22323032322D30362D3131223A7B2264617465223A2253612E2031312E30362E32303232222C22736169736F6E223A224861757074736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3138307D7D2C2264617973223A372C22746178223A31392C226E6574746F223A313035382E38322C227461785072696365223A3230312E31382C22746F74616C223A313236307D',1),
	(8,1,'houseboat',7,'2022-06-06','2022-06-12',1320,X'7B22707269636542617365223A313332302C226461696C79507269636573223A7B22323032322D30362D3036223A7B2264617465223A224D6F2E2030362E30362E32303232222C22736169736F6E223A224861757074736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3232307D2C22323032322D30362D3037223A7B2264617465223A2244692E2030372E30362E32303232222C22736169736F6E223A224861757074736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3232307D2C22323032322D30362D3038223A7B2264617465223A224D692E2030382E30362E32303232222C22736169736F6E223A224861757074736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3232307D2C22323032322D30362D3039223A7B2264617465223A22446F2E2030392E30362E32303232222C22736169736F6E223A224861757074736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3232307D2C22323032322D30362D3130223A7B2264617465223A2246722E2031302E30362E32303232222C22736169736F6E223A224861757074736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3232307D2C22323032322D30362D3131223A7B2264617465223A2253612E2031312E30362E32303232222C22736169736F6E223A224861757074736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3232307D7D2C2264617973223A362C22746178223A31392C226E6574746F223A313130392E32342C227461785072696365223A3231302E37362C22746F74616C223A313332307D',1),
	(9,1,'houseboat',9,'2022-12-18','2023-01-01',1960,X'7B22707269636542617365223A323630302C226461696C79507269636573223A7B22323032322D31322D3138223A7B2264617465223A22536F2E2031382E31322E32303232222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3134307D2C22323032322D31322D3139223A7B2264617465223A224D6F2E2031392E31322E32303232222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3134307D2C22323032322D31322D3230223A7B2264617465223A2244692E2032302E31322E32303232222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3134307D2C22323032322D31322D3231223A7B2264617465223A224D692E2032312E31322E32303232222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3134307D2C22323032322D31322D3232223A7B2264617465223A22446F2E2032322E31322E32303232222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3134307D2C22323032322D31322D3233223A7B2264617465223A2246722E2032332E31322E32303232222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3134307D2C22323032322D31322D3234223A7B2264617465223A2253612E2032342E31322E32303232222C22736169736F6E223A224861757074736169736F6E222C22686F6C69646179223A22576569686E61636874656E53696C76657374657232303232222C227072696365223A3232307D2C22323032322D31322D3235223A7B2264617465223A22536F2E2032352E31322E32303232222C22736169736F6E223A224861757074736169736F6E222C22686F6C69646179223A22576569686E61636874656E53696C76657374657232303232222C227072696365223A3232307D2C22323032322D31322D3236223A7B2264617465223A224D6F2E2032362E31322E32303232222C22736169736F6E223A224861757074736169736F6E222C22686F6C69646179223A22576569686E61636874656E53696C76657374657232303232222C227072696365223A3232307D2C22323032322D31322D3237223A7B2264617465223A2244692E2032372E31322E32303232222C22736169736F6E223A224861757074736169736F6E222C22686F6C69646179223A22576569686E61636874656E53696C76657374657232303232222C227072696365223A3232307D2C22323032322D31322D3238223A7B2264617465223A224D692E2032382E31322E32303232222C22736169736F6E223A224861757074736169736F6E222C22686F6C69646179223A22576569686E61636874656E53696C76657374657232303232222C227072696365223A3232307D2C22323032322D31322D3239223A7B2264617465223A22446F2E2032392E31322E32303232222C22736169736F6E223A224861757074736169736F6E222C22686F6C69646179223A22576569686E61636874656E53696C76657374657232303232222C227072696365223A3232307D2C22323032322D31322D3330223A7B2264617465223A2246722E2033302E31322E32303232222C22736169736F6E223A224861757074736169736F6E222C22686F6C69646179223A22576569686E61636874656E53696C76657374657232303232222C227072696365223A3232307D2C22323032322D31322D3331223A7B2264617465223A2253612E2033312E31322E32303232222C22736169736F6E223A224861757074736169736F6E222C22686F6C69646179223A22576569686E61636874656E53696C76657374657232303232222C227072696365223A3232307D7D2C2264617973223A31342C22746178223A31392C226E6574746F223A323138342E38372C227461785072696365223A3431352E31332C22746F74616C223A323630307D',1),
	(10,3,'houseboat',7,'2022-12-23','2022-12-26',330,X'7B22707269636542617365223A3431302C226461696C79507269636573223A7B22323032322D31322D3233223A7B2264617465223A2246722E2032332E31322E32303232222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3131307D2C22323032322D31322D3234223A7B2264617465223A2253612E2032342E31322E32303232222C22736169736F6E223A224861757074736169736F6E222C22686F6C69646179223A22576569686E61636874656E53696C76657374657232303232222C227072696365223A3135307D2C22323032322D31322D3235223A7B2264617465223A22536F2E2032352E31322E32303232222C22736169736F6E223A224861757074736169736F6E222C22686F6C69646179223A22576569686E61636874656E53696C76657374657232303232222C227072696365223A3135307D7D2C2264617973223A332C22746178223A31392C226E6574746F223A3334342E35342C227461785072696365223A36352E34362C22746F74616C223A3431307D',1),
	(11,2,'houseboat',9,'2022-12-30','2023-01-08',1170,X'7B22707269636542617365223A313332302C226461696C79507269636573223A7B22323032322D31322D3330223A7B2264617465223A2246722E2033302E31322E32303232222C22736169736F6E223A224861757074736169736F6E222C22686F6C69646179223A22576569686E61636874656E53696C76657374657232303232222C227072696365223A3138307D2C22323032322D31322D3331223A7B2264617465223A2253612E2033312E31322E32303232222C22736169736F6E223A224861757074736169736F6E222C22686F6C69646179223A22576569686E61636874656E53696C76657374657232303232222C227072696365223A3138307D2C22323032332D30312D3031223A7B2264617465223A22536F2E2030312E30312E32303233222C22736169736F6E223A224861757074736169736F6E222C22686F6C69646179223A22576569686E61636874656E53696C76657374657232303232222C227072696365223A3138307D2C22323032332D30312D3032223A7B2264617465223A224D6F2E2030322E30312E32303233222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3133307D2C22323032332D30312D3033223A7B2264617465223A2244692E2030332E30312E32303233222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3133307D2C22323032332D30312D3034223A7B2264617465223A224D692E2030342E30312E32303233222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3133307D2C22323032332D30312D3035223A7B2264617465223A22446F2E2030352E30312E32303233222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3133307D2C22323032332D30312D3036223A7B2264617465223A2246722E2030362E30312E32303233222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3133307D2C22323032332D30312D3037223A7B2264617465223A2253612E2030372E30312E32303233222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3133307D7D2C2264617973223A392C22746178223A31392C226E6574746F223A313130392E32342C227461785072696365223A3231302E37362C22746F74616C223A313332307D',1),
	(12,3,'houseboat',7,'2022-12-30','2023-01-08',990,X'7B22707269636542617365223A313131302C226461696C79507269636573223A7B22323032322D31322D3330223A7B2264617465223A2246722E2033302E31322E32303232222C22736169736F6E223A224861757074736169736F6E222C22686F6C69646179223A22576569686E61636874656E53696C76657374657232303232222C227072696365223A3135307D2C22323032322D31322D3331223A7B2264617465223A2253612E2033312E31322E32303232222C22736169736F6E223A224861757074736169736F6E222C22686F6C69646179223A22576569686E61636874656E53696C76657374657232303232222C227072696365223A3135307D2C22323032332D30312D3031223A7B2264617465223A22536F2E2030312E30312E32303233222C22736169736F6E223A224861757074736169736F6E222C22686F6C69646179223A22576569686E61636874656E53696C76657374657232303232222C227072696365223A3135307D2C22323032332D30312D3032223A7B2264617465223A224D6F2E2030322E30312E32303233222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3131307D2C22323032332D30312D3033223A7B2264617465223A2244692E2030332E30312E32303233222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3131307D2C22323032332D30312D3034223A7B2264617465223A224D692E2030342E30312E32303233222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3131307D2C22323032332D30312D3035223A7B2264617465223A22446F2E2030352E30312E32303233222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3131307D2C22323032332D30312D3036223A7B2264617465223A2246722E2030362E30312E32303233222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3131307D2C22323032332D30312D3037223A7B2264617465223A2253612E2030372E30312E32303233222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3131307D7D2C2264617973223A392C22746178223A31392C226E6574746F223A3933322E37372C227461785072696365223A3137372E32332C22746F74616C223A313131307D',1),
	(13,1,'houseboat',9,'2023-01-27','2023-02-05',1260,X'7B22707269636542617365223A313236302C226461696C79507269636573223A7B22323032332D30312D3237223A7B2264617465223A2246722E2032372E30312E32303233222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3134307D2C22323032332D30312D3238223A7B2264617465223A2253612E2032382E30312E32303233222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3134307D2C22323032332D30312D3239223A7B2264617465223A22536F2E2032392E30312E32303233222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3134307D2C22323032332D30312D3330223A7B2264617465223A224D6F2E2033302E30312E32303233222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3134307D2C22323032332D30312D3331223A7B2264617465223A2244692E2033312E30312E32303233222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3134307D2C22323032332D30322D3031223A7B2264617465223A224D692E2030312E30322E32303233222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3134307D2C22323032332D30322D3032223A7B2264617465223A22446F2E2030322E30322E32303233222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3134307D2C22323032332D30322D3033223A7B2264617465223A2246722E2030332E30322E32303233222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3134307D2C22323032332D30322D3034223A7B2264617465223A2253612E2030342E30322E32303233222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3134307D7D2C2264617973223A392C22746178223A31392C226E6574746F223A313035382E38322C227461785072696365223A3230312E31382C22746F74616C223A313236307D',1),
	(14,2,'houseboat',9,'2022-12-19','2022-12-22',390,X'7B22707269636542617365223A3339302C226461696C79507269636573223A7B22323032322D31322D3139223A7B2264617465223A224D6F2E2031392E31322E32303232222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3133307D2C22323032322D31322D3230223A7B2264617465223A2244692E2032302E31322E32303232222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3133307D2C22323032322D31322D3231223A7B2264617465223A224D692E2032312E31322E32303232222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3133307D7D2C2264617973223A332C22746178223A31392C226E6574746F223A3332372E37332C227461785072696365223A36322E32372C22746F74616C223A3339307D',1),
	(15,1,'houseboat',9,'2023-02-20','2023-02-26',840,X'7B22707269636542617365223A3834302C226461696C79507269636573223A7B22323032332D30322D3230223A7B2264617465223A224D6F2E2032302E30322E32303233222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3134307D2C22323032332D30322D3231223A7B2264617465223A2244692E2032312E30322E32303233222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3134307D2C22323032332D30322D3232223A7B2264617465223A224D692E2032322E30322E32303233222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3134307D2C22323032332D30322D3233223A7B2264617465223A22446F2E2032332E30322E32303233222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3134307D2C22323032332D30322D3234223A7B2264617465223A2246722E2032342E30322E32303233222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3134307D2C22323032332D30322D3235223A7B2264617465223A2253612E2032352E30322E32303233222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3134307D7D2C2264617973223A362C22746178223A31392C226E6574746F223A3730352E38382C227461785072696365223A3133342E31322C22746F74616C223A3834307D',1),
	(16,3,'houseboat',7,'2023-01-15','2023-02-01',1870,X'7B22707269636542617365223A313837302C226461696C79507269636573223A7B22323032332D30312D3135223A7B2264617465223A22536F2E2031352E30312E32303233222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3131307D2C22323032332D30312D3136223A7B2264617465223A224D6F2E2031362E30312E32303233222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3131307D2C22323032332D30312D3137223A7B2264617465223A2244692E2031372E30312E32303233222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3131307D2C22323032332D30312D3138223A7B2264617465223A224D692E2031382E30312E32303233222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3131307D2C22323032332D30312D3139223A7B2264617465223A22446F2E2031392E30312E32303233222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3131307D2C22323032332D30312D3230223A7B2264617465223A2246722E2032302E30312E32303233222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3131307D2C22323032332D30312D3231223A7B2264617465223A2253612E2032312E30312E32303233222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3131307D2C22323032332D30312D3232223A7B2264617465223A22536F2E2032322E30312E32303233222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3131307D2C22323032332D30312D3233223A7B2264617465223A224D6F2E2032332E30312E32303233222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3131307D2C22323032332D30312D3234223A7B2264617465223A2244692E2032342E30312E32303233222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3131307D2C22323032332D30312D3235223A7B2264617465223A224D692E2032352E30312E32303233222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3131307D2C22323032332D30312D3236223A7B2264617465223A22446F2E2032362E30312E32303233222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3131307D2C22323032332D30312D3237223A7B2264617465223A2246722E2032372E30312E32303233222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3131307D2C22323032332D30312D3238223A7B2264617465223A2253612E2032382E30312E32303233222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3131307D2C22323032332D30312D3239223A7B2264617465223A22536F2E2032392E30312E32303233222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3131307D2C22323032332D30312D3330223A7B2264617465223A224D6F2E2033302E30312E32303233222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3131307D2C22323032332D30312D3331223A7B2264617465223A2244692E2033312E30312E32303233222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3131307D7D2C2264617973223A31372C22746178223A31392C226E6574746F223A313537312E34332C227461785072696365223A3239382E35372C22746F74616C223A313837307D',0),
	(17,2,'houseboat',9,'2023-03-27','2023-04-02',650,X'7B22707269636542617365223A3635302C226461696C79507269636573223A7B22323032332D30332D3237223A7B2264617465223A224D6F2E2032372E30332E32303233222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3133307D2C22323032332D30332D3238223A7B2264617465223A2244692E2032382E30332E32303233222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3133307D2C22323032332D30332D3239223A7B2264617465223A224D692E2032392E30332E32303233222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3133307D2C22323032332D30332D3330223A7B2264617465223A22446F2E2033302E30332E32303233222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3133307D2C22323032332D30332D3331223A7B2264617465223A2246722E2033312E30332E32303233222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3133307D7D2C2264617973223A362C22746178223A31392C226E6574746F223A3534362E32322C227461785072696365223A3130332E37382C22746F74616C223A3635307D',1),
	(18,3,'houseboat',9,'2022-11-30','2022-12-04',440,X'7B22707269636542617365223A3434302C226461696C79507269636573223A7B22323032322D31312D3330223A7B2264617465223A224D692E2033302E31312E32303232222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3131307D2C22323032322D31322D3031223A7B2264617465223A22446F2E2030312E31322E32303232222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3131307D2C22323032322D31322D3032223A7B2264617465223A2246722E2030322E31322E32303232222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3131307D2C22323032322D31322D3033223A7B2264617465223A2253612E2030332E31322E32303232222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3131307D7D2C2264617973223A342C22746178223A31392C226E6574746F223A3336392E37352C227461785072696365223A37302E32352C22746F74616C223A3434307D',1),
	(19,2,'houseboat',7,'2022-12-05','2022-12-11',780,X'7B22707269636542617365223A3738302C226461696C79507269636573223A7B22323032322D31322D3035223A7B2264617465223A224D6F2E2030352E31322E32303232222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3133307D2C22323032322D31322D3036223A7B2264617465223A2244692E2030362E31322E32303232222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3133307D2C22323032322D31322D3037223A7B2264617465223A224D692E2030372E31322E32303232222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3133307D2C22323032322D31322D3038223A7B2264617465223A22446F2E2030382E31322E32303232222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3133307D2C22323032322D31322D3039223A7B2264617465223A2246722E2030392E31322E32303232222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3133307D2C22323032322D31322D3130223A7B2264617465223A2253612E2031302E31322E32303232222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3133307D7D2C2264617973223A362C22746178223A31392C226E6574746F223A3635352E34362C227461785072696365223A3132342E35342C22746F74616C223A3738307D',1),
	(20,1,'apartment',13,'2022-12-05','2022-12-11',840,X'7B22707269636542617365223A3834302C226461696C79507269636573223A7B22323032322D31322D3035223A7B2264617465223A224D6F2E2030352E31322E32303232222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3134307D2C22323032322D31322D3036223A7B2264617465223A2244692E2030362E31322E32303232222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3134307D2C22323032322D31322D3037223A7B2264617465223A224D692E2030372E31322E32303232222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3134307D2C22323032322D31322D3038223A7B2264617465223A22446F2E2030382E31322E32303232222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3134307D2C22323032322D31322D3039223A7B2264617465223A2246722E2030392E31322E32303232222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3134307D2C22323032322D31322D3130223A7B2264617465223A2253612E2031302E31322E32303232222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3134307D7D2C2264617973223A362C22746178223A31392C226E6574746F223A3730352E38382C227461785072696365223A3133342E31322C22746F74616C223A3834307D',1),
	(21,1,'house',12,'2022-12-03','2022-12-11',1120,X'7B22707269636542617365223A313132302C226461696C79507269636573223A7B22323032322D31322D3033223A7B2264617465223A2253612E2030332E31322E32303232222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3134307D2C22323032322D31322D3034223A7B2264617465223A22536F2E2030342E31322E32303232222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3134307D2C22323032322D31322D3035223A7B2264617465223A224D6F2E2030352E31322E32303232222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3134307D2C22323032322D31322D3036223A7B2264617465223A2244692E2030362E31322E32303232222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3134307D2C22323032322D31322D3037223A7B2264617465223A224D692E2030372E31322E32303232222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3134307D2C22323032322D31322D3038223A7B2264617465223A22446F2E2030382E31322E32303232222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3134307D2C22323032322D31322D3039223A7B2264617465223A2246722E2030392E31322E32303232222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3134307D2C22323032322D31322D3130223A7B2264617465223A2253612E2031302E31322E32303232222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3134307D7D2C2264617973223A382C22746178223A31392C226E6574746F223A3934312E31382C227461785072696365223A3137382E38322C22746F74616C223A313132307D',1),
	(22,1,'apartment',13,'2022-12-15','2022-12-23',780,X'7B22707269636542617365223A3738302C226461696C79507269636573223A7B22323032322D31322D3035223A7B2264617465223A224D6F2E2030352E31322E32303232222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3133307D2C22323032322D31322D3036223A7B2264617465223A2244692E2030362E31322E32303232222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3133307D2C22323032322D31322D3037223A7B2264617465223A224D692E2030372E31322E32303232222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3133307D2C22323032322D31322D3038223A7B2264617465223A22446F2E2030382E31322E32303232222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3133307D2C22323032322D31322D3039223A7B2264617465223A2246722E2030392E31322E32303232222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3133307D2C22323032322D31322D3130223A7B2264617465223A2253612E2031302E31322E32303232222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3133307D7D2C2264617973223A362C22746178223A31392C226E6574746F223A3635352E34362C227461785072696365223A3132342E35342C22746F74616C223A3738307D',1),
	(23,1,'house',12,'2023-01-02','2023-01-08',840,X'7B22707269636542617365223A3834302C226461696C79507269636573223A7B22323032332D30312D3032223A7B2264617465223A224D6F2E2030322E30312E32303233222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3134307D2C22323032332D30312D3033223A7B2264617465223A2244692E2030332E30312E32303233222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3134307D2C22323032332D30312D3034223A7B2264617465223A224D692E2030342E30312E32303233222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3134307D2C22323032332D30312D3035223A7B2264617465223A22446F2E2030352E30312E32303233222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3134307D2C22323032332D30312D3036223A7B2264617465223A2246722E2030362E30312E32303233222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3134307D2C22323032332D30312D3037223A7B2264617465223A2253612E2030372E30312E32303233222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3134307D7D2C2264617973223A362C22746178223A31392C226E6574746F223A3730352E38382C227461785072696365223A3133342E31322C22746F74616C223A3834307D',1),
	(24,2,'house',12,'2023-01-09','2023-01-15',780,X'7B22707269636542617365223A3738302C226461696C79507269636573223A7B22323032332D30312D3039223A7B2264617465223A224D6F2E2030392E30312E32303233222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3133307D2C22323032332D30312D3130223A7B2264617465223A2244692E2031302E30312E32303233222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3133307D2C22323032332D30312D3131223A7B2264617465223A224D692E2031312E30312E32303233222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3133307D2C22323032332D30312D3132223A7B2264617465223A22446F2E2031322E30312E32303233222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3133307D2C22323032332D30312D3133223A7B2264617465223A2246722E2031332E30312E32303233222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3133307D2C22323032332D30312D3134223A7B2264617465223A2253612E2031342E30312E32303233222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3133307D7D2C2264617973223A362C22746178223A31392C226E6574746F223A3635352E34362C227461785072696365223A3132342E35342C22746F74616C223A3738307D',1),
	(25,3,'apartment',13,'2023-01-02','2023-01-08',300,X'7B22707269636542617365223A3330302C226461696C79507269636573223A7B22323032332D30312D3032223A7B2264617465223A224D6F2E2030322E30312E32303233222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A35307D2C22323032332D30312D3033223A7B2264617465223A2244692E2030332E30312E32303233222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A35307D2C22323032332D30312D3034223A7B2264617465223A224D692E2030342E30312E32303233222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A35307D2C22323032332D30312D3035223A7B2264617465223A22446F2E2030352E30312E32303233222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A35307D2C22323032332D30312D3036223A7B2264617465223A2246722E2030362E30312E32303233222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A35307D2C22323032332D30312D3037223A7B2264617465223A2253612E2030372E30312E32303233222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A35307D7D2C2264617973223A362C22746178223A31392C226E6574746F223A3235322E312C227461785072696365223A34372E392C22746F74616C223A3330307D',1),
	(26,3,'apartment',13,'2023-01-16','2023-01-22',300,X'7B22707269636542617365223A3330302C226461696C79507269636573223A7B22323032332D30312D3136223A7B2264617465223A224D6F2E2031362E30312E32303233222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A35307D2C22323032332D30312D3137223A7B2264617465223A2244692E2031372E30312E32303233222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A35307D2C22323032332D30312D3138223A7B2264617465223A224D692E2031382E30312E32303233222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A35307D2C22323032332D30312D3139223A7B2264617465223A22446F2E2031392E30312E32303233222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A35307D2C22323032332D30312D3230223A7B2264617465223A2246722E2032302E30312E32303233222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A35307D2C22323032332D30312D3231223A7B2264617465223A2253612E2032312E30312E32303233222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A35307D7D2C2264617973223A362C22746178223A31392C226E6574746F223A3235322C227461785072696365223A34382C22746F74616C223A3330307D',1),
	(27,1,'apartment',13,'2023-01-05','2023-01-15',1400,X'7B22707269636542617365223A313430302C226461696C79507269636573223A7B22323032332D30312D3035223A7B2264617465223A22446F2E2030352E30312E32303233222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3134307D2C22323032332D30312D3036223A7B2264617465223A2246722E2030362E30312E32303233222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3134307D2C22323032332D30312D3037223A7B2264617465223A2253612E2030372E30312E32303233222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3134307D2C22323032332D30312D3038223A7B2264617465223A22536F2E2030382E30312E32303233222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3134307D2C22323032332D30312D3039223A7B2264617465223A224D6F2E2030392E30312E32303233222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3134307D2C22323032332D30312D3130223A7B2264617465223A2244692E2031302E30312E32303233222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3134307D2C22323032332D30312D3131223A7B2264617465223A224D692E2031312E30312E32303233222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3134307D2C22323032332D30312D3132223A7B2264617465223A22446F2E2031322E30312E32303233222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3134307D2C22323032332D30312D3133223A7B2264617465223A2246722E2031332E30312E32303233222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3134307D2C22323032332D30312D3134223A7B2264617465223A2253612E2031342E30312E32303233222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3134307D7D2C2264617973223A31302C22746178223A31392C226E6574746F223A313137362C227461785072696365223A3232342C22746F74616C223A313430307D',1),
	(28,2,'apartment',13,'2023-01-29','2023-02-05',910,X'7B22707269636542617365223A3931302C226461696C79507269636573223A7B22323032332D30312D3239223A7B2264617465223A22536F2E2032392E30312E32303233222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3133307D2C22323032332D30312D3330223A7B2264617465223A224D6F2E2033302E30312E32303233222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3133307D2C22323032332D30312D3331223A7B2264617465223A2244692E2033312E30312E32303233222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3133307D2C22323032332D30322D3031223A7B2264617465223A224D692E2030312E30322E32303233222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3133307D2C22323032332D30322D3032223A7B2264617465223A22446F2E2030322E30322E32303233222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3133307D2C22323032332D30322D3033223A7B2264617465223A2246722E2030332E30322E32303233222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3133307D2C22323032332D30322D3034223A7B2264617465223A2253612E2030342E30322E32303233222C22736169736F6E223A224E6562656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3133307D7D2C2264617973223A372C22746178223A31392C226E6574746F223A3736342C227461785072696365223A3134362C22746F74616C223A3931307D',1),
	(29,1,'apartment',13,'2023-05-12','2023-05-28',2940,X'7B22707269636542617365223A323838302C226461696C79507269636573223A7B22323032332D30352D3132223A7B2264617465223A2246722E2031322E30352E32303233222C22736169736F6E223A225A7769736368656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3138307D2C22323032332D30352D3133223A7B2264617465223A2253612E2031332E30352E32303233222C22736169736F6E223A225A7769736368656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3138307D2C22323032332D30352D3134223A7B2264617465223A22536F2E2031342E30352E32303233222C22736169736F6E223A225A7769736368656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3138307D2C22323032332D30352D3135223A7B2264617465223A224D6F2E2031352E30352E32303233222C22736169736F6E223A225A7769736368656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3138307D2C22323032332D30352D3136223A7B2264617465223A2244692E2031362E30352E32303233222C22736169736F6E223A225A7769736368656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3138307D2C22323032332D30352D3137223A7B2264617465223A224D692E2031372E30352E32303233222C22736169736F6E223A225A7769736368656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3138307D2C22323032332D30352D3138223A7B2264617465223A22446F2E2031382E30352E32303233222C22736169736F6E223A225A7769736368656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3138307D2C22323032332D30352D3139223A7B2264617465223A2246722E2031392E30352E32303233222C22736169736F6E223A225A7769736368656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3138307D2C22323032332D30352D3230223A7B2264617465223A2253612E2032302E30352E32303233222C22736169736F6E223A225A7769736368656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3138307D2C22323032332D30352D3231223A7B2264617465223A22536F2E2032312E30352E32303233222C22736169736F6E223A225A7769736368656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3138307D2C22323032332D30352D3232223A7B2264617465223A224D6F2E2032322E30352E32303233222C22736169736F6E223A225A7769736368656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3138307D2C22323032332D30352D3233223A7B2264617465223A2244692E2032332E30352E32303233222C22736169736F6E223A225A7769736368656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3138307D2C22323032332D30352D3234223A7B2264617465223A224D692E2032342E30352E32303233222C22736169736F6E223A225A7769736368656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3138307D2C22323032332D30352D3235223A7B2264617465223A22446F2E2032352E30352E32303233222C22736169736F6E223A225A7769736368656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3138307D2C22323032332D30352D3236223A7B2264617465223A2246722E2032362E30352E32303233222C22736169736F6E223A225A7769736368656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3138307D2C22323032332D30352D3237223A7B2264617465223A2253612E2032372E30352E32303233222C22736169736F6E223A225A7769736368656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3138307D7D2C22707269636552656E74616C436C65616E696E67223A36302C2270726963654B696C6F77617474223A302C2264617973223A31362C22746178223A31392C226E6574746F223A323437302C227461785072696365223A3437302C22746F74616C223A323934307D',1),
	(30,1,'houseboat',13,'2023-05-22','2023-05-31',1680,X'7B22707269636542617365223A313632302C226461696C79507269636573223A7B22323032332D30352D3232223A7B2264617465223A224D6F2E2032322E30352E32303233222C22736169736F6E223A225A7769736368656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3138307D2C22323032332D30352D3233223A7B2264617465223A2244692E2032332E30352E32303233222C22736169736F6E223A225A7769736368656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3138307D2C22323032332D30352D3234223A7B2264617465223A224D692E2032342E30352E32303233222C22736169736F6E223A225A7769736368656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3138307D2C22323032332D30352D3235223A7B2264617465223A22446F2E2032352E30352E32303233222C22736169736F6E223A225A7769736368656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3138307D2C22323032332D30352D3236223A7B2264617465223A2246722E2032362E30352E32303233222C22736169736F6E223A225A7769736368656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3138307D2C22323032332D30352D3237223A7B2264617465223A2253612E2032372E30352E32303233222C22736169736F6E223A225A7769736368656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3138307D2C22323032332D30352D3238223A7B2264617465223A22536F2E2032382E30352E32303233222C22736169736F6E223A225A7769736368656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3138307D2C22323032332D30352D3239223A7B2264617465223A224D6F2E2032392E30352E32303233222C22736169736F6E223A225A7769736368656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3138307D2C22323032332D30352D3330223A7B2264617465223A2244692E2033302E30352E32303233222C22736169736F6E223A225A7769736368656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3138307D7D2C22707269636552656E74616C436C65616E696E67223A36302C2270726963654B696C6F77617474223A302C2264617973223A392C22746178223A31392C226E6574746F223A313431312C227461785072696365223A3236392C22746F74616C223A313638307D',0),
	(31,3,'house',12,'2023-05-22','2023-06-04',1800,X'7B22707269636542617365223A313735302C226461696C79507269636573223A7B22323032332D30352D3232223A7B2264617465223A224D6F2E2032322E30352E32303233222C22736169736F6E223A225A7769736368656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3133307D2C22323032332D30352D3233223A7B2264617465223A2244692E2032332E30352E32303233222C22736169736F6E223A225A7769736368656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3133307D2C22323032332D30352D3234223A7B2264617465223A224D692E2032342E30352E32303233222C22736169736F6E223A225A7769736368656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3133307D2C22323032332D30352D3235223A7B2264617465223A22446F2E2032352E30352E32303233222C22736169736F6E223A225A7769736368656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3133307D2C22323032332D30352D3236223A7B2264617465223A2246722E2032362E30352E32303233222C22736169736F6E223A225A7769736368656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3133307D2C22323032332D30352D3237223A7B2264617465223A2253612E2032372E30352E32303233222C22736169736F6E223A225A7769736368656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3133307D2C22323032332D30352D3238223A7B2264617465223A22536F2E2032382E30352E32303233222C22736169736F6E223A225A7769736368656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3133307D2C22323032332D30352D3239223A7B2264617465223A224D6F2E2032392E30352E32303233222C22736169736F6E223A225A7769736368656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3133307D2C22323032332D30352D3330223A7B2264617465223A2244692E2033302E30352E32303233222C22736169736F6E223A225A7769736368656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3133307D2C22323032332D30352D3331223A7B2264617465223A224D692E2033312E30352E32303233222C22736169736F6E223A225A7769736368656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3133307D2C22323032332D30362D3031223A7B2264617465223A22446F2E2030312E30362E32303233222C22736169736F6E223A224861757074736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3135307D2C22323032332D30362D3032223A7B2264617465223A2246722E2030322E30362E32303233222C22736169736F6E223A224861757074736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3135307D2C22323032332D30362D3033223A7B2264617465223A2253612E2030332E30362E32303233222C22736169736F6E223A224861757074736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3135307D7D2C22707269636552656E74616C436C65616E696E67223A35302C2270726963654B696C6F77617474223A302C2264617973223A31332C22746178223A31392C226E6574746F223A313531322C227461785072696365223A3238382C22746F74616C223A313830307D',0),
	(32,2,'houseboat',10,'2023-05-28','2023-06-04',1180,X'7B22707269636542617365223A313138302C226461696C79507269636573223A7B22323032332D30352D3238223A7B2264617465223A22536F2E2032382E30352E32303233222C22736169736F6E223A225A7769736368656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3136307D2C22323032332D30352D3239223A7B2264617465223A224D6F2E2032392E30352E32303233222C22736169736F6E223A225A7769736368656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3136307D2C22323032332D30352D3330223A7B2264617465223A2244692E2033302E30352E32303233222C22736169736F6E223A225A7769736368656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3136307D2C22323032332D30352D3331223A7B2264617465223A224D692E2033312E30352E32303233222C22736169736F6E223A225A7769736368656E736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3136307D2C22323032332D30362D3031223A7B2264617465223A22446F2E2030312E30362E32303233222C22736169736F6E223A224861757074736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3138307D2C22323032332D30362D3032223A7B2264617465223A2246722E2030322E30362E32303233222C22736169736F6E223A224861757074736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3138307D2C22323032332D30362D3033223A7B2264617465223A2253612E2030332E30362E32303233222C22736169736F6E223A224861757074736169736F6E222C22686F6C69646179223A6E756C6C2C227072696365223A3138307D7D2C22707269636552656E74616C436C65616E696E67223A302C2270726963654B696C6F77617474223A302C2264617973223A372C22746178223A31392C226E6574746F223A3939312C227461785072696365223A3138392C22746F74616C223A313138307D',0);

/*!40000 ALTER TABLE `rentables` ENABLE KEYS */;
UNLOCK TABLES;


# Tabellen-Dump role_has_permissions
# ------------------------------------------------------------

DROP TABLE IF EXISTS `role_has_permissions`;

CREATE TABLE `role_has_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL,
  `role_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `role_has_permissions_role_id_foreign` (`role_id`),
  CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `role_has_permissions` WRITE;
/*!40000 ALTER TABLE `role_has_permissions` DISABLE KEYS */;

INSERT INTO `role_has_permissions` (`permission_id`, `role_id`)
VALUES
	(1,2),
	(1,3),
	(2,2),
	(2,3),
	(2,5),
	(2,9),
	(3,2),
	(3,3),
	(3,5),
	(3,9),
	(4,2),
	(4,3),
	(5,2),
	(5,3),
	(5,5),
	(5,9),
	(6,2),
	(6,3),
	(7,2),
	(7,3),
	(7,5),
	(7,9),
	(8,3),
	(9,3),
	(9,5),
	(9,9),
	(10,3),
	(11,3),
	(11,5),
	(11,9),
	(12,3),
	(13,2),
	(13,3),
	(13,5),
	(13,9),
	(14,2),
	(14,3),
	(15,2),
	(15,3),
	(15,5),
	(15,9),
	(16,3),
	(16,5),
	(16,9),
	(17,3),
	(17,9),
	(18,2),
	(18,3),
	(18,5),
	(18,9),
	(19,2),
	(19,3),
	(19,5),
	(19,9),
	(20,2),
	(20,3),
	(21,2),
	(21,3),
	(21,5),
	(21,9),
	(22,2),
	(22,3),
	(22,5),
	(22,9),
	(23,2),
	(23,3),
	(23,5),
	(23,9),
	(24,2),
	(24,3),
	(25,2),
	(25,3),
	(25,5),
	(25,9),
	(26,2),
	(26,3),
	(27,1),
	(28,1),
	(29,1),
	(29,12),
	(30,1),
	(30,12),
	(31,3),
	(31,5),
	(31,9),
	(32,2),
	(32,3),
	(32,5),
	(32,9),
	(33,2),
	(33,3),
	(34,2),
	(34,3),
	(34,5),
	(34,9),
	(35,2),
	(35,3),
	(36,2),
	(36,3),
	(36,5),
	(36,9),
	(37,2),
	(37,3),
	(38,2),
	(38,3),
	(38,5),
	(39,1),
	(39,12),
	(40,1),
	(41,1),
	(42,2),
	(42,3),
	(42,5),
	(42,9),
	(43,1),
	(44,2),
	(44,3),
	(44,5),
	(44,9),
	(45,2),
	(45,3),
	(46,2),
	(46,3),
	(46,5),
	(46,9),
	(47,2),
	(47,3),
	(48,2),
	(48,3),
	(48,5),
	(48,9),
	(49,2),
	(49,3),
	(50,2),
	(50,3),
	(50,5),
	(50,9),
	(51,2),
	(51,3),
	(52,1),
	(53,2),
	(53,3),
	(53,5),
	(53,9),
	(54,2),
	(54,3),
	(55,1),
	(56,1),
	(59,2),
	(59,3),
	(59,5),
	(59,9),
	(60,2),
	(60,3),
	(61,2),
	(61,3),
	(61,5),
	(61,9),
	(62,2),
	(62,3),
	(62,5),
	(62,9),
	(63,2),
	(63,3),
	(64,2),
	(64,3),
	(64,5),
	(64,9),
	(65,2),
	(65,3),
	(66,2),
	(66,3),
	(66,5),
	(66,9),
	(67,2),
	(67,3),
	(68,2),
	(68,3),
	(68,5),
	(68,9),
	(69,2),
	(69,3),
	(70,2),
	(70,3),
	(70,5),
	(70,9),
	(71,2),
	(71,3),
	(72,2),
	(72,3),
	(72,5),
	(72,9),
	(73,2),
	(73,3),
	(74,2),
	(74,3),
	(74,5),
	(74,9),
	(75,2),
	(75,3),
	(76,2),
	(76,3),
	(76,5),
	(76,9),
	(76,13),
	(77,2),
	(77,3),
	(78,2),
	(78,3),
	(78,5),
	(78,9),
	(79,2),
	(79,3),
	(80,2),
	(80,3),
	(80,5),
	(80,9),
	(81,2),
	(81,3),
	(82,2),
	(82,3),
	(82,5),
	(82,9),
	(83,2),
	(83,3),
	(83,5),
	(83,9),
	(84,2),
	(84,3),
	(85,2),
	(85,3),
	(85,5),
	(85,9),
	(86,2),
	(86,3),
	(89,2),
	(89,3),
	(89,5),
	(89,9),
	(90,2),
	(90,3),
	(91,2),
	(91,3),
	(91,5),
	(91,9),
	(92,2),
	(92,3),
	(93,2),
	(93,3),
	(93,5),
	(93,9),
	(95,2),
	(95,3),
	(96,2),
	(96,3),
	(96,5),
	(96,9),
	(97,2),
	(97,3),
	(98,2),
	(98,3),
	(98,5),
	(98,9),
	(99,2),
	(99,3),
	(100,2),
	(100,3),
	(100,5),
	(100,9),
	(101,2),
	(101,3),
	(102,2),
	(102,3),
	(102,5),
	(102,9),
	(102,13),
	(103,2),
	(103,3),
	(104,2),
	(104,3),
	(104,5),
	(104,9),
	(105,2),
	(105,3),
	(106,2),
	(106,3),
	(106,5),
	(106,9),
	(106,13),
	(107,2),
	(107,3),
	(108,2),
	(108,3),
	(108,5),
	(108,9),
	(109,2),
	(109,3),
	(110,2),
	(110,3),
	(110,5),
	(110,9),
	(110,13),
	(112,12),
	(113,12),
	(115,2),
	(115,3),
	(115,5),
	(115,9),
	(116,2),
	(116,3),
	(117,1),
	(118,1),
	(119,2),
	(119,3);

/*!40000 ALTER TABLE `role_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;


# Tabellen-Dump roles
# ------------------------------------------------------------

DROP TABLE IF EXISTS `roles`;

CREATE TABLE `roles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `guard_name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;

INSERT INTO `roles` (`id`, `name`, `guard_name`, `created_at`, `updated_at`)
VALUES
	(1,'boat','customer','2021-08-25 12:36:28','2021-11-20 19:24:37'),
	(2,'master','admin','2021-08-25 12:36:33','2021-08-25 12:36:33'),
	(3,'admin','admin','2021-08-25 12:36:38','2021-10-04 17:55:03'),
	(5,'demonstration','admin','2021-09-30 14:21:37','2021-09-30 14:21:37'),
	(9,'boss','admin','2022-03-13 16:49:00','2022-03-16 11:38:38'),
	(12,'renter','customer','2023-01-07 23:43:55','2023-01-07 23:43:55'),
	(13,'employee','admin','2023-01-11 15:17:50','2023-01-11 15:17:50');

/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;


# Tabellen-Dump service_categories
# ------------------------------------------------------------

DROP TABLE IF EXISTS `service_categories`;

CREATE TABLE `service_categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `modus` enum('underwater','board','deck','all') DEFAULT 'board',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `service_categories` WRITE;
/*!40000 ALTER TABLE `service_categories` DISABLE KEYS */;

INSERT INTO `service_categories` (`id`, `name`, `modus`)
VALUES
	(1,'Unterwasser Anstrich','underwater'),
	(4,'Wachsen','board'),
	(5,'Polieren','board'),
	(6,'Unterwasserschiff Reinigung','underwater'),
	(7,'Motor','all'),
	(8,'Elektrik','all'),
	(9,'Überwasser Anstrich','board'),
	(10,'Überwasser Reinigung','board'),
	(11,'Unterwasser Voranstrich','underwater');

/*!40000 ALTER TABLE `service_categories` ENABLE KEYS */;
UNLOCK TABLES;


# Tabellen-Dump service_materials
# ------------------------------------------------------------

DROP TABLE IF EXISTS `service_materials`;

CREATE TABLE `service_materials` (
  `service_id` int(10) unsigned NOT NULL,
  `material_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`service_id`,`material_id`),
  KEY `service_materials_ibfk_2` (`material_id`),
  CONSTRAINT `service_materials_ibfk_1` FOREIGN KEY (`service_id`) REFERENCES `services` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `service_materials_ibfk_2` FOREIGN KEY (`material_id`) REFERENCES `materials` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `service_materials` WRITE;
/*!40000 ALTER TABLE `service_materials` DISABLE KEYS */;

INSERT INTO `service_materials` (`service_id`, `material_id`)
VALUES
	(2,2),
	(3,3),
	(4,1),
	(5,4),
	(6,6),
	(9,9),
	(10,10),
	(11,8);

/*!40000 ALTER TABLE `service_materials` ENABLE KEYS */;
UNLOCK TABLES;


# Tabellen-Dump service_requests
# ------------------------------------------------------------

DROP TABLE IF EXISTS `service_requests`;

CREATE TABLE `service_requests` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `boat_id` int(10) unsigned NOT NULL,
  `description` text NOT NULL,
  `done_until` date NOT NULL,
  `done` tinyint(1) unsigned DEFAULT NULL,
  `done_at` datetime DEFAULT NULL,
  `is_paid` tinyint(1) unsigned DEFAULT 0,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `service_requests_ibfk_1` (`boat_id`),
  CONSTRAINT `service_requests_ibfk_1` FOREIGN KEY (`boat_id`) REFERENCES `boats` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `service_requests` WRITE;
/*!40000 ALTER TABLE `service_requests` DISABLE KEYS */;

INSERT INTO `service_requests` (`id`, `boat_id`, `description`, `done_until`, `done`, `done_at`, `is_paid`, `created_at`, `updated_at`)
VALUES
	(2,35,'Frühjahrsarbeiten 2023','2023-04-30',0,NULL,0,'2023-02-05 18:49:21','2023-02-05 18:49:21'),
	(3,35,'Antifouling Anstrich','2023-05-07',0,NULL,0,'2023-02-08 17:46:42','2023-02-08 17:46:42');

/*!40000 ALTER TABLE `service_requests` ENABLE KEYS */;
UNLOCK TABLES;


# Tabellen-Dump service_requests_services
# ------------------------------------------------------------

DROP TABLE IF EXISTS `service_requests_services`;

CREATE TABLE `service_requests_services` (
  `service_request_id` int(10) unsigned NOT NULL,
  `service_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`service_request_id`,`service_id`),
  KEY `service_requests_services_ibfk_2` (`service_id`),
  CONSTRAINT `service_requests_services_ibfk_1` FOREIGN KEY (`service_request_id`) REFERENCES `service_requests` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `service_requests_services_ibfk_2` FOREIGN KEY (`service_id`) REFERENCES `services` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `service_requests_services` WRITE;
/*!40000 ALTER TABLE `service_requests_services` DISABLE KEYS */;

INSERT INTO `service_requests_services` (`service_request_id`, `service_id`)
VALUES
	(2,2),
	(2,5),
	(2,6),
	(2,7),
	(2,13),
	(3,2);

/*!40000 ALTER TABLE `service_requests_services` ENABLE KEYS */;
UNLOCK TABLES;


# Tabellen-Dump services
# ------------------------------------------------------------

DROP TABLE IF EXISTS `services`;

CREATE TABLE `services` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `service_category_id` int(10) unsigned NOT NULL,
  `price_type_id` int(10) unsigned NOT NULL,
  `name` varchar(100) NOT NULL,
  `quantity` tinyint(3) unsigned DEFAULT 1,
  `price` decimal(10,2) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `services_ibfk_1` (`service_category_id`),
  KEY `services_ibfk_2` (`price_type_id`),
  CONSTRAINT `services_ibfk_1` FOREIGN KEY (`service_category_id`) REFERENCES `service_categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `services_ibfk_2` FOREIGN KEY (`price_type_id`) REFERENCES `config_price_types` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `services` WRITE;
/*!40000 ALTER TABLE `services` DISABLE KEYS */;

INSERT INTO `services` (`id`, `service_category_id`, `price_type_id`, `name`, `quantity`, `price`)
VALUES
	(2,1,1,'Antifouling Anstrich Graphit',1,5.00),
	(3,1,1,'Antifouling Anstrich Blau',1,2.00),
	(4,1,1,'Antifouling Anstrich Extra',1,2.00),
	(5,4,1,'Bootsrumpf wachsen',1,2.00),
	(6,10,5,'Anti-Gilb Reingung',1,1.00),
	(7,5,1,'Bootsrumpf polieren',1,2.00),
	(8,10,5,'Bootsrumpf schleifen',1,5.00),
	(9,11,5,'Osmose Schutz Grau',1,5.00),
	(10,1,5,'Osmose Schutz Grün',1,5.00),
	(11,11,5,'Bootsrumpf grundieren 1x',1,5.00),
	(12,1,5,'Bootsrumpf grundieren 2x',2,10.00),
	(13,1,5,'Bootsrumpf grundieren 3x',3,15.00);

/*!40000 ALTER TABLE `services` ENABLE KEYS */;
UNLOCK TABLES;


# Tabellen-Dump widgets
# ------------------------------------------------------------

DROP TABLE IF EXISTS `widgets`;

CREATE TABLE `widgets` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(50) DEFAULT NULL,
  `slug` varchar(50) DEFAULT NULL,
  `content` text NOT NULL,
  `position` int(10) unsigned NOT NULL,
  `class` varchar(100) DEFAULT NULL,
  `bgColor` varchar(100) DEFAULT NULL,
  `color` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

LOCK TABLES `widgets` WRITE;
/*!40000 ALTER TABLE `widgets` DISABLE KEYS */;

INSERT INTO `widgets` (`id`, `title`, `slug`, `content`, `position`, `class`, `bgColor`, `color`)
VALUES
	(2,'Kontakt','kontakt','<p><strong><span style=\"font-size: 18px;\">Yachtanlieger Netzelkow</span></strong><br>Kirchstra&szlig;e 5,<br>17440 L&uuml;tow<br><em><span>&nbsp;<i class=\"fa  fa-phone fr-deletable\">&nbsp;</i>&nbsp;</span></em><a data-dtype=\"d3ifr\" data-local-attribute=\"d3ph\" data-ved=\"2ahUKEwiNh_rCgKzzAhXB8-AKHfoKBhMQkAgoAHoECDAQAw\" href=\"tel:+493837740575\" id=\"isPasted\">038377 40575</a></p><p><br></p>',3,NULL,'#932092','#feffff');

/*!40000 ALTER TABLE `widgets` ENABLE KEYS */;
UNLOCK TABLES;



/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
